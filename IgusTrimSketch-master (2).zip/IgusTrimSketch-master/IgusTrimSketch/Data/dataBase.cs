﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using System.Xml;
using System.Xml.Serialization;

namespace IgusTrimSketch
{
    public class dataBase
    {
        public MachineList machines = new MachineList("MachineList");
        public List<MachineList> machineList = new List<MachineList>();

        public List<TrimSet> trimsetList= new List<TrimSet>();
        public List<TrimGroup> trimGroupList = new List<TrimGroup>();

        Random rand = new Random();

        DatabasePersist _persist;

        public dataBase(DatabasePersist persist)
        {
            _persist = persist;

            try
            {
                _persist.loadDatabase(this);
            }
            catch (Exception)
            {
                MachineList ml = new MachineList("MachineList 1");
                ml.AddMachine(new Machine("M1", "192.168.3.134", 1));
                ml.AddMachine(new Machine("M2", "192.168.3.134", 2));
                ml.AddMachine(new Machine("M3", "192.168.3.134", 3));

                machineList.Add(ml);

                ml = new MachineList("MachineList 2");
                ml.AddMachine(new Machine("M4", "192.168.3.135", 1));
                ml.AddMachine(new Machine("M5", "192.168.3.135", 2));
                ml.AddMachine(new Machine("M6", "192.168.3.135", 3));

                machineList.Add(ml);

                trimsetList.Add(new TrimSet("Trimset 1", 32, rand));
                trimsetList.Add(new TrimSet("Trimset 2", 32, rand));
                trimsetList.Add(new TrimSet("Trimset 3", 32));

                trimGroupList.Add(new TrimGroup("TrimGroup1", "MachineList 1", "Trimset 1"));
                trimGroupList.Add(new TrimGroup("TrimGroup2", "MachineList 2", "Trimset 2"));
            }

        }

        public void saveDatabase()
        {
            _persist.saveDatabase(this);
        }

        public MachineList getMachineListByName(string name)
        {
            for (int i = 0; i < machineList.Count; i++)
            {
                if (name == machineList[i].name)
                {
                    return machineList[i];
                }
            }
            return null;
        }

        public TrimSet getTrimSetByName(string name)
        {
            for (int i = 0; i < trimsetList.Count; i++)
            {
                if (name == trimsetList[i].name)
                {
                    return trimsetList[i];
                }
            }
            return null;
        }
    }
}
