﻿using System;
using System.Collections.Generic;
using System.Text;

namespace IgusTrimSketch
{

    public class TrimTriple
    {
        public int nr;
        public int trim;
        public int diameter;

        public TrimTriple(int n, int d, int t)
        {
            nr = n;
            trim = t;
            diameter = d;

        }

        public TrimTriple()
        {

        }

    }

    public class TrimSet
    {
        public string name;
        public TrimTriple[] TrimTriples;
        
        public TrimSet()  //wegen Serialisierung stehen lassen
        {

        }

        public TrimSet(string name, int maxItems)
        {
            this.name = name;
            TrimTriples = new TrimTriple[maxItems];

            for (int i = 0; i < TrimTriples.Length; i++)
            {
                TrimTriples[i] = new TrimTriple(i + 1, 45, 0);
            };
        }

        public TrimSet(string name, int maxItems, Random rand)
        {
            this.name = name;
            TrimTriples = new TrimTriple[maxItems];

            if (rand is Random)
                FillTrimsetsWithRandoms(rand);
        }

 
        public void FillTrimsetsWithRandoms(Random rand)
        {

            int[] diameters = { 45, 50, 60, 76 };
            int[] trimfactors = {-5, -4,-3,-2 -1, 0, 1, 2, 3 ,4, 5};

            for (int i = 0; i < TrimTriples.Length; i++)
            {
                TrimTriples[i] = new TrimTriple(i + 1, 
                    diameters[rand.Next(diameters.Length)], 
                    trimfactors[rand.Next(diameters.Length)]
                    );
            };
        }

    }

}
