﻿using System;
using System.Collections.Generic;
using System.Text;

namespace IgusTrimSketch
{

    public class Machine
    {
        public string name;
        public string ipaddress;
        public int lco;

        public Machine(string name, string ipaddress, int lco)
        {
            this.name = name;
            this.ipaddress = ipaddress;
            this.lco = lco;
        }

        public Machine() //wegen Serialisierung stehen lassen
        {

        }

    }

    public class MachineList
    {
        public string name;
        public List<Machine> machines;
       
        public MachineList(string name)
        {
            this.name = name;
            machines = new List<Machine>();
        }

        public MachineList()
        {
            machines = new List<Machine>();
        }

  
        public void AddMachine(Machine nr)
        {
            machines.Add(nr);
        }

    }


}
