﻿using System;
using System.Collections.Generic;
using System.Text;
namespace IgusTrimSketch
{

     public class TrimGroup
    {
        public string name;
        public string machineListname;
        public string trimSetName;

        public List<int> machines;
        public MachineList machineList;
        public TrimSet trims;

        public TrimGroup(string name, string machineListname, string trimSetName)
        {
            this.name = name;
            this.machineListname = machineListname;
            this.trimSetName = trimSetName;

            machines = new List<int>();
        }


        public TrimGroup()
        {

        }

        public void setTrimset(TrimSet ts)
        {
            trims = ts;
        }

        public void AddMachine(int nr)
        {
            machines.Add(nr);
        }

    }

}
