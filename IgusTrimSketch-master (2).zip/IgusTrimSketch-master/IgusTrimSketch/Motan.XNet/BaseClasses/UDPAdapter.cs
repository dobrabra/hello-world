/* Changes:
 * 060125 by Ho: Erweitern der Pr�fung (Zuordnung) Message um Funktion und Subfunktion.
 * 
 * 
 * 
 * 
 * 
 */
using System;
using System.Net;
using System.Net.Sockets;
using System.Collections;
using System.Threading;
using Motan.XNet.XNetProtocol;

namespace Motan.XNet.XNetProtocol
{
	// Sonder 101207 by JH
	public delegate void XNetNotificationHandler(UDPAdapter udpAdapter, XNetMessage message);

	/// <summary>
	/// Die Klasse UDPAdapter kapselt das Senden und Empfangen einer XNetMessage.
	/// Sie implementiert unter anderem den Listener Thread als auch den sogenannten
	/// DispatcherThread, der dann die Verteilung der Nachrichten auf die 
	/// LCO-Objekte durchf�hrt.
	/// </summary>
	public class UDPAdapter
	{
		#region Private Members
		
		private Socket Udp;
		private byte [] Buffer = new byte[1000];	// Gr��e von Eingehenden Nachrichten ist auf 1000 Bytes beschr�nkt
		
		private Motan.Win32CE.ManualResetEvent AbortDispatcher			= Motan.Win32CE.ManualResetEvent.Create(false);
		private Motan.Win32CE.ManualResetEvent StopDispatcher			= Motan.Win32CE.ManualResetEvent.Create(false);
		private Motan.Win32CE.ManualResetEvent DispatcherThreadStopped	= Motan.Win32CE.ManualResetEvent.Create(false);
		private Motan.Win32CE.ManualResetEvent StartDispatcher			= Motan.Win32CE.ManualResetEvent.Create(false);
		private Motan.Win32CE.ManualResetEvent SyncMessageReplyRecived	= Motan.Win32CE.ManualResetEvent.Create(false);
		private XNetMessage SyncReplyMessage = null;

        public XNetMessage AsyncReplyMessage = null;

		private LCOAddress SyncMessageLCO = null;
		private byte MessageFunction;					// 060125 by Ho
		private byte MessageSubFunction;				// 060125 by Ho

		private System.Threading.Thread ListenerThread;
		private System.Threading.Thread DispatcherThread;

		private byte[] SendMessageBuffer = new byte[1024];

		// Sonder 101207 by JH
		public event XNetNotificationHandler XNetNotification;
        public event XNetNotificationHandler XNetAsyncMessage;


		#region Queues

		private Mutex QueueMutex;

		private Queue ReplyQueue = new Queue();

		#endregion

		#region Threads

		/// <summary>
		/// Dieser Thread empf�ngt eingehende UDP Requests und speichert diese in der RequestQueue
		/// </summary>
		private void Listener()
		{
			try
			{
				EndPoint localendpoint  = this.LocalEndPoint;
				EndPoint remoteendpoint = new IPEndPoint(0, 0);

				while(true)
				{
					try
					{
						// BeginReceiveFrom needs a buffer to store received data into and it
						// also needs an EndPoint into which the packet sender's ip address
						// can be stored.  Threads in the ThreadPool don't have storage of
						// their own to use for such things.
					// 060427 JH alle drei folgenden Zeilen ersetzt
						//		IAsyncResult ar = Udp.BeginReceiveFrom(Buffer, 0, Buffer.Length, SocketFlags.None, ref localendpoint, null,null);
						//		ar.AsyncWaitHandle.WaitOne();							
						//		Udp.EndReceiveFrom(ar, ref remoteendpoint);
					// 060427 JH neu, da Handles im Thread nicht freigegeben worden sind.
						Udp.ReceiveFrom(Buffer, 0, Buffer.Length, SocketFlags.None, ref remoteendpoint);	

						//im Buffer liegen die Daten
						XNetMessage m = null;
						
						try
						{
							m = new XNetMessage(Buffer, (IPEndPoint) remoteendpoint, LocalEndPoint);
						}
						catch	// ung�ltige XNet Message
						{
							continue;
						}


						// Sonder 101207 by JH
						if (m.Type == XNetMessageType.Notification && XNetNotification != null)
							XNetNotification(this, m);


//						Requests an das WebPanel werden noch nicht unterst�tzt
						if(m.Type == XNetMessageType.Send || m.Type == XNetMessageType.Notification)
							continue;

						QueueMutex.WaitOne();

						ReplyQueue.Enqueue(m);

						QueueMutex.ReleaseMutex();
					}
					catch(ObjectDisposedException)
					{
						break;
					}
					catch(System.Exception)
					{
						//weitermachen
					}
				}
			}
			catch(System.Exception ex)
			{
				string s = ex.Message;//Wenn Socket geschlossen ist!?!
			}
		}


		/// <summary>
		/// Dieser Thread verarbeitet Messages in der RequestQueue, filtert diese und sorgt daf�r,
		/// dass ein auf einen synchronen call wartender Thread weiter ausgef�hrt wird.
		/// </summary>
		private void Dispatcher()
		{
			//arbeitet die Queues durch
			while(true)
			{
				if(AbortDispatcher.WaitOne(0))
					break;

				if(StopDispatcher.WaitOne(0))
				{
					StopDispatcher.Reset();
					DispatcherThreadStopped.Set();

					StartDispatcher.WaitOne();
					StartDispatcher.Reset();
					DispatcherThreadStopped.Reset();
				}

				Thread.Sleep(10);
				QueueMutex.WaitOne();

				if(ReplyQueue.Count>0)
				{
					XNetMessage m = (XNetMessage) ReplyQueue.Dequeue();

                    if (m.DestinationLCO.IPEndPoint.Equals(LocalEndPoint) && m.SourceLCO.Equals(SyncMessageLCO)
                        && (m.Function == MessageFunction) && (m.SubFunction == MessageSubFunction))						// 060125 by Ho
                    {
                        SyncReplyMessage = m;
                        SyncMessageReplyRecived.Set();
                    }
                    else
                    {
                        if (!m.SourceLCO.Equals(SyncMessageLCO) || (m.SubFunction != MessageSubFunction))
                        {
                            if (XNetAsyncMessage != null)
                                XNetAsyncMessage(this, m);
                        }
                    }
                    
				}

				QueueMutex.ReleaseMutex();
			}
		}
		#endregion

		#endregion

		#region Public Members

		/// <summary>
		/// Lokaler Endpunkt (IPAdresse und Port)
		/// </summary>
		public IPEndPoint LocalEndPoint
		{
			get
			{
				return (IPEndPoint) Udp.LocalEndPoint;
			}
		}

		public bool udpIsOk  //TODO
        {
			get
            {
				return Udp != null;
            }
        }
		/// <summary>
		/// Instanziert den UDP Adapter und startet Listener- und Dispatcherthread. Ein Socket f�r den �bergebenen
		/// Endpunkt wird ge�ffnet.
		/// </summary>
		/// <param name="LocalEndPoint"></param>
		public UDPAdapter(IPEndPoint LocalEndPoint)
		{
            try
            {
                AbortDispatcher.Reset();

                Udp = new Socket(AddressFamily.InterNetwork, SocketType.Dgram, ProtocolType.Udp);

                Udp.Bind(LocalEndPoint);

                QueueMutex = new Mutex(false);

                //Startet den Listener Thread
                ListenerThread = new System.Threading.Thread(new System.Threading.ThreadStart(Listener));
                ListenerThread.Start();

                //Staret des Dispatcher Thread
                DispatcherThread = new Thread(new ThreadStart(this.Dispatcher));
                DispatcherThread.Start();
                //return true;

            }
            catch
            {
                Udp = null;
            }
		}


		/// <summary>
		/// l�st die Resourcen des Adapters auf (z.B. Threads beenden) und schlie�t den UDP Socket
		/// </summary>
		public void Close()
		{
			AbortDispatcher.Set();

			if(Udp!=null)
			{
				Udp.Shutdown(SocketShutdown.Both);
				Udp.Close();
			}

			this.ReplyQueue.Clear();
		}

		/// <summary>
		/// Hier kann festgestellt werden,
		/// ob UDPAdapter initialiert ist.
		/// </summary>
		/// <remarks>
		/// Der UDPAdapter ist initialisiert,wenn
		/// der Socket intialisiert ist. Die Implementierung
		/// verwendet daher dieses Kriterium
		/// </remarks>
		public bool IsInitialized
		{
			get
			{
				return Udp != null;
			}
		}

		/// <summary>
		/// Sendet eine Nachricht, die eine "Reply" Message erwartet (synchroner Charakter)
		/// </summary>
		/// <param name="m">zu sendende XNetMessage</param>
		/// <param name="Timeout">Maximale Wartezeit auf die Antwort in ms</param>
		/// <returns>Empfangene 'Reply' XNetMessage oder null im Timeout Fall</returns>
		public XNetMessage Send(XNetMessage m, int Timeout)
		{
			QueueMutex.WaitOne();

			System.Diagnostics.Debug.Assert(SyncMessageLCO == null);	// es wird auf keinen Syncronen call gewartet

			SyncReplyMessage	= null;
			SyncMessageLCO		= m.DestinationLCO;
			MessageFunction	= m.Function;		// 060125 by Ho
			MessageSubFunction= m.SubFunction;	// 060125 by Ho

			SyncMessageReplyRecived.Reset();

			QueueMutex.ReleaseMutex();

			Notify(m);

			//Warte bis Event gesetzt
			bool bMessageReplied = SyncMessageReplyRecived.WaitOne(Timeout);
			QueueMutex.WaitOne();
			
			SyncMessageLCO = null;

			XNetMessage reply_msg	= SyncReplyMessage;
			SyncReplyMessage		= null;

			QueueMutex.ReleaseMutex();

			if(bMessageReplied == false)	// Timeout
				throw new NetworkException(m);

			return reply_msg;
		}

		/// <summary>
		/// Sendet eine Nachricht, die keine "Reply" Message erwartet (asynchroner Charakter)
		/// </summary>
		/// <param name="m">zu sendende XNetMessage</param>
		public void Notify(XNetMessage m)
		{
			if(Udp==null)
				return;

			int data_length;
			m.GetBytes(ref SendMessageBuffer, out data_length);
            try
            {
                Udp.SendTo(SendMessageBuffer, 0, data_length, SocketFlags.None, m.DestinationLCO.IPEndPoint);
            }
            catch
            {
            }
		}

		#endregion

		#region ControlNodeScanner

		/// <summary>
		/// Event, welches nach jedem Scan einer IP Adresse abgefeuert wird. (wird f�r ein visuelles Feedback
		/// des Scannvorganges verwendet)
		/// </summary>
		public event EventHandler ScanProgress;

		/// <summary>
		/// Scannt im angegebenen IP Adressbereich nach ControlNodes.
		/// </summary>
		/// <param name="IPFrom">Start IP Adresse</param>
		/// <param name="IPTo">End IP Adresse</param>
		/// <param name="RemotePort">Empfangsport der ControlNodes</param>
		/// <returns>liefert eine Liste von empfangenen XNetMessages</returns>
		/// <remarks>
		/// IPFrom und IPEnd m�ssen im selben Netz sein, damit der Scan funktioniert.
		/// Z.B. IPFrom = 192.168.3.20 und IPTo = 192.168.3.240
		/// 
		/// F�r den Scan wird an die IP Adresse die Funktion 1:243 gesendet
		/// </remarks>
		public ControlNodeInfo[] ScanControlNodes(byte IPFrom, byte IPTo, int RemotePort)
		{
			//Dazu muss allerdings der DispatcherThread angehalten werden!
			//nun UDPCalls absetzen
			StopDispatcher.Set();
			DispatcherThreadStopped.WaitOne();

			// Der Dispatcher Thread wartet nun,auf das StartDispatcher Event

			// f�r den Scan wird die NodeNr 255 als Source LCO Nummer verwendet
			LCOAddress sa = new LCOAddress(LocalEndPoint, 255);

			// eventuell vorhandene Replies l�schen
			QueueMutex.WaitOne();
			ReplyQueue.Clear();
			QueueMutex.ReleaseMutex();

			string IPBase = LocalEndPoint.Address.ToString();
			IPBase = IPBase.Substring(0, IPBase.LastIndexOf('.'));

			for(byte ip=IPFrom; ip<=IPTo; ip++)
			{
				IPAddress dipa = IPAddress.Parse(IPBase + "." + ip.ToString());

				if(dipa.Equals(LocalEndPoint.Address) && LocalEndPoint.Port == RemotePort)	// keine Message an sich selber senden
					continue;

				IPEndPoint ipep = new IPEndPoint(dipa, RemotePort);

				LCOAddress da = new LCOAddress(ipep, 255);

				XNetMessage m = new XNetMessage(sa, da, XNetMessageType.Send,1,243,null, DataPresentation.LittleEndian);
				Notify(m);

				if(ScanProgress != null)
					ScanProgress(null, null);

				Thread.Sleep(20);	//			Thread.Sleep(10);	
			}

			// Maximal 5s warten, wenn aber bis dahin von s�mtlichen IPs 
			// ein Request gekommen ist, so kann abgebrochen werden
			for(int i = 0; i < 100; i++)
			{
				QueueMutex.WaitOne();

				int ResponseMessages = ReplyQueue.Count;

				QueueMutex.ReleaseMutex();

				if(ResponseMessages == IPTo-IPFrom+1)
					break;

				Thread.Sleep(10);	//			Thread.Sleep(1);

			}

			//Nun ReplyQueue auswerten
			QueueMutex.WaitOne();

			ArrayList reply_msgs = new ArrayList();

			foreach(XNetMessage mr in ReplyQueue)
			{
				IPEndPoint respondingEP = mr.SourceLCO.IPEndPoint;

				if(LocalEndPoint.Equals(respondingEP))
					continue;

				foreach(XNetMessage m in reply_msgs)
					if(m.SourceLCO.IPEndPoint.Equals(respondingEP))
						continue;

				reply_msgs.Add(mr);
			}

			ReplyQueue.Clear();
			QueueMutex.ReleaseMutex();

			StartDispatcher.Set();

			ControlNodeInfo[] _ControlNodeInfos = new ControlNodeInfo[reply_msgs.Count];

			for(int iIndex = 0; iIndex < reply_msgs.Count; iIndex++)
				_ControlNodeInfos[iIndex] = new ControlNodeInfo((XNetMessage) reply_msgs[iIndex]);

			return _ControlNodeInfos;
		}


		/// <summary>
		/// �berpr�ft einen einzelnen IPEndpunkt, ob hinter diesem ein ControlNode steht.
		/// </summary>
		/// <param name="RemoteEP"></param>
		/// <param name="LocalEP"></param>
		/// <returns></returns>
		/// <remarks>Die Methode wird intern verwendet, um zum letzten ControlNode zu connecten</remarks>
		public ControlNodeInfo GetControlNodeInfo(IPEndPoint RemoteEP)
		{
			Byte[] Adressbytes = RemoteEP.Address.GetAddressBytes();
            byte IP = Adressbytes[3];
            
			ControlNodeInfo[] reply_msgs = ScanControlNodes(IP, IP, RemoteEP.Port);

			if(reply_msgs.Length != 1)
				return null;

			return reply_msgs[0];
		}

		#endregion		
	}
}
