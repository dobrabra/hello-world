using System;
using System.Net;
using System.Net.Sockets;


namespace Motan.XNet.XNetProtocol
{
	/// <summary>
	/// Eine LCO Adresse besteht aus einem IPEndpunkt (IP Adresse und Port) und einer LCO Nummer
	/// </summary>
	/// <remarks>
	/// Diese Klasse wird im WebPanel intern verwendet und hat ansonsten nichts mit dem DatenTyp
	/// NodeAddress zu tun, welcher dazu dient eine Adresse eines LCO Objekte in das UPD Datenpacket
	/// zu schreiben
	/// </remarks>
	public class LCOAddress
	{
		/// <summary>
		/// IP Endpunkt des ControlNodes, welchem das LCO angeh�rt
		/// </summary>
		public IPEndPoint IPEndPoint;

		/// <summary>
		/// LCO Nummer im ControlNode
		/// </summary>
		public byte LCONr;

		public LCOAddress(IPEndPoint cn,byte co)
		{
			this.IPEndPoint = cn;
			this.LCONr = co;
		}


		public override int GetHashCode()
		{
            byte [] Adressbytes = IPEndPoint.Address.GetAddressBytes();
            int Hash = (int)((((long)Adressbytes[3]) << 8) | (long)LCONr);            
            return Hash;
		}

		public override bool Equals(object obj)
		{

	
			LCOAddress coa = obj as LCOAddress;
			if(coa==null) return false;
			return this.GetHashCode() ==  coa.GetHashCode();
		}


		public override string ToString()
		{
			return IPEndPoint.ToString() + ":" + LCONr.ToString();
		}
	}
}
