using System;


namespace Motan.XNet.XNetProtocol
{
	/// <summary>
	/// Spezieller String f�r die Kommunikation mit ControlNodes. (mit fixer L�nge)
	/// </summary>
	/// <remarks>
	/// Im UI ProgrammCode wird mit dem .NET Datentyp String gearbeitet. Dieser Stringtyp
	/// dient nur f�r die UDP Kommunikation
	/// </remarks>
	public class XString
	{
		char[] _text;
		public int Capacity
		{
			get
			{
				return _text.Length;
			}
		}


		/// <summary>
		/// Instanziert einen leeren String mit der �bergebenen Kapazit�t. Leer heisst in diesem
		/// Falle, dass der String aus lauter ' ' Zeichen besteht.
		/// </summary>
		/// <param name="capacity">maximale Kapazit�t des Strings</param>
		public XString(int capacity) : this(capacity, "") {}

		/// <summary>
		/// Instanziert einen String mit der �bergebnen Kapazit�t und belegt in vor.
		/// </summary>
		/// <param name="capacity">Kapazit�t</param>
		/// <param name="s">Text</param>
		/// <remarks>Die L�nge von s muss <= der Kapazit�t sein. U.U. wird der String mit
		/// Blanks aufgef�llt. Ist der �bergebene String l�nger als die maximale Kapazit�t 
		/// so wird eine Exception ausgel�st.</remarks>
		public XString(int capacity, string s)
		{
			_text = new char[capacity];
			Set(s);
		}
	
		/// <summary>
		/// Wandelt den XString in einen .NET String um
		/// </summary>
		/// <param name="xs"></param>
		/// <returns></returns>
		public static implicit operator string(XString xs)
		{
			return xs.ToString();
		}

		/// <summary>
		/// Wandelt den XString in einen .NET String um
		/// </summary>
		public override string ToString()
		{
			return new string(_text);
		}

		/// <summary>
		/// Belegt den XString mit dem �bergebenen Text. 
		/// </summary>
		/// <param name="s"></param>
		/// <remarks>Die L�nge dieses Textes muss
		/// kleiner oder gleich der Kapazit�t des XString Objektes sein. In diesem Fall
		/// wird der XString mit Blanks aufgef�llt. Ist der �bergebene String l�nger,
		/// so wird eine Exception ausgel�st.</remarks>
		public void Set(string s)
		{
			if(s.Length > _text.Length)
				throw new System.Exception("assigned string too long");

			s.CopyTo(0, _text, 0, s.Length);

			for(int i = s.Length; i < _text.Length; i++)
				_text[i] = ' ';
		}
	}


	/// <summary>
	/// Zusammenfassung von ControlNode und LCO Nummer. Der ControlNode entspricht dem letzten Oktett der IP Adresse.
	/// </summary>
	/// <remarks>Dieser Datentype wird nur dazu verwendet, um eine LCO Adresse in eine XNetMessage zu verpacken</remarks>
	public struct NodeAddress
	{
		/// <summary>
		/// Letztes Oktett der IP Adressen des ControlNodes
		/// </summary>
		public byte ControlNode;

		/// <summary>
		/// Nummer des LCO's innerhalb des ControlNodes
		/// </summary>
		public byte LCONumber;

		public static readonly NodeAddress Empty = new NodeAddress();

		public NodeAddress(byte ControlNode, byte LCONumber)
		{
			this.ControlNode = ControlNode;
			this.LCONumber   = LCONumber;
		}

		/// <summary>
		/// Liefert ein String in der Form 000:000
		/// </summary>
		/// <returns></returns>
		public override string ToString()
		{
			return ControlNode.ToString("000") + ":" + LCONumber.ToString("000");
		}

		public static bool operator==(NodeAddress na1, NodeAddress na2)
		{
			return na1.Equals(na2);
		}
		public static bool operator!=(NodeAddress na1, NodeAddress na2)
		{
			return !na1.Equals(na2);
		}
		public override bool Equals(object obj)
		{
			return base.Equals (obj);
		}
		public override int GetHashCode()
		{
			return ((int) ControlNode << 8) | ((int) LCONumber);
		}

	}


}
