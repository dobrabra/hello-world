/* Changes
 *
 * 111214 by MG(1.16.0.3): Neu hinzu protected bool ReadDataPoint(byte Function, byte SubFunction, ref long l)
 *
 *
 *
 *
 *
*/
using System;
using Motan.XNet.XNetProtocol;

namespace Motan.XNet
{
	/// <summary>
	/// Diese Klasse dient als Basisklasse von LCOs
	/// </summary>
	/// <remarks>
	/// Ein LCO ist die Abbildung eines tats�chlichen LCO Objektes in der Steuerung. �ber Properties
	/// und Methoden wreden die Funktionsnummern und Subfunktionsnummern dem UI Programmierer verborgen.
	/// Ein LCo ist immer einem ControlNode zugeordnet.
	/// </remarks>
	public abstract class LogicalControlObject
	{
		#region Error Handling

		/// <summary>
		/// Hier kann der letzte XNetFehler abgerufen werden
		/// </summary>
		/// <region>
		/// Immer wenn auf eine 'Send' XNetMessage eine 'Fault' Message zur�ckkommt,
		/// wird intern eine XNetException ausgel�st. Diese letzte Exception kann �ber dieses
		/// Property ausgelesen werden.
		/// </region>
		public XNetException LastXNetError = null;

		/// <summary>
		/// Wird abgefeuert, wenn eine 'Fault' Message empfangen wird
		/// </summary>
		public event ExeptionEventHandler XNetError;

		/// <summary>
		/// Feuert das Event XNetError ab und deligiert weiter an den ControlNode
		/// </summary>
		/// <param name="error"></param>
		protected virtual void OnXNetError(XNetException error)
		{
			LastXNetError = error;

			if(XNetError != null)
				XNetError(this, LastXNetError);

			CN.OnXNetError(LastXNetError);
		}


		#endregion

		#region Public Members

		/// <summary>
		/// ControlNode der dsa LCO beinhaltet
		/// </summary>
		public readonly ControlNode CN;

		/// <summary>
		/// IPEndpoint und LCO Nummer in der Steuerung
		/// </summary>
		public readonly LCOAddress	Address;
 
		/// <summary>
		/// IPEndpoint und LCO Nummer im WebPanel
		/// </summary>
		/// <remarks>
		/// Die LCO Nummer im WebPanel wird automatisch generiert
		/// </remarks>
		public readonly LCOAddress	LocalAddress; 

		public static int StandardTimeout = 4000;	

		/// <summary>
		/// Gibt den Namen vom LCO Objekt zur�ck (muss LCO spezifisch implementiert werden)
		/// </summary>
		public abstract string Name { get; }


		/// <summary>
		/// Der Aufruf dieser Methode holt sich alle Daten vom 
		/// ControlNode f�r dieses LCO (liest im Normal fall das 242 Dataset aus
		/// und belegt die Properties)
		/// </summary>
		/// <returns>Wenn beim Aufruf etwas fehlschl�gt, dann wird false zur�ckgegeben</returns>
		/// <remarks>Bevor auf ein Property vom LCO zugegriffen wird muss diese Methode
		/// aufgerufen werden. So ist gew�hrleistet, dass die aktuellen Daten im LCO sind.</remarks>
		public abstract bool Update(bool SyncMsg);

        public abstract bool UpdateParser(XNetMessage msg_reply);


		#endregion
		
		#region Write/Read DataPoints

		protected bool WriteDataSet(byte Function, byte SubFunction, byte [] Data, int TimeOut)
		{
			if (TimeOut <= 0)
			{
                TimeOut = StandardTimeout;
			}
			try
			{

				CN.SendWriteCommand(this, Function, SubFunction, Data, TimeOut);
				return true;
			}
			catch(XNetException ex)
			{
				OnXNetError(ex);
				return false;
			}
		}

		#region NotifyEvent
		protected bool NotifyEvent(byte Function, byte SubFunction, byte [] Data, int TimeOut, byte [] Dataold)
		{
			if ((Motan.XNet.ApplicationSettings.IsStartfromLinkNet)||true)
			{
				if (((SubFunction>0) && (SubFunction <=70)) || (SubFunction == 230))
				{
					CN.Notify2LN(this,Function, SubFunction,Data,Dataold);
				}
			}
			return true;
		}
		#endregion

		#region WriteCommand
		protected bool WriteCommand(byte Function, ushort command, int TimeOut, ushort Status)
		{
			NotifyEvent(Function, 230, ConvertHelper.GetBytes(command, DataPresentation.LittleEndian), TimeOut, ConvertHelper.GetBytes(Status, DataPresentation.LittleEndian));
			// spezielle SubFunction 230
			return WriteDataSet(Function, 230, ConvertHelper.GetBytes(command, CN.DataPresentation), TimeOut);
		}
		#endregion

		protected XNetMessage ReadDataSet(byte Function, byte SubFunction, int ReplyDataSetLength, int TimeOut)
		{
			return ReadDataSet(Function, SubFunction, null, ReplyDataSetLength, TimeOut);
		}
		/// <summary>
		/// Liest ein Dataset aus und �berpr�ft die empfangen L�nge
		/// </summary>
		/// <param name="Function"></param>
		/// <param name="SubFunction"></param>
		/// <param name="Data"></param>
		/// <param name="ReplyDataSetLength"></param>
		/// <param name="TimeOut"></param>
		/// <returns></returns>
		protected XNetMessage ReadDataSet(byte Function, byte SubFunction, byte [] Data, int ReplyDataSetLength, int TimeOut)
		{
			try
			{
				XNetMessage reply_msg = CN.SendReadCommand(this, Function, SubFunction, Data, TimeOut);

				if(ReplyDataSetLength == Int32.MaxValue)	// keine �berpr�fung der empfangenen Datasetl�nge
					return reply_msg;

				if(reply_msg.Data.Length >= ReplyDataSetLength)	// Antwort mu� mindestens die geforderte Anzahl Byte liefern
					return reply_msg;

				// Fehler -> falsche l�nge von Daten wurden empfangen
				throw new DataSetReadError(reply_msg);
			}
			catch(XNetException ex)
			{
				OnXNetError(ex);
				return null;
			}
		}

		/// <summary>
		/// Exception Klasse, welche bei einem fehlerhaften Read eines Default DataSets gefeuert wird
		/// </summary>
		public class DataSetReadError : XNetException
		{
			public DataSetReadError(XNetMessage msg) : base(msg)
			{
			}
		}

		#region ReadDefaultDataSet mit Timeout
		protected XNetMessage ReadDefaultDataSet(byte Function, int DataSetLength, int TimeOut)
		{
			return ReadDataSet(Function, 241, null, DataSetLength, TimeOut);
		}
		#endregion

		#region ReadDataPoint mit Timeout

		protected bool ReadDataPoint(byte Function, byte SubFunction, ref bool b, int TimeOut)
		{
			try
			{
				ReadDataSet(Function,SubFunction,null, 1, TimeOut).Parse(out b);
				return true;
			}
			catch(XNetException ex)
			{
				OnXNetError(ex);
				return false;
			}
		}

		protected bool ReadDataPoint(byte Function, byte SubFunction, ref byte b, int TimeOut)
		{
			try
			{
				ReadDataSet(Function,SubFunction,null, 1, TimeOut).Parse(out b);
				return true;
			}
			catch(XNetException ex)
			{
				OnXNetError(ex);
				return false;
			}
		}
		
		protected bool ReadDataPoint(byte Function, byte SubFunction, ref short s, int TimeOut)
		{
			try
			{
				ReadDataSet(Function,SubFunction,null, 2, TimeOut).Parse(out s);
				return true;
			}
			catch(XNetException ex)
			{
				OnXNetError(ex);
				return false;
			}
		}

		protected bool ReadDataPoint(byte Function, byte SubFunction, ref ushort us, int TimeOut)
		{
			try
			{
				ReadDataSet(Function,SubFunction,null, 2, TimeOut).Parse(out us);
				return true;
			}
			catch(XNetException ex)
			{
				OnXNetError(ex);
				return false;
			}
		}

		protected bool ReadDataPoint(byte Function, byte SubFunction, ref int i, int TimeOut)
		{
			try
			{
				ReadDataSet(Function,SubFunction,null, 4, TimeOut).Parse(out i);
				return true;
			}
			catch(XNetException ex)
			{
				OnXNetError(ex);
				return false;
			}
		}

		protected bool ReadDataPoint(byte Function, byte SubFunction, ref float f, int TimeOut)
		{
			try
			{
				ReadDataSet(Function,SubFunction,null, 4, TimeOut).Parse(out f);
				return true;
			}
			catch(XNetException ex)
			{
				OnXNetError(ex);
				return false;
			}
		}

		protected bool ReadDataPoint(byte Function, byte SubFunction, ref long l)
		{
			try
			{
				ReadDataSet(Function,SubFunction,null, 4).Parse(out l);
				return true;
			}
			catch(XNetException ex)
			{
				OnXNetError(ex);
				return false;
			}
		}

		protected bool ReadDataPoint(byte Function, byte SubFunction, ref XString s, int TimeOut)
		{
			try
			{
				ReadDataSet(Function,SubFunction,null, s.Capacity, TimeOut).Parse(ref s);
				return true;
			}
			catch(XNetException ex)
			{
				OnXNetError(ex);
				return false;
			}
		}

		protected bool ReadDataPoint(byte Function, byte SubFunction, ref DateTime dt, int TimeOut)
		{
			try
			{
				ReadDataSet(Function,SubFunction,null, 8, TimeOut).Parse(out dt);
				return true;
			}
			catch(XNetException ex)
			{
				OnXNetError(ex);
				return false;
			}
		}

		protected bool ReadDataPoint(byte Function, byte SubFunction, ref NodeAddress na, int TimeOut)
		{
			try
			{
				ReadDataSet(Function,SubFunction,null, 4, TimeOut).Parse(out na);
				return true;
			}
			catch(XNetException ex)
			{
				OnXNetError(ex);
				return false;
			}
		}
		#endregion

		#region WriteDataPoint mit Timeout
		protected bool WriteDataPoint(byte Function, byte SubFunction, bool b, int TimeOut, bool bold)
		{
			NotifyEvent(Function, SubFunction, ConvertHelper.GetBytes(b, DataPresentation.LittleEndian), TimeOut, ConvertHelper.GetBytes(bold, DataPresentation.LittleEndian));

			return WriteDataSet(Function, SubFunction, ConvertHelper.GetBytes(b, CN.DataPresentation), TimeOut);
		}
		protected bool WriteDataPoint(byte Function, byte SubFunction, byte b, int TimeOut, byte bold)
		{
			NotifyEvent(Function, SubFunction, ConvertHelper.GetBytes(b, DataPresentation.LittleEndian), TimeOut, ConvertHelper.GetBytes(bold, DataPresentation.LittleEndian));

			return WriteDataSet(Function, SubFunction, ConvertHelper.GetBytes(b, CN.DataPresentation), TimeOut);
		}
		protected bool WriteDataPoint(byte Function, byte SubFunction, short s, int TimeOut, short sold)
		{
			NotifyEvent(Function, SubFunction, ConvertHelper.GetBytes(s, DataPresentation.LittleEndian), TimeOut, ConvertHelper.GetBytes(sold, DataPresentation.LittleEndian));

			return WriteDataSet(Function, SubFunction, ConvertHelper.GetBytes(s, CN.DataPresentation), TimeOut);
		}
		protected bool WriteDataPoint(byte Function, byte SubFunction, ushort us, int TimeOut, byte usold)
		{
			NotifyEvent(Function, SubFunction, ConvertHelper.GetBytes(us, DataPresentation.LittleEndian), TimeOut, ConvertHelper.GetBytes(usold, DataPresentation.LittleEndian));

			return WriteDataSet(Function, SubFunction, ConvertHelper.GetBytes(us, CN.DataPresentation), TimeOut);
		}
		protected bool WriteDataPoint(byte Function, byte SubFunction, int i, int TimeOut, int iold)
		{
			NotifyEvent(Function, SubFunction, ConvertHelper.GetBytes(i, DataPresentation.LittleEndian), TimeOut, ConvertHelper.GetBytes(iold, DataPresentation.LittleEndian));

			return WriteDataSet(Function, SubFunction, ConvertHelper.GetBytes(i, CN.DataPresentation), TimeOut);
		}
		protected bool WriteDataPoint(byte Function, byte SubFunction, float f, int TimeOut, float fold)
		{
			NotifyEvent(Function, SubFunction, ConvertHelper.GetBytes(f, DataPresentation.LittleEndian), TimeOut, ConvertHelper.GetBytes(fold, DataPresentation.LittleEndian));

            return WriteDataSet(Function, SubFunction, ConvertHelper.GetBytes(f, CN.DataPresentation), TimeOut);


		}
		protected bool WriteDataPoint(byte Function, byte SubFunction, XString xs, int TimeOut, XString xsold)
		{
			NotifyEvent(Function, SubFunction, ConvertHelper.GetBytes(xs, DataPresentation.LittleEndian), TimeOut, ConvertHelper.GetBytes(xsold, DataPresentation.LittleEndian));

			return WriteDataSet(Function, SubFunction, ConvertHelper.GetBytes(xs, CN.DataPresentation), TimeOut);
		}
		protected bool WriteDataPoint(byte Function, byte SubFunction, DateTime dt, int TimeOut, DateTime dtold)
		{
			NotifyEvent(Function, SubFunction, ConvertHelper.GetBytes(dt, DataPresentation.LittleEndian), TimeOut, ConvertHelper.GetBytes(dtold, DataPresentation.LittleEndian));

			return WriteDataSet(Function, SubFunction, ConvertHelper.GetBytes(dt, CN.DataPresentation), TimeOut);
		}

		protected bool WriteDataPoint(byte Function, byte SubFunction, NodeAddress na, int TimeOut, NodeAddress naold)
		{
			NotifyEvent(Function, SubFunction, ConvertHelper.GetBytes(na, DataPresentation.LittleEndian), TimeOut, ConvertHelper.GetBytes(naold, DataPresentation.LittleEndian));

			return WriteDataSet(Function, SubFunction, ConvertHelper.GetBytes(na, CN.DataPresentation), TimeOut);
		}
		#endregion

		#region WriteDataset ohne Timeoutparameter also mit 
		protected bool WriteDataSet(byte Function, byte SubFunction, byte [] Data)
		{
            return WriteDataSet(Function, SubFunction, Data, StandardTimeout);
		}
		#endregion

		#region ReadDataPoint ohne Timeout
		protected bool ReadDataPoint(byte Function, byte SubFunction, ref bool d)
		{
			return ReadDataPoint(Function, SubFunction, ref d, StandardTimeout);
		}

		protected bool ReadDataPoint(byte Function, byte SubFunction, ref byte d)
		{
			return ReadDataPoint(Function, SubFunction, ref d, StandardTimeout);
		}
		
		protected bool ReadDataPoint(byte Function, byte SubFunction, ref short d)
		{
			return ReadDataPoint(Function, SubFunction, ref d, StandardTimeout);
		}

		protected bool ReadDataPoint(byte Function, byte SubFunction, ref ushort d)
		{
			return ReadDataPoint(Function, SubFunction, ref d, StandardTimeout);
		}

		protected bool ReadDataPoint(byte Function, byte SubFunction, ref int d)
		{
			return ReadDataPoint(Function, SubFunction, ref d, StandardTimeout);
		}

		protected bool ReadDataPoint(byte Function, byte SubFunction, ref float d)
		{
			return ReadDataPoint(Function, SubFunction, ref d, StandardTimeout);
		}

		protected bool ReadDataPoint(byte Function, byte SubFunction, ref XString d)
		{
			return ReadDataPoint(Function, SubFunction, ref d, StandardTimeout);
		}

		protected bool ReadDataPoint(byte Function, byte SubFunction, ref DateTime d)
		{
			return ReadDataPoint(Function, SubFunction, ref d, StandardTimeout);
		}

		protected bool ReadDataPoint(byte Function, byte SubFunction, ref NodeAddress na)
		{
			return ReadDataPoint(Function, SubFunction, ref na, StandardTimeout);
		}
		#endregion

		#region ReadDataSet ohne Timeout

		protected XNetMessage ReadDataSet(byte Function, byte SubFunction, int ReplyDataSetLength)
		{
			return ReadDataSet(Function, SubFunction, null, ReplyDataSetLength, StandardTimeout);
		}

		protected XNetMessage ReadDataSet(byte Function, byte SubFunction, byte [] Data, int ReplyDataSetLength)
		{
			return ReadDataSet(Function, SubFunction, Data, ReplyDataSetLength, StandardTimeout);
		}

		protected XNetMessage ReadDefaultDataSet(byte Function, int DataSetLength)
		{
                return ReadDefaultDataSet(Function, DataSetLength, StandardTimeout);
		}

        protected XNetMessage ReadDefaultDataSet(byte Function, int DataSetLength, bool Sync)
        {
            if (Sync)
                return ReadDefaultDataSet(Function, DataSetLength, StandardTimeout);
            else
                CN.SendReadAsyncCommand(this, Function, 241, null);
            return null;
        }

		#endregion

		#endregion

		#region Alarm

		/// <summary>
		/// aktuelles Alarmwort
		/// </summary>
		protected ushort _Alarm=0;

		/// <summary>
		/// Liest das Alarmwort (SubFunction 231) aus
		/// </summary>
		/// <param name="Function"></param>
		/// <returns></returns>
		protected bool ReadAlarm(byte Function)
		{
			return ReadDataPoint(Function,231,ref _Alarm, StandardTimeout);
		}

		/// <summary>
		/// Liefertr True, wenn das aktuelle Alarmwort <> 0 ist
		/// </summary>
		public bool IsAlarmed
		{
			get { return _Alarm != 0; }
		}
		/// <summary>
		/// �berpr�ft ob das entsprechende Bit im Alarmwort gesetzt ist
		/// </summary>
		/// <param name="alarmcode">Nummer vom Bit (beginnend bei 0)</param>
		/// <returns></returns>
		protected bool HasAlarm(int alarmcode)
		{
			return (_Alarm & (1 << alarmcode)) != 0x0000;
		}

		#endregion

		#region Status

		/// <summary>
		/// aktuelles Statuswort
		/// </summary>
		protected ushort _Status=0;

		/// <summary>
		/// �berpr�ft ob ein Bit im Statuswort gesetzt ist
		/// </summary>
		/// <param name="statuscode">Bitnummer (beginnend bei 0)</param>
		/// <returns></returns>
		protected bool HasStatus(int statuscode)
		{
			return (_Status & (1 << statuscode)) != 0x0000;
		}

        protected void SetStatus(int statuscode, bool status)
        {
            if (status)
                _Status = (ushort)(_Status | (1 << (statuscode)));
            else
                _Status = (ushort)(_Status & (~ (1 << (statuscode))));
                    }
	
		/// <summary>
		/// Liest das Statuswort aus (SubFunktion 232)
		/// </summary>
		/// <param name="Function"></param>
		/// <returns></returns>
		protected bool ReadStatus(byte Function)
		{
			return ReadDataPoint(Function,232,ref _Status, StandardTimeout);
		}
		

		#endregion

		#region Factories

		/// <summary>
		/// Instanziert ein LCO Objekt
		/// </summary>
		/// <param name="cn">ControlNode</param>
		/// <param name="unitnr">LCONr in der Steuerung</param>
		protected LogicalControlObject(ControlNode cn, byte unitnr)
		{
			this.CN = cn;

			byte localunitnr = (byte) CN.AddLCO(this,unitnr);
			Address			= new LCOAddress(cn.IPEndPoint, unitnr);
			LocalAddress	= new LCOAddress(cn.UDPAdapter.LocalEndPoint, localunitnr);
		}
		
		#endregion
	}
}
