using System;
using System.Runtime.InteropServices;

namespace Motan.Win32CE
{
	/// <summary>
	/// Erweiterung der Klasse ManualResetEvent unter CF (Compact Framework)
	/// </summary>
	/// <remarks>
	/// Die im CF vorhandene Klasse ManualResetEvent hat keine Methode WaitOne() mit
	/// Angabe eines Timeouts. Diese wird allerdings ben�tigt, und daher wird eine 
	/// eigene Klasse in diesem Namensraum implementiert.
	/// </remarks>
	abstract class ManualResetEvent
	{
		/// <summary>
		/// CE Implementierung vom ManualReset Event
		/// </summary>
		private class CEManualResetEvent : ManualResetEvent
		{
			private enum APIConstants : int
			{
				WAIT_OBJECT_0   	= 0x00000000,
				WAIT_ABANDONED  	= 0x00000080,
				WAIT_ABANDONED_0	= 0x00000080,
				WAIT_TIMEOUT		= 0x102,
				WAIT_FAILED         = -1,
				INFINITE            = -1	
			}

			private enum EventFlags
			{
				EVENT_PULSE     = 1,
				EVENT_RESET     = 2,
				EVENT_SET       = 3
			}


			[DllImport("coredll.dll", EntryPoint="WaitForSingleObject", SetLastError = true)]
			private static extern int CEWaitForSingleObject(IntPtr hHandle, int dwMilliseconds); 

			[DllImport("coredll.dll", EntryPoint="EventModify", SetLastError = true)]
			private static extern int CEEventModify(IntPtr hEvent, uint function); 

			[DllImport("coredll.dll", EntryPoint="CreateEvent", SetLastError = true)]
			private static extern IntPtr CECreateEvent(IntPtr lpEventAttributes, int bManualReset, int bInitialState, string lpName); 

			[DllImport("coredll.dll", EntryPoint="CloseHandle", SetLastError = true)]
			private static extern IntPtr CECloseHandle(IntPtr handle);

			private IntPtr	_Handle;

			public CEManualResetEvent() : this(false)	{}

			public CEManualResetEvent(bool initState)
			{
				_Handle = CECreateEvent(IntPtr.Zero, 1, initState ? 1 : 0 , null);
			}

			public override void WaitOne()
			{
				WaitOne((int) APIConstants.INFINITE);
			}

			public override bool WaitOne(int timeout)
			{
				int iRet = CEWaitForSingleObject(_Handle, timeout);
				return iRet == (int) APIConstants.WAIT_OBJECT_0;
			}

			public override bool Set()
			{
				return Convert.ToBoolean(CEEventModify(_Handle, (uint)EventFlags.EVENT_SET));
			}

			public override bool Reset()
			{
				return Convert.ToBoolean(CEEventModify(_Handle, (uint)EventFlags.EVENT_RESET));
			}

			public override bool Pulse()
			{
				return Convert.ToBoolean(CEEventModify(_Handle, (uint)EventFlags.EVENT_PULSE));
			}

			~CEManualResetEvent()
			{
				CECloseHandle(_Handle);
			}


		}


		/// <summary>
		/// XP Implementierung vom ManualResetEvent
		/// </summary>
		private class XPManualResetEvent : ManualResetEvent
		{
			private enum APIConstants : int
			{
				WAIT_OBJECT_0   	= 0x00000000,
				WAIT_ABANDONED  	= 0x00000080,
				WAIT_ABANDONED_0	= 0x00000080,
				WAIT_TIMEOUT		= 0x102,
				WAIT_FAILED         = -1,
				INFINITE            = -1	
			}

			[DllImport("Kernel32.dll", EntryPoint="WaitForSingleObject", SetLastError = true)]
			private static extern int WaitForSingleObject(IntPtr hHandle, int dwMilliseconds); 

			[DllImport("Kernel32.dll", EntryPoint="SetEvent", SetLastError = true)]
			private static extern bool SetEvent(IntPtr hEvent); 

			[DllImport("Kernel32.dll", EntryPoint="ResetEvent", SetLastError = true)]
			private static extern bool ResetEvent(IntPtr hEvent); 

			[DllImport("Kernel32.dll", EntryPoint="PulseEvent", SetLastError = true)]
			private static extern bool PulseEvent(IntPtr hEvent); 
				
			[DllImport("Kernel32.dll", EntryPoint="CreateEvent", SetLastError = true)]
			private static extern IntPtr CreateEvent(IntPtr lpEventAttributes, int bManualReset, int bInitialState, string lpName); 

			[DllImport("Kernel32.dll", EntryPoint="CloseHandle", SetLastError = true)]
			private static extern IntPtr CloseHandle(IntPtr handle);

			private IntPtr	_Handle;

			public XPManualResetEvent() : this(false)	{}

			public XPManualResetEvent(bool initState)
			{
				_Handle = CreateEvent(IntPtr.Zero, 1, initState ? 1 : 0 , null);
			}

			public override void WaitOne()
			{
				WaitOne((int) APIConstants.INFINITE);
			}

			public override bool WaitOne(int timeout)
			{
				int iRet = WaitForSingleObject(_Handle, timeout);
				return iRet == (int) APIConstants.WAIT_OBJECT_0;
			}


			public override bool Set()
			{
				return SetEvent(_Handle);
			}

			public override bool Reset()
			{
				return ResetEvent(_Handle);
			}

			public override bool Pulse()
			{
				return PulseEvent(_Handle);
			}

			~XPManualResetEvent() 
			{
				CloseHandle(_Handle);
			}


		}


		/// <summary>
		/// Liefert eine Instanz eines ManualReset Events
		/// (je nach Betriebssystm wird intern ein CEManualResetEvent oder ein XPManualResetEvent instanziert)
		/// </summary>
		/// <param name="InitialState"></param>
		/// <returns></returns>
		public static ManualResetEvent Create(bool InitialState)
		{
			if(System.Environment.OSVersion.Platform == System.PlatformID.WinCE)
				return new CEManualResetEvent(InitialState);
			else
				return new XPManualResetEvent(InitialState);
				
		}


		/// <summary>
		/// H�lt den aktuellen Thread an, bis das Event gesetzt wird
		/// </summary>
		/// <returns></returns>
		public abstract void WaitOne();
		/// <summary>
		/// H�lt den aktuellen Thread an, bis das Event gesetzt wird oder
		/// der Timeout abgelaufen ist
		/// </summary>
		/// <param name="timeout">Maximale Wartezeit in ms</param>
		/// <returns>liefert True wenn der Timeout nicht abgelaufen ist</returns>
		public abstract bool WaitOne(int timeout);
		/// <summary>
		/// Setzt das Event
		/// </summary>
		/// <returns></returns>
		public abstract bool Set();
		/// <summary>
		/// Setzt das Event zur�ck
		/// </summary>
		/// <returns></returns>
		public abstract bool Reset();
		/// <summary>
		/// Setzt und Resetet das Event
		/// </summary>
		/// <returns></returns>
		public abstract bool Pulse();

	}
}
