/* Changes:
 * 051124 by JH: In class XNetMessage "DataLength" als "public readonly" eingebunden
 * 111020 by MG(1.16.0.2): Erweitert um public void Parse(out int i, int index)
 * 111214 by MG(1.16.0.3): Erweitert um public void Parse(out long l)
 * 
 * 
 */
using System;
using System.Net;

namespace Motan.XNet.XNetProtocol
{

	/// <summary>
	/// Typ einer XNetMessage
	/// </summary>
	public enum XNetMessageType
	{
		/// <summary>
		/// Message, welche eine 'Quit' Message als Antwort erwartet (synchrone Kommunikation)
		/// </summary>
		Send			=	'S',

		/// <summary>
		/// Antwort auf eine 'Send' Message (im Success Fall)
		/// </summary>
		Quit			=	'Q',

		/// <summary>
		/// Antwort auf eine 'Send' Message (im Fehlerfall)
		/// </summary>
		Fault			=	'F',

		/// <summary>
		/// Message, welche keine 'Quit' Message als antwort erwartet (asynchrone Kommunikation)
		/// </summary>
		Notification	=	'N'
	}

	/// <summary>
	/// Die Enumeration XNetFault listet die von Motan definierten Fehler
	/// des XNet Protokolls auf
	/// </summary>
	public enum XNetFault
	{
		OK						= '0',
		DcnNOK				= '1',
		DcoNOK				= '2',
		TypNOK				= '3',
		FctNOK				= '4',
		SftNOK				= '5',
		LenNOK				= '6',
		WrongEndian			= '7',
		WrongParam			= '8',
		UnknownNOK			= '?',
		Busy					= 'B',
		CmdDisabled			= 'C',
		ListFull				= 'L',
		Transaction			= 'T',
		WrongSetVal			= 'V',
		CriticalSection	= 'd'
	}

	/// <summary>
	/// Enth�lt alle notwendigen Daten um ein UDP Request �ber UDP zu einem LCO zu senden.
	/// Die Klasse XNetMessage kann auch �ber ein empfangenes UDP Datagramm instanziert werden.
	/// </summary>
	public class XNetMessage
	{
		/// <summary>
		/// Absender der Message
		/// </summary>
		public LCOAddress SourceLCO;

		/// <summary>
		/// Empf�nger der Message
		/// </summary>
		public LCOAddress DestinationLCO;

		/// <summary>
		/// Message Typ (Send, Quit, Fault oder Notification)
		/// </summary>
		public readonly XNetMessageType Type;

		/// <summary>
		/// Fehlercode der Message (im Normalfall auf OK)
		/// </summary>
		public readonly XNetFault ErrorCode;

		/// <summary>
		/// wird noch nicht verwendet (ist immer mit 0 belegt)
		/// </summary>
		public readonly char Reserved;

		/// <summary>
		/// Funktionsnummer der Message
		/// </summary>
		public readonly byte Function;

		/// <summary>
		/// SubFunktionsnummer der Message
		/// </summary>
		public readonly byte SubFunction;

		/// <summary>
		/// DataLength der Message im Header (inkl. Endian und #)
		/// </summary>
		public readonly int DataLength;

		/// <summary>
		/// Array der Nutzdaten (ohne Endian Modifier)
		/// </summary>
		public readonly byte [] Data;

		/// <summary>
		/// ByteOrder das Daten im Datenblock
		/// </summary>
		public readonly DataPresentation DataPresentation;

		/// <summary>
		/// liefert true, wenn im Datenblock keine Daten vorhanden sind (null oder Length = 0)
		/// </summary>
		public bool Empty
		{
			get
			{
				return Data == null || Data.Length == 0;
			}
		}


		/// <summary>
		/// Instanziert ein XNetMessageObjekt ausgehend von einem empfangenen Datenblock
		/// </summary>
		/// <param name="buffer">Empfangenes ByteArray</param>
		/// <param name="Source">Absender der UDP Message</param>
		/// <param name="Destination">der Lokale IP Endpunkt</param>
		internal XNetMessage(byte [] buffer, IPEndPoint Source, IPEndPoint Destination)
		{
			byte coSource		= byte.Parse(System.Text.Encoding.ASCII.GetString(buffer,3,3));
			byte coDestination	= byte.Parse(System.Text.Encoding.ASCII.GetString(buffer,9,3));

			SourceLCO			= new LCOAddress(Source, coSource);
			DestinationLCO		= new LCOAddress(Destination, coDestination);

			Type				= (XNetMessageType) buffer[12];

			ErrorCode			= (XNetFault) buffer[13];
			Reserved			= (char) buffer[14];

			Function	= byte.Parse(System.Text.Encoding.ASCII.GetString(buffer,15,3));
			SubFunction = byte.Parse(System.Text.Encoding.ASCII.GetString(buffer,18,3));

			DataLength	= byte.Parse(System.Text.Encoding.ASCII.GetString(buffer,21,3));
//			DataLength	= byte.Parse(System.Text.Encoding.ASCII.GetString(buffer,21,3));

			if(DataLength > 0)
			{
				// die DataLength enth�lt auch zwei bytes f�r den Endian Modifier
				System.Diagnostics.Debug.Assert(DataLength >= 2);

				Data = new byte[DataLength-2];
				DataPresentation = buffer[24] == 52 ? DataPresentation.LittleEndian : DataPresentation.BigEndian;
				Array.Copy(buffer, 26, Data, 0, Data.Length);
			}
			else
			{
				Data = new byte[0];
				DataPresentation = DataPresentation.LittleEndian;	// irrelevant
			}
		}


		/// <summary>
		/// Instanziert ein XNETMessage Objekt um eine Nachricht abzusenden
		/// </summary>
		/// <param name="sa">Source - Lokaler IP Endpunkt</param>
		/// <param name="da">Destination - Empf�nger IP Endpunkt</param>
		/// <param name="t">Message Typ (Send oder Notify)</param>
		/// <param name="function">Funktion</param>
		/// <param name="subfunction">Subfunktion</param>
		/// <param name="data">Nutzdaten (ohne EndianModifier) ... die Daten im Datenblock m�ssen mit der �bergebenen DataPresentation kodiert sein</param>
		/// <param name="dp">DataPresentation (Little- oder BigEndian) in der die Nutzdaten kodiert sind. Muss im Standardfall mit der Datapresentation des Empf�ngerControlnodes zusammenstimmen</param>
		// Sonder by AB public
		public XNetMessage(LCOAddress sa, LCOAddress da,XNetMessageType t,byte function, byte subfunction,byte[] data, DataPresentation dp)
		{
			SourceLCO			= sa;
			DestinationLCO		= da;
			Type				= t;
			ErrorCode			= XNetFault.OK;
			Reserved			= '0';
			Function			= function;
			SubFunction			= subfunction;
			DataPresentation	= dp;
			Data				= data;
		}

		private void itoa(byte b,byte [] buffer,int index)
		{
			string s = b.ToString("D3");
			System.Text.ASCIIEncoding.ASCII.GetBytes(s,0,3,buffer,index);
		}

		/// <summary>
		/// Liefert den ByteHaufen, der per UDP abgesendet werden kann
		/// </summary>
		/// <param name="buffer">Referenz auf einen SendeBuffer (wird im Bedarfsfall vergr��ert)</param>
		/// <param name="length">L�nge des belgten Datenbuffers</param>

		internal void GetBytes(ref byte[] buffer, out  int length)
		{
			if(Empty)
				length = 24;
			else
				length = 24 + 2 + Data.Length;

			if(buffer.Length < length)
				buffer = new byte[length];

			//SourceControlnode
 //   		itoa((byte) (this.SourceLCO.IPEndPoint.Address.Address >> 24),buffer,0);


            Byte[] Sourcebytes = this.SourceLCO.IPEndPoint.Address.GetAddressBytes();
            Byte[] Destinationbytes = this.DestinationLCO.IPEndPoint.Address.GetAddressBytes();
            
            itoa(Sourcebytes[3], buffer, 0);
            itoa(this.SourceLCO.LCONr,buffer,3);
			itoa(Destinationbytes[3],buffer,6);
			itoa(this.DestinationLCO.LCONr,buffer,9);

			buffer[12] = (byte) Type;
			buffer[13] = (byte) (char) ErrorCode;
			buffer[14] = (byte) Reserved;

			itoa(this.Function,buffer,15);
			itoa(this.SubFunction,buffer,18);

			if(Empty)	// keine Daten vorhanen
			{
				itoa(0,buffer,21);
			}
			else
			{
				itoa((byte) (Data.Length+2),buffer,21);

				if(DataPresentation == DataPresentation.LittleEndian)
					buffer[24]=52; //Ascii '4'
				else
					buffer[24]=51; //Ascii '3'

				buffer[25] = 35; //Ascii '#'

				this.Data.CopyTo(buffer, 26);
			}
		}


		#region Parse Methoden

		private int currentIndex = 0;

		public void Parse(out bool b)
		{
			ConvertHelper.Parse(Data, currentIndex, DataPresentation, out b);
			currentIndex++;
		}
		public void Parse(out byte b)
		{
			ConvertHelper.Parse(Data, currentIndex, DataPresentation, out b);
			currentIndex++;
		}
		public void Parse(out short s)
		{
			ConvertHelper.Parse(Data, currentIndex, DataPresentation, out s);
			currentIndex += 2;
		}
		public void Parse(out ushort us)
		{
			ConvertHelper.Parse(Data, currentIndex, DataPresentation, out us);
			currentIndex += 2;
		}
		public void Parse(out int i)
		{
			ConvertHelper.Parse(Data, currentIndex, DataPresentation, out i);
			currentIndex += 4;
		}
		public void Parse(out uint ui)
		{
			ConvertHelper.Parse(Data, currentIndex, DataPresentation, out ui);
			currentIndex += 4;
		}
		public void Parse(out float f)
		{
			ConvertHelper.Parse(Data, currentIndex, DataPresentation, out f);
			currentIndex += 4;
		}
		public void Parse(ref XString s)
		{
			ConvertHelper.Parse(Data, currentIndex, DataPresentation, ref s);
			currentIndex += s.Capacity;
		}
		public void Parse(out DateTime dt)
		{
			ConvertHelper.Parse(Data, currentIndex, DataPresentation, out dt);
			currentIndex += 8;
		}
		public void Parse(ref byte [] bs)
		{
			ConvertHelper.Parse(Data, currentIndex, DataPresentation, ref bs);
			currentIndex += bs.Length;
		}
		public void Parse(out NodeAddress na)
		{
			ConvertHelper.Parse(Data, currentIndex, DataPresentation, out na);
			currentIndex += 2;
		}
		public void Parse(out int i, int index)
		{
			ConvertHelper.Parse(Data, index, DataPresentation, out i);
		}
		public void Parse(out long l)
		{
			ConvertHelper.Parse(Data, currentIndex, DataPresentation, out l);
			currentIndex += 8;
		}

		#endregion

	}
}
