using System;
using System.Net;
using System.Collections;
using Motan.XNet.XNetProtocol;


namespace Motan.XNet
{
	/// <summary>
	/// Typ eines ControlNodes
	/// 050609 Ho: Anpassung enum ControlNodeTyp mit fixen Werten; Vorgabe f�r Bereichsauswertung der
	///            Stationen.
	/// </summary>
	// 050609 Ho	public enum ControlNodeTyp { Unknown, LUXORnet, METROnet, GRAVInet };
	public enum ControlNodeTyp { Unknown=0, LUXORnet=256, METROnet=512, GRAVInet=768 };

	/// <summary>
	/// Basisklasse f�r Controlnodes im XNet
	/// </summary>
	public abstract class ControlNode
	{
		#region Error Handling

		/// <summary>
		/// Hier kann der letzte XNetFehler abgerufen werden
		/// </summary>
		/// <region>
		/// Immer wenn auf eine 'Send' XNetMessage eine 'Fault' Message zur�ckkommt,
		/// wird intern eine XNetException ausgel�st. Diese letzte Exception kann �ber dieses
		/// Property ausgelesen werden.
		/// </region>
		public XNetException LastXNetError = null;

		/// <summary>
		/// Event, welches bei Auftreten eines XNetFehlers (f�r s�mtliche LCOs des ControlNodes)
		/// abgefeuert wird
		/// </summary>
		public event ExeptionEventHandler XNetError;

		/// <summary>
		/// Feuert das XNetError Event ab.
		/// </summary>
		/// <param name="error"></param>
		internal virtual void OnXNetError(XNetException error)
		{
			LastXNetError = error;

			if(XNetError != null)
				XNetError(this, LastXNetError);
		}



		#endregion

		#region Private Members

		private bool _IsInitialized = false;
		private ArrayList _LCOs = new ArrayList();
		private byte _Errorcode=0;

		#endregion

		#region Public Members

		public readonly UDPAdapter UDPAdapter;
		public readonly int Geraetetyp;

		/// <summary>
		/// Letztes Oktett der IPAdresse der IPAdresse vom ControlNode
		/// </summary>
		public readonly byte NodeNumber;

		/// <summary>
		/// Endpunkt (IP Adresse und Port) vom ControlNode
		/// </summary>
		public readonly System.Net.IPEndPoint IPEndPoint;

		/// <summary>
		/// Datendarstellung im ControlNode (Little bzw. BigEndian)
		/// </summary>
		public DataPresentation DataPresentation;
		/// <summary>
		/// True, wenn ControlNode initialisiert ist
		/// </summary>
		/// <remarks>
		/// Liefert True, wenn Refresh aufgerufen wurde
		/// und der ControlNode hat erfolgreich s�mtliche LCO Objekte instanziert hat. Dazu
		/// musste zuerst das Auslesen vom SystemLCO funktionieren.
		/// </remarks>
		public bool IsInitialized
		{
			get { return _IsInitialized; }
		}

		public byte Errorcode
		{
			get { return _Errorcode; }
			set { _Errorcode = value; }
		}

		/// <summary>
		/// Liefert (soweit vorhanden) das gew�nschte LCO zu�rck
		/// </summary>
		public LogicalControlObject GetLCO(byte LCONr)
		{
			foreach(LogicalControlObject lco in _LCOs)
				if(lco.Address.LCONr == LCONr)
					return lco;

			return null;
		}

		/// <summary>
		/// Liest das SystemLCO aus und instanziert die LCOs vom ControlNode
		/// </summary>
		/// <returns>Liefert True, wenn die Initialisierung funktioniert hat</returns>
		public bool Refresh()
		{
			_IsInitialized = Initialize();

			if(_IsInitialized == false)
				RemoveAllLCOs();

			return _IsInitialized;
		}

		/// <summary>
		/// Initialisiert das Controlnodeobjekt v�llig neu
		/// Idee: Realisierung von Plug and Play?
		/// </summary>
		/// <remarks>
		/// Diese Methode wird intern von Refresh aufgerufen.
		/// </remarks>
		protected virtual bool Initialize()
		{
			//alle LCOs abmelden
			RemoveAllLCOs();
			
			_IsInitialized = false;
			return _IsInitialized;
		}

		/// <summary>
		/// Hinzuf�gen von LogicalControlObjects
		/// </summary>
		/// <param name="lco"></param>
		/// <remarks>Jedes LCO muss beim ControlNode 'registriert' werden.
		/// Im Zuge dieser Registrierung wird dem LCO eine lokale LCO Nummer zugeordnet.
		/// �ber diese lokale LCO Nummer kommuniziert das C# LCO Objet mit dem LCO in der
		/// Steuerung.
		/// </remarks>
		internal int AddLCO(LogicalControlObject lco)
		{
			//  zur�ckgegeben wird die lokale LCO Nummer des neuen LCO's
			// ... entspricht dem Index im Array, um eins erh�ht

			return _LCOs.Add(lco)+1;
		}

        internal int AddLCO(LogicalControlObject lco, byte lconr)
        {
            foreach (LogicalControlObject _lco in _LCOs)
                if (_lco.Address.LCONr == lconr)
                {
                    _LCOs.Remove(_lco);
                    break;
                }

            return _LCOs.Add(lco) + 1;
        }

		/// <summary>
		/// L�scht s�mtliche LCO's
		/// </summary>
		public void RemoveAllLCOs()
		{
			_LCOs.Clear();
		}


		/// <summary>
		/// Sendet eine 'Send' Message an das LCO und liefert die empfangene 'Quit' Message (synchrone Kommunikation)
		/// </summary>
		/// <param name="lco">Empf�nger LCO</param>
		/// <param name="Function">Funktion</param>
		/// <param name="SubFunction">SubFunktion</param>
		/// <param name="Data">Nutzdaten</param>
		/// <param name="TimeOut">Maximale Wartezeit auf den Response</param>
		/// <returns>Antwort des LCOs in der Steuerung</returns>
		/// <remarks>
		/// Die Methode liefert immer eine g�ltige Reply Message. Im Fehlerfall (Timeout oder Fault Antwort) wird eine Exception ausgel�st
		/// </remarks>
		internal XNetMessage SendWriteCommand(LogicalControlObject lco, byte Function, byte SubFunction,byte[]Data, int TimeOut)
		{
			//TODO System.Diagnostics.Debug.Assert(_LCOs.Contains(lco));
			
			XNetMessage m = new XNetMessage(lco.LocalAddress, lco.Address, XNetMessageType.Send, Function,SubFunction, Data, DataPresentation);
			XNetMessage reply_msg = UDPAdapter.Send(m, TimeOut);

			if(SynchMessageSend != null)
				SynchMessageSend(this, null);

			if(reply_msg.Type == XNetMessageType.Fault)
				throw new XNetException(reply_msg);

			if(WriteCommandSend != null)
				WriteCommandSend(this, null);

			return reply_msg;
		}
		/// <summary>
		/// Sendet eine 'Send' Message an das LCO und liefert die empfangene 'Quit' Message (synchrone Kommunikation)
		/// </summary>
		/// <param name="lco">Empf�nger LCO</param>
		/// <param name="Function">Funktion</param>
		/// <param name="SubFunction">SubFunktion</param>
		/// <param name="Data">Nutzdaten</param>
		/// <param name="TimeOut">Maximale Wartezeit auf den Response</param>
		/// <returns>Antwort des LCOs in der Steuerung</returns>
		/// <remarks>
		/// Die Methode liefert immer eine g�ltige Reply Message. Im Fehlerfall (Timeout oder Fault Antwort) wird eine Exception ausgel�st
		/// </remarks>
		internal XNetMessage SendReadCommand(LogicalControlObject lco, byte Function, byte SubFunction,byte[]Data, int TimeOut)
		{
			//TODO System.Diagnostics.Debug.Assert(_LCOs.Contains(lco));
			
			XNetMessage m = new XNetMessage(lco.LocalAddress, lco.Address, XNetMessageType.Send, Function,SubFunction, Data, DataPresentation);
			XNetMessage reply_msg = UDPAdapter.Send(m, TimeOut);

			if(SynchMessageSend != null)
				SynchMessageSend(this, null);

			if(reply_msg.Type == XNetMessageType.Fault)
				throw new XNetException(reply_msg);

			return reply_msg;
		}
		/// <summary>
		/// Sendet eine 'Notify' Message an das LCo in der Steuerung (asynchron)
		/// </summary>
		/// <param name="Function">Funktion</param>
		/// <param name="SubFunction">SubFunktion</param>
		/// <param name="Data">Nutzdaten</param>
		internal void Notify(LogicalControlObject lco, byte Function, byte SubFunction,byte[]Data)
		{
			//TODO System.Diagnostics.Debug.Assert(_LCOs.Contains(lco));

			XNetMessage m = new XNetMessage(lco.LocalAddress, lco.Address, XNetMessageType.Notification, Function, SubFunction, Data, DataPresentation);
			UDPAdapter.Notify(m);
		}

        internal void SendReadAsyncCommand(LogicalControlObject lco, byte Function, byte SubFunction, byte[] Data)
        {
           //TODO System.Diagnostics.Debug.Assert(_LCOs.Contains(lco));

            XNetMessage m = new XNetMessage(lco.LocalAddress, lco.Address, XNetMessageType.Send, Function, SubFunction, Data, DataPresentation);
            UDPAdapter.Notify(m);
        }

        


        internal void Notify2LN(LogicalControlObject lco, byte Function, byte SubFunction, byte[] Data, byte[] Dataold)
        {
            string _Stationname = "----";

            if (_LCOs[1] is LCO.SystemLCO)
            {
                LCO.SystemLCO sys = (LCO.SystemLCO)_LCOs[1];
                _Stationname = sys.Name;
            }




            byte[] Data26 = new byte[26];

            if (Data.Length > 8)
            {
                for (int i = 0; i <= 7; i++)
                    Data26[18 + i] = Data[i];
            }
            else
            {
                Data26[18] = Data26[19] = Data26[20] = Data26[21] = Data26[22] = Data26[23] = Data26[24] = Data26[25] = 0;
                Data.CopyTo(Data26, 18);
            }
            if (Dataold.Length > 8)
            {
                for (int i = 0; i <= 7; i++)
                    Data26[10 + i] = Dataold[i];
            }
            else
            {
                Data26[10] = Data26[11] = Data26[12] = Data26[13] = Data26[14] = Data26[15] = Data26[16] = Data26[17] = 0;
                Dataold.CopyTo(Data26, 10);
            }

            Data26[0] = lco.Address.LCONr;	// LCO-Nr als int16 und Name ablegen
            Data26[1] = 0;
            System.Text.ASCIIEncoding.ASCII.GetBytes(lco.Name, 0, lco.Name.Length, Data26, 2);

            Data26[6] = Function;
            Data26[7] = 0;
            Data26[8] = SubFunction;
            Data26[9] = 0;

            string _CurrentUser = "------";
            short _CurrentUserlevel = 0;

            // 080616 Sonder by JH 
            //string szrole = Motan.Windows.Forms.RoleManager.CurrentRole.ToString();
            int len;
            // 080616 Sonder by JH 
            //len	= 6 /*WCN+Name*/ + data.Length + 2 /*PW-Level*/ + szrole.Length /*username*/ ;
            len = 6 /*WCN+Name*/ + Data26.Length + 2 /*PW-Level*/ + _CurrentUser.Length /*username*/ ;


            byte[] tempdata = new byte[len];

            tempdata[0] = 123;
            tempdata[1] = 0;
            System.Text.ASCIIEncoding.ASCII.GetBytes(_Stationname, 0, _Stationname.Length, tempdata, 2);

            Data26.CopyTo(tempdata, 6);
            BitConverter.GetBytes(_CurrentUserlevel).CopyTo(tempdata, 32);
            // 080616 Sonder by JH 
            //System.Text.ASCIIEncoding.ASCII.GetBytes(szrole,0,szrole.Length,tempdata,34);
            System.Text.ASCIIEncoding.ASCII.GetBytes(_CurrentUser, 0, _CurrentUser.Length, tempdata, 34);

            System.Diagnostics.Debug.Assert(_LCOs.Contains(lco));
            LCOAddress dadr = new LCOAddress(lco.LocalAddress.IPEndPoint, 254);
            LCOAddress sadr = new LCOAddress(lco.LocalAddress.IPEndPoint, 254);
            dadr.IPEndPoint.Port = 5141;
            XNetMessage m = new XNetMessage(sadr, dadr, XNetMessageType.Notification, 251, 1, tempdata, DataPresentation.LittleEndian);
            UDPAdapter.Notify(m);
        }

		/// <summary>
		/// Immer wenn ein Datenpunkt beschrieben oder ein Command erfolgreich abgesetzt wurde (une ein 'Q' Antworttelegramm empfangen wurde) wird ein Event ausgel�st.
		/// Das UI h�rt auf dieses Event und aktualisiert die Sicht.
		/// </summary>
		public event EventHandler WriteCommandSend;


		/// <summary>
		/// Immer wenn eine XNetMessage abgesetzt wurde (une ein 'Q' Antworttelegramm empfangen wurde) wird ein Event ausgel�st.
		/// Das UI h�rt auf dieses Event und zeigt an, dass eine Netzwerkverbindung besteht
		/// </summary>
		public event EventHandler SynchMessageSend;

		#endregion

		#region Factory
		/// <summary>
		/// Instanziert einen ControlNode
		/// </summary>
		/// <param name="UDPAdapter">UDPAdapter (lokaler Endpunkt)</param>
		/// <param name="cni">ControlNodeInfo der Steuerung</param>
		internal ControlNode(UDPAdapter UDPAdapter, ControlNodeInfo cni)
		{
			this.UDPAdapter			= UDPAdapter;
			this.DataPresentation	= cni.DataPresentation;
			this.IPEndPoint			= cni.EndPoint;
			this.Geraetetyp			= cni.GeraeteTyp;
            Byte[] Adressbytes      = IPEndPoint.Address.GetAddressBytes();
			this.NodeNumber			= Adressbytes[3];
		}
		#endregion
	}
}
