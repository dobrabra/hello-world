using System;
using System.Net;
using Motan.XNet.XNetProtocol;


namespace Motan.XNet
{
	
	public enum ControlType
	{
		Luxornet_256			=	256,
		Luxornetlight_257		=	257,	//Andere Gebl�sesichten
		Metrolux_258			=	258,	//Andere Trocknersichten
		LuxornetNewGBView_259	=	259,	//Neuer StandbyManager/Gebl�sesicht
		LuxornetLMRCAN_260		=	260,	//Neu mit CAN und LMR und komplett konfigurierbar
		Metronet_512			=	512,
		Metronet_light_513		=	513,	//Abweichende Konfiguration
		Metronet_light_514		=	514,	//Neuer StandbyManager/Gebl�sesicht
		Metronet_515			=	515,	//Neuer StandbyManager/Gebl�sesicht
		GraviNetGcP300_768		=	768,
		GraviNetGcP305_2MB_769	=	769,
		GraviNetMc_770			=	770,
		GraviNetGcP305_4MB_771	=	771,
		VoluNetOld_772			=	772,
		VoluNetP205_774			=	774,
		GraviNetGcP205_775		=	775,
		GraviNetMc_776			=	776


	


}
	/// <summary>
	/// Informationen �ber einen ControlNode
	/// 050609 Ho: Anpassung auf den Bereich von 256 m�glichen Knoten, welche jeweils 
	///            Luxornet=256..511,Metronet=512..767,Gravinet=768..1023 zugeordnet werden.
	/// </summary>
	public class ControlNodeInfo
	{
		/// <summary>
		/// Instanziert das ControlNodeInfo Objekt
		/// </summary>
		/// <param name="m">Antwort eines ControlNodes auf das auslesen des 1:243 Datensatzes
		/// </param>
		public ControlNodeInfo(XNetMessage m)
		{
			EndPoint = m.SourceLCO.IPEndPoint;

			StationName			= "XXXX";
			ControlNodeTyp		= ControlNodeTyp.Unknown;
			DataPresentation	= DataPresentation.LittleEndian;

			try
			{
				XString _StationName = new XString(4);

				this.DataPresentation = m.DataPresentation;

				m.Parse(ref _StationName);

				StationName = _StationName;
				
				short sGeraeteTyp = 0;
				m.Parse(out sGeraeteTyp);

// Beginn neu 050609 by Ho
				//				switch(sGeraeteTyp)		
				//				{
				//					case 256:	ControlNodeTyp = ControlNodeTyp.LUXORnet;	break;
				//					case 512:	ControlNodeTyp = ControlNodeTyp.METROnet;	break;
				//					case 768:	ControlNodeTyp = ControlNodeTyp.GRAVInet;	break;
				//					default:	ControlNodeTyp = ControlNodeTyp.Unknown;	break;
				//				}
				GeraeteTyp = sGeraeteTyp;
				if (( (int)Motan.XNet.ControlNodeTyp.LUXORnet <= sGeraeteTyp) && (sGeraeteTyp < (int)Motan.XNet.ControlNodeTyp.METROnet))
					ControlNodeTyp = ControlNodeTyp.LUXORnet;
				if (( (int)Motan.XNet.ControlNodeTyp.METROnet <= sGeraeteTyp) && (sGeraeteTyp < (int)Motan.XNet.ControlNodeTyp.GRAVInet))
					ControlNodeTyp = ControlNodeTyp.METROnet;
				if (( (int)Motan.XNet.ControlNodeTyp.GRAVInet <= sGeraeteTyp) && (sGeraeteTyp < ((int)Motan.XNet.ControlNodeTyp.GRAVInet + 256)))
					ControlNodeTyp = ControlNodeTyp.GRAVInet;

// Ende neu 050609 by Ho
			}
			catch
			{
				ControlNodeTyp		= ControlNodeTyp.Unknown;
			}
		}


		/// <summary>
		/// DataPresentation (Little- oder Big Endian) des ControlNodes
		/// </summary>
		public readonly DataPresentation DataPresentation;

		/// <summary>
		/// Stationsname
		/// </summary>
		public readonly string StationName;

		/// <summary>
		/// Typ (GraviNet, LuxorNet oder MetroNet
		/// </summary>
		public readonly ControlNodeTyp ControlNodeTyp;

		/// <summary>
		/// GeraeteTyp (GraviNet, LuxorNet oder MetroNet) detaillierter als Short
		/// </summary>
		public readonly short GeraeteTyp;			// 050609 by Ho

		/// <summary>
		/// Remote EndPoint der Steuerung
		/// </summary>
		public readonly IPEndPoint EndPoint;

		public override bool Equals(object obj)
		{
			ControlNodeInfo o = obj as ControlNodeInfo;

			if(obj == null)
				return false;

			return o.StationName == StationName && o.ControlNodeTyp == ControlNodeTyp && o.EndPoint.Address == EndPoint.Address && o.EndPoint.Port == EndPoint.Port;
		}
		public override int GetHashCode()
		{
			return base.GetHashCode ();
		}


		public override string ToString()
		{
			if (_ShowShortString)
			{
				string str = EndPoint.Address.ToString();
				string[] parts = str.Split(new Char[]{'.'});
				return StationName + " IP: " + parts[parts.Length - 1];
			}
			else
				return StationName + " (" + ControlNodeTyp.ToString() + " - IP: " + EndPoint.ToString() + ")";

		}

		private bool _ShowShortString = false;
		public bool ShowShortString
		{
			get { return _ShowShortString; }
			set { _ShowShortString = value; }
		}
	}
	
}
