using System;
using Motan.XNet.XNetProtocol;


namespace Motan.XNet
{
	/// <summary>
	/// Delegate, welches von der EventSink implementiert werden muss,
	/// um �ber Events von Exceptions informiert zu werden
	/// </summary>
	public delegate void ExeptionEventHandler(object sender, System.Exception arg);
	/// <summary>
	/// Exceptionklasse, speziell f�r das XNetProtocoll
	/// </summary>
	public class XNetException : System.Exception
	{
		/// <summary>
		/// Fault Message welche von der Steuereung gesendet wurde
		/// </summary>
		public readonly XNetMessage XNetMessage;

		internal XNetException(XNetMessage msg) : base(msg.ErrorCode.ToString())
		{
			this.XNetMessage = msg;
			
		}
	}

	/// <summary>
	/// Spezielle Exceptionklasse f�r Netzwerkfehler (Netzwerkunterbruch)
	/// </summary>
	public class NetworkException : XNetException
	{
		internal NetworkException(XNetMessage Msg):base(Msg)
		{
		}

		public override string Message
		{
			get
			{
				return "Network Timeout";
			}
		}

	}

}
