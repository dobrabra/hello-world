/* Changes
 *
 * 111214 by MG(1.16.0.3): Neu hinzu public static void Parse(byte[] buffer, int Index, DataPresentation dp, out long l)
 *
 *
 *
 *
 *
*/

using System;


namespace Motan.XNet.XNetProtocol
{
	/// <summary>
	/// M�glichen Datenpr�sentationen (Big- oder LittleEndian) eines ControlNodes
	/// </summary>
	/// <remarks>Ein ControlNode erwartet je nach Steuerungstyp Little- oder BigEndian
	/// kodierte Daten. Das Web Panel detektiert schon bei der ersten Kontaktaufnahme 
	/// den EndianType vom ControlNode und kommuniziert entsprechend.</remarks>
	public enum DataPresentation
	{
		LittleEndian, BigEndian
	}	

	/// <summary>
	/// Beinhaltet Hilfsfunktionen, f�r die Konvertierung des Bytestreams aus dem UDP-Protokoll in .NET 
	/// Datentypen und umgekehrt
	/// </summary>
	public class ConvertHelper
	{
		public static byte [] GetBytes(bool b, DataPresentation dp)
		{
			return BitConverter.GetBytes(b);
		}
		public static byte [] GetBytes(byte b, DataPresentation dp)
		{
			//return BitConverter.GetBytes(b);
			byte[] bval = new byte[1];
			bval[0]= b;
			return bval;
		}
		public static byte [] GetBytes(short s, DataPresentation dp)
		{
			byte[] bs = BitConverter.GetBytes(s);

			// Convert To Endian
			if(dp != LocalDataPresentation)
				Array.Reverse(bs, 0, bs.Length);

			return bs;
		}
		public static byte [] GetBytes(ushort us, DataPresentation dp)
		{
			byte[] bs = BitConverter.GetBytes(us);
				
			// Convert To Endian
			if(dp != LocalDataPresentation)
				Array.Reverse(bs, 0, bs.Length);

			return bs;
		}
		public static byte [] GetBytes(int i, DataPresentation dp)
		{
			byte[] bs = BitConverter.GetBytes(i);
				
			// Convert To Endian
			if(dp != LocalDataPresentation)
				Array.Reverse(bs, 0, bs.Length);

			return bs;
		}
		public static byte [] GetBytes(uint ui, DataPresentation dp)
		{
			byte[] bs = BitConverter.GetBytes(ui);
				
			// Convert To Endian
			if(dp != LocalDataPresentation)
				Array.Reverse(bs, 0, bs.Length);

			return bs;
		}
		public static byte [] GetBytes(float f, DataPresentation dp)
		{
			return GetBytes((int) Math.Round(f * 100, 0), dp);
		}
		public static byte [] GetBytes(XString s, DataPresentation dp)
		{
			return System.Text.Encoding.ASCII.GetBytes(s.ToString());
		}
		public static byte [] GetBytes(DateTime dt, DataPresentation dp)
		{
			byte[] bs = new byte[8];
			//Laut SDM25-01 wird beim Datumstyp die Jahreszahl in einen Byte
			//mit dem Zahlenraum 0-99 definiert. Daher muss beim Jahreswert der
			//Wert 2000 abgezogen werden. Siehe auch entsprechend Parse()-Funktion
			bs[0] = (byte)(dt.Year-2000);
			bs[1] = (byte)dt.Month;
			bs[2] = (byte)dt.Day;
			bs[3] = 0;
			bs[4] = (byte)dt.Hour;
			bs[5] = (byte)dt.Minute;
			bs[6] = (byte)dt.Second;
			bs[7] = (byte)0;

			return bs;
		}
		public static byte [] GetBytes(byte[] b, DataPresentation dp)
		{
			return b;
		}

		public static byte [] GetBytes(NodeAddress na, DataPresentation dp)
		{
			byte[] bs =  new byte[2];

			bs[0] = na.ControlNode;
			bs[1] = na.LCONumber;

			return bs;
		}


		public static void Parse(byte[] buffer, int Index, DataPresentation dp, out bool b)
		{
			b = BitConverter.ToBoolean(buffer, Index);
		}
		public static void Parse(byte[] buffer, int Index, DataPresentation dp, out byte b)
		{
			b = buffer[Index];
		}
		public static void Parse(byte[] buffer, int Index, DataPresentation dp, out short s)
		{
			Array.Copy(buffer,Index, buffer2, 0, 2);

			if(LocalDataPresentation != dp)
				Array.Reverse(buffer2,0,2);

			s = BitConverter.ToInt16(buffer2, 0);
		}
		public static void Parse(byte[] buffer, int Index, DataPresentation dp, out ushort us)
		{
			Array.Copy(buffer,Index, buffer2, 0, 2);

			if(LocalDataPresentation != dp)
				Array.Reverse(buffer2,0,2);

			us = BitConverter.ToUInt16(buffer2, 0);
		}
		public static void Parse(byte[] buffer, int Index, DataPresentation dp, out int i)
		{
			Array.Copy(buffer,Index, buffer4, 0, 4);

			if(LocalDataPresentation != dp)
				Array.Reverse(buffer4,0,4);

			i = BitConverter.ToInt32(buffer4, 0);
		}
		public static void Parse(byte[] buffer, int Index, DataPresentation dp, out uint ui)
		{
			Array.Copy(buffer,Index, buffer4, 0, 4);

			if(LocalDataPresentation != dp)
				Array.Reverse(buffer4,0,4);

			ui = BitConverter.ToUInt32(buffer4, 0);
		}
		public static void Parse(byte[] buffer, int Index, DataPresentation dp, out float f)
		{
			int i;
			Parse(buffer, Index, dp, out i);
			f = ((float) i) / 100;
		}

		public static void Parse(byte[] buffer, int Index, DataPresentation dp, out long l)
		{
			int i;
			Parse(buffer, Index, dp, out i);
			l = (long)i;
		}
		public static void Parse(byte[] buffer, int Index, DataPresentation dp, ref XString s)
		{
			s.Set(System.Text.ASCIIEncoding.ASCII.GetString(buffer,Index,s.Capacity));
		}
		public static void Parse(byte[] buffer, int Index, DataPresentation dp, out DateTime dt)
		{
			Array.Copy(buffer,Index,buffer8,0,8);
				
			if(buffer8[7]==50) //Ascii '2'(2.. PM , 1.. AM, 0..24h)
			{
				buffer8[4]+=12;
			}
			//Laut SDM25-01 wird beim Datumstyp die Jahreszahl in einen Byte
			//mit dem Zahlenraum 0-99 definiert. Daher muss diesem Wert 2000
			//hinzugefuegt werden.
			try
			{
				dt=new DateTime((int)buffer8[0]+2000,(int)buffer8[1],(int)buffer8[2],(int)buffer8[4],(int)buffer8[5],(int)buffer8[6]);
			}
			catch
			{
				dt=new DateTime(2000, 1, 1, 0, 0, 0);  //wenn etwas schief geht, R�ckgabewert auf 01.01.2000 0:00 Uhr
			}
		}
		public static void Parse(byte[] buffer, int Index, DataPresentation dp, ref byte [] bs)
		{
			Array.Copy(buffer,Index,bs,0,bs.Length);
		}
		public static void Parse(byte[] buffer, int Index, DataPresentation dp, out NodeAddress na)
		{
			na.ControlNode	= buffer[Index];
			na.LCONumber	= buffer[Index+1];
		}


		private static byte[] buffer2 = new byte[2];
		private static byte[] buffer4 = new byte[4];
		private static byte[] buffer8 = new byte[8];

		/// <summary>
		/// Datapresentation (LittleEndian oder BigEndian) des WebPanel Systems
		/// </summary>
		public static readonly DataPresentation LocalDataPresentation = BitConverter.IsLittleEndian ? DataPresentation.LittleEndian : DataPresentation.BigEndian;
	}


}
