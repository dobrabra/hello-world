/* Functional Description
 *    
 * 
 * 
 */
/* Changes:
 * 
 * 160330 by MG(3.0.0.0):	Fehlerbild:		AA16041 Daten fehlen
					     	Ursache:		Datensatz wurde im CODESYS erweitert
					     	Abhilfe:		Neue Parameter:
												NewTrend_Aktiv
											�nderung Parameter:
												Statuscode
											Neue Methode:
												cfCalcualteOffset
												cfAutoReduceSensivity
												GetSingleTrendDataset(short Curve1, short CurveNumber,short Blockindex) inklusive
												zus�tzlicher Parameter, siehe region Special ReadDataSet TrendData 247
											Ge�nderte Methode
												UpdateParser erweitert um Parsing f�r acmsgversion 220216 
					     	Baustein:		Blendmgr_FCT035.cs 
 * 
 * 
 */
using System;
using System.Collections;

using Motan;
using Motan.XNet;
using Motan.XNet.XNetProtocol;

using System.Data;

namespace Motan.XNet.LCO
{
	/// <summary>
	/// ;
	/// </summary>
    /// 
    public enum OnOffState
    { Off, On, OffDelayed, LineStopByComp }

    public class Blendmgr_FCT035 : LogicalControlObject
    {

        #region Status

        public enum  StatusCode
		{
			sfOnOff								= 0,
			sfMixerOnOff						= 5,
			sfMixerContinuos					= 6,
			sfControlSwitch						= 8,
            sfMixerRun                          = 9,
            sfDosRun = 10,//Dosierung l�uft noch durch Nachlauf, Gelb anzeigen bei ONOFFbutton wenn SFonOff aus und sfDosrun Ein
            sfSimulationOnOff = 12,
            sfLineStopByComp = 13, //Linienstopp durch Komponente wegen Stellbefehl Unterschreitung
            sfCalculateOffset = 14,
            sfAutoReduceSensivity = 15
        };
		public bool  HasStatus(StatusCode statuscode)
		{
			return base.HasStatus((int) statuscode);
		}

        public void SetStatus(StatusCode statuscode, bool value)
        {
             base.SetStatus((int)statuscode,value);
        }

			
		#endregion
         
        #region Parameter
        #region Property svName
        private XString _svName=new XString(4);
		public string svName
		{
			get
			{
				return (string)_svName;
			}
			set
			{
				WriteDataPoint(35,1, new XString(_svName.Capacity, value),-1,new XString(_svName.Capacity, _svName));
			}
		}
	
		#endregion
		#region Property svDosingTime
		private float _svDosingTime=0;
		public float svDosingTime
		{
			get
			{
				return _svDosingTime* 10;
			}
			set
			{
				WriteDataPoint(35,2,value/10,-1,_svDosingTime);
			}
		}

		#endregion
		#region Property svThroughputEX
		private float _svThroughputEX=0;
		public float svThroughputEX
		{
			get
			{
				return _svThroughputEX * 10;
			}
			set
			{
                if (WriteDataPoint(35, 3, value / 10, -1, _svThroughputEX))
                {
                    _svThroughputEX = value;
                };
			}
		}
		#endregion
		#region Property svShotWeight
		private float _svShotWeight=0;
		public float svShotWeight
		{
			get
			{
				return _svShotWeight * 10;
			}
			set
			{
				WriteDataPoint(35,4,value/ 10,-1,_svShotWeight);
			}
		}

		#endregion
		#region Property svProcessTechnique
		private byte _svProcessTechnique=0;
		public byte svProcessTechnique
		{
			get
			{
				return _svProcessTechnique;
			}
			set
			{
				WriteDataPoint(35,5,value,-1,_svProcessTechnique);
			}
		}

		#endregion
		#region Property svVoltageMAX
		private float _svVoltageMAX=0;
		public float svVoltageMAX
		{
			get
			{
				return _svVoltageMAX;
			}
			set
			{
                if (WriteDataPoint(35, 6, value, -1, _svVoltageMAX))
                {
                    _svVoltageMAX = value;
                };
			}
		}
		#endregion
		#region Property svPctVoltageMAX
		private float _svPctVoltageMAX=0;
		public virtual float svPctVoltageMAX
		{
			get
			{
				return _svPctVoltageMAX;
			}
			set
			{
                if (WriteDataPoint(35, 7, value, -1, _svPctVoltageMAX))
                {
                    _svVoltageMAX = value;
                };
			}
		}

		#endregion
		#region Property svVoltageMIN
		private float _svVoltageMIN=0;
		public virtual float svVoltageMIN
		{
			get
			{
				return _svVoltageMIN;
			}
			set
			{
                if (WriteDataPoint(35, 8, value, -1, _svVoltageMIN))
                {
                    _svVoltageMIN = value;
                };

			}
		}
		#endregion
		#region Property svPctVoltageMIN
		private float _svPctVoltageMIN=0;
		public  float svPctVoltageMIN
		{
			get
			{
				return _svPctVoltageMIN;
			}
			set
			{
                if (WriteDataPoint(35, 9, value, -1, _svPctVoltageMIN))
                {
                    _svPctVoltageMIN = value;
                };

			}
		}
		

		#endregion
		#region Property svTypMainComp
		private short _svTypMainComp=0;
		public virtual short svTypMainComp
		{
			get
			{
				return _svTypMainComp;
			}
			set
			{
				WriteDataPoint(35,10,value,-1,_svTypMainComp);
			}
		}
	

		#endregion
		#region Property svOrderNumber
		private XString _svOrderNumber=new XString(8);
		public string svOrderNumber
		{
			get
			{
				return (string)_svOrderNumber;
			}
			set
			{
				WriteDataPoint(35,11, new XString(_svOrderNumber.Capacity, value),-1,new XString(_svOrderNumber.Capacity, _svOrderNumber));
			}
		}
	
		#endregion
		#region Property svMixerRunOnTime
		private short _svMixerRunOnTime=0;
		public short svMixerRunOnTime
		{
			get
			{
				return _svMixerRunOnTime;
			}
			set
			{
				WriteDataPoint(35,12,value,-1,_svMixerRunOnTime);
			}
		}

		#endregion
		#region Property svCtctMde
		private short _svCtctMde=0;
		public virtual short svCtctMde
		{
			get
			{
				return _svCtctMde;
			}
			set
			{
                if (WriteDataPoint(35, 13, value, -1, _svCtctMde))
                {
                    _svCtctMde = value;
                };

			}
		}


		// Istwerte
		#endregion
        #region Property acShotCounts
        protected uint _acShotCounts = 0;
        public uint acShotCounts
        {
            get
            {
                return _acShotCounts;
            }
        }

        #endregion
        #region Property acGesamtgewicht
        protected float _acGesamtgewicht = 0;
        public float acGesamtgewicht
        {
            get
            {
                return _acGesamtgewicht;
            }
        }

        #endregion
        #region Property acOldTotals1
        protected float _acOldTotals1 = 0;
        public float acOldTotals1
        {
            get
            {
                return _acOldTotals1;
            }
        }

        #endregion
        #region Property acOldTotals2
        protected float _acOldTotals2 = 0;
        public float acOldTotals2
        {
            get
            {
                return _acOldTotals2;
            }
        }

        #endregion
        #region Property acOldTotals3
        protected float _acOldTotals3 = 0;
        public float acOldTotals3
        {
            get
            {
                return _acOldTotals3;
            }
        }

        #endregion
        #region Property acOldTotals4
        protected float _acOldTotals4 = 0;
        public float acOldTotals4
        {
            get
            {
                return _acOldTotals4;
            }
        }

        #endregion
        #region Property acOldDates1
        protected DateTime _acOldDates1 = DateTime.Now;
        public DateTime acOldDates1
        {
            get
            {
                return _acOldDates1;
            }
        }

        #endregion
        #region Property acOldDates2
        protected DateTime _acOldDates2 = DateTime.Now;
        public DateTime acOldDates2
        {
            get
            {
                return _acOldDates2;
            }
        }

        #endregion
        #region Property acOldDates3
        protected DateTime _acOldDates3 = DateTime.Now;
        public DateTime acOldDates3
        {
            get
            {
                return _acOldDates3;
            }
        }

        #endregion
        #region Property acOldDates4
        protected DateTime _acOldDates4 = DateTime.Now;
        public DateTime acOldDates4
        {
            get
            {
                return _acOldDates4;
            }
        }

        #endregion
        #region Property acOrderNumber
        protected XString _acOrderNumber = new XString(8);
        public string acOrderNumber
        {
            get
            {
                return (string)_acOrderNumber;
            }
        }

        #endregion
        #region Property acTotalTimeExtrusion
        protected float _acTotalTimeExtrusion = 0;
        public float acTotalTimeExtrusion
        {
            get
            {
                return _acTotalTimeExtrusion;
            }
        }

        #endregion
        #region Property acRecipeNumber
        protected short _acRecipeNumber = 0;
        public short acRecipeNumber
        {
            get
            {
                return _acRecipeNumber;
            }
        }

        #endregion
        #region Property acDosingTime
        protected float _acDosingTime = 0;
        public float acDosingTime
        {
            get
            {
                return _acDosingTime;
            }
        }

        #endregion
        #region Property acThroughput
        protected float _acThroughput = 0;
        public float acThroughput
        {
            get
            {
                return _acThroughput;
            }
        }
        #endregion
		#region Property acGuideVal
		protected float _acGuideVal=0;
		public float acGuideVal
		{
			get
			{
				return _acGuideVal;
			}
		}

		#endregion
		#region Property acRelThroughput
		protected float _acRelThroughput=0;
		public float acRelThroughput
		{
			get
			{
				return _acRelThroughput;
			}
		}

		#endregion
		#region Property acUnitType
		protected short _acUnitType=0;
		public short acUnitType
		{
			get
			{
				return _acUnitType;
			}
		}

		#endregion
		#region Property acMsgVersion
		private int _acMsgVersion=0;
		public int acMsgVersion
		{
			get
			{
				return _acMsgVersion;
			}
		}
		#endregion
		#region Property svAdaptRange
		private short _svAdaptRange=0;
		public short svAdaptRange
		{
			get
			{
				return _svAdaptRange;
			}
			set
			{
				WriteDataPoint(35,15,value,-1,_svAdaptRange);
			}
		}
		#endregion
		#region Property svExtTolerance
        private Int32 _svExtTolerance = 0;
        public Int32 svExtTolerance
		{
			get
			{
				return _svExtTolerance;
			}
			set
			{
                if (WriteDataPoint(35, 16, value, -1, _svExtTolerance))
                {
                    _svExtTolerance = value;
                };

			}
		}
		#endregion
		#region Property svCalcVariant
		private short _svCalcVariant=0;
		public short svCalcVariant
		{
			get
			{
				return _svCalcVariant;
			}
			set
			{
                if (WriteDataPoint(35,17,value,-1,_svCalcVariant))
                {
                    _svCalcVariant = value;
                };

			}
		}
		#endregion
		#region Property svMainComp
		private short _svMainComp=0;
		public short svMainComp
		{
			get
			{
				return _svMainComp;
			}
			set
			{
                if (WriteDataPoint(35, 18, value, -1, _svMainComp))
                {
                    _svMainComp = value;
                };

			}
		}
		#endregion
		#region Property svTimePerDiv
		private short _svTimePerDiv=0;
		public short svTimePerDiv
		{
			get
			{
				return _svTimePerDiv;
			}
			set
			{
				WriteDataPoint(35,19,value,-1,_svTimePerDiv);
			}
		}
		#endregion
		#region Property svTrendStunde
		private short _svTrendStunde=0;
		public short svTrendStunde
		{
			get
			{
				return _svTrendStunde;
			}
		}
		#endregion
		#region Property svTrendMinute
		private short _svTrendMinute=0;
		public short svTrendMinute
		{
			get
			{
				return _svTrendMinute;
			}
		}
		#endregion
        #region Property acLevel
        protected Int32 _acLevel = 0;
        public Int32 acLevel
        {
            get
            {
                return _acLevel;
            }
        }

        #endregion
        #region Property acCalculatedSetThroughput
        protected float _acCalculatedSetThroughput = 0;
        public float acCalculatedSetThroughput
        {
            get
            {
                return _acCalculatedSetThroughput;
            }
        }

        #endregion
        #region Property svlevelsetpoint
        protected Int32 _svlevelsetpoint = 0;
        public Int32 svlevelsetpoint
        {
            get
            {
                return _svlevelsetpoint;
            }
            set
            {
                if (WriteDataPoint(35, 20, value, -1, _svlevelsetpoint))
                {
                    _svlevelsetpoint = value;
                };
            }
        }

        #endregion
        #region Property svlevelstart
        protected Int32 _svlevelstart = 0;
        public Int32 svlevelstart
        {
            get
            {
                return _svlevelstart;
            }
            set
            {
                WriteDataPoint(35, 21, value, -1, _svlevelstart);
            }
        }

        #endregion
        #region Property svlevelmin
        protected Int32 _svlevelmin = 0;
        public Int32 svlevelmin
        {
            get
            {
                return _svlevelmin;
            }
        }

        #endregion
        #region Property svlevelmax
        protected Int32 _svlevelmax = 0;
        public Int32 svlevelmax
        {
            get
            {
                return _svlevelmax;
            }
            set
            {
                WriteDataPoint(35, 23, value, -1, _svlevelmax);
            }
        }

        #endregion
        #region Property svThroughput
        private float _svThroughput = 0;
        public float svThroughput
        {
            get
            {
                return _svThroughput;
            }
            set
            {
                if (WriteDataPoint(35, 3, value, -1, _svThroughput))
                {
                    _svThroughput = value;
                };

                ;
            }
        }

        #endregion
        #region Property svGuidevalX1
        private float _svGuidevalX1 = 0;
        public float svGuidevalX1
        {
            get
            {
                return _svGuidevalX1;
            }
            set
            {
                WriteDataPoint(35, 6, value, -1, _svGuidevalX1);
            }
        }
        #endregion
        #region Property svGuidevalY1
        private float _svGuidevalY1 = 0;
        public virtual float svGuidevalY1
        {
            get
            {
                return _svGuidevalY1;
            }
            set
            {
                WriteDataPoint(35, 7, value, -1, _svGuidevalY1);
            }
        }

        #endregion
        #region Property svGuidevalX2
        private float _svGuidevalX2 = 0;
        public virtual float svGuidevalX2
        {
            get
            {
                return _svGuidevalX2;
            }
            set
            {
                WriteDataPoint(35, 8, value, -1, _svGuidevalX2);
            }
        }
        #endregion
        #region Property svGuidevalY2
        private float _svGuidevalY2 = 0;
        public float svGuidevalY2
        {
            get
            {
                return _svGuidevalY2;
            }
            set
            {
                WriteDataPoint(35, 9, value, -1, _svGuidevalY2);
            }
        }


        #endregion
        #region Property acScaleNumber
        protected Int32 _acScaleNumber = 0;
        public Int32 acScaleNumber
        {
            get
            {
                return _acScaleNumber;
            }
        }

        #endregion
        #region Property svRampStep
        private float _svRampStep = 0;
        public float svRampStep
        {
            get
            {
                return _svRampStep;
            }
            set
            {
                if (WriteDataPoint(35, 24, value, -1, _svRampStep))
                {
                    _svRampStep = value;
                };

            }
        }

        #endregion
        #region Property svThroughputMan
        private float _svThroughputMan = 0;
        public float svThroughputMan
        {
            get
            {
                return _svThroughputMan;
            }
            set
            {
                if (WriteDataPoint(35, 25, value, -1, _svThroughputMan))
                {
                    _svThroughputMan = value;
                };
                
            }
        }

                #endregion
        #region Property svVariant
        private ushort _svVariant = 0;
        public ushort svVariant
        {
            get
            {
                return _svVariant;
            }
            set
            {
                WriteDataPoint(35, 15, value, -1, _svVariant);
            }
        }
        #endregion
        #region Property svRecipeNumber
        protected short _svRecipeNumber = 0;
        public virtual short svRecipeNumber
        {
            get
            {
                return _svRecipeNumber;
            }
            set
            {
            }
        }

        #endregion
        #region Property acRecipeName
        protected XString _acRecipeName = new XString(8);
        public XString acRecipeName
        {
            get
            {
                return (XString)_acRecipeName;
            }
            set
            {
            }
        }

        #endregion
        #region Property acRecipeType
        protected short _acRecipeType = 0;
        public short acRecipeType
        {
            get
            {
                return _acRecipeType;
            }
        }

        #endregion
        #region Property svCountOfSlopeDetections
        protected short _svCountOfSlopeDetections = 1;
        public short svCountOfSlopeDetections
        {
            get
            {
                return _svCountOfSlopeDetections;
            }
            set
            {
                WriteDataPoint(35, 28, value, -1, _svCountOfSlopeDetections);
            }
        }
        #endregion

        #region Property svSlopeFactor
        protected float _svSlopeFactor = 10;
        public float svSlopeFactor
        {
            get
            {
                return _svSlopeFactor;
            }
            set
            {
                WriteDataPoint(35, 29, value, -1, _svSlopeFactor);
            }
        }
        #endregion

        #region Property acCountOfSlopeDetections
        protected short _acCountOfSlopeDetections = 0;
        public short acCountOfSlopeDetections
        {
            get
            {
                return _acCountOfSlopeDetections;
            }
        }
        #endregion

		#region Name

		public override string Name
		{
			get
			{
				return _svName;
			}
		}

		#endregion

        #endregion

        #region Commands
        public bool cfOnOff()
		{
            if (base.WriteCommand(35, 0x0001, -1, _Status))
            {
                if (!HasStatus(Motan.XNet.LCO.Blendmgr_FCT035.StatusCode.sfOnOff))
                {
                    SetStatus(Motan.XNet.LCO.Blendmgr_FCT035.StatusCode.sfOnOff, true);
                }
                else
                {
                    SetStatus(Motan.XNet.LCO.Blendmgr_FCT035.StatusCode.sfOnOff, false);
                }
                return true;
            }
            else
            {
                return false;
            }
		}


		public bool cfResetTotals()
		{
			return base.WriteCommand(35,0x0010,-1,_Status);
		}

		public bool cfMixerOnOff()
		{
			return base.WriteCommand(35,0x0020,-1,_Status);
		}

		public bool cfMixerNonStopOperationOnOff()
		{
			return base.WriteCommand(35,0x0040,-1,_Status);
		}

        public bool cfThrgptRampPlus()
        {
            return base.WriteCommand(35, 0x0100, -1, _Status);
        }

        public bool cfThrgptRampMinus()
        {
            return base.WriteCommand(35, 0x0200, -1, _Status);
        }

        public bool cfSimulationOnOff()
        {
            return base.WriteCommand(35, 0x1000, -1, _Status);
        }

        public bool cfCalcualteOffset()
        {
            return base.WriteCommand(35, 0x4000, -1, _Status);
        }
        public bool cfAutoReduceSensivity()
        {
            return base.WriteCommand(35, 0x8000, -1, _Status);
        }


		#endregion

		#region Factories			
		public Blendmgr_FCT035(ControlNode cn, byte lconr):base(cn,lconr) 
		{
	    }
		#endregion

        #region NewTrend_Aktiv
        private bool _NewTrend_Aktiv = false;
        public bool NewTrend_Aktiv
        {
            get { return _NewTrend_Aktiv; }
            set { _NewTrend_Aktiv = value; }
        }
        #endregion

		#region The Update Method
        public override bool UpdateParser(XNetMessage msg_reply)
        {
            byte _stuffbyte;

            NewTrend_Aktiv = false;

            if (msg_reply.Data.Length >= 146)
            {
                msg_reply.Parse(out _acMsgVersion, 142);
                if (_acMsgVersion == 0x220312)
                {
                    if (msg_reply.Data.Length == 192)
                    {
                        msg_reply.Parse(out _Alarm);
                        msg_reply.Parse(out _Status);
                        msg_reply.Parse(ref _svName);						//	svName:								ARRAY [0..3] OF BYTE:=
                        msg_reply.Parse(out _svDosingTime);					//	svDosingTime:						DINT;			(*W002
                        msg_reply.Parse(out _svThroughput);				//	svThroughput:						DINT;			(*W003
                        msg_reply.Parse(out _svShotWeight);					//	svShotWeight:						DINT;			(*W004
                        msg_reply.Parse(out _svProcessTechnique);			//	svProcessTechnique:					WORD;			(*W005
                        msg_reply.Parse(out _stuffbyte);
                        msg_reply.Parse(out _svGuidevalX1);					//	svGuidevalXmax:						DINT:=100;		(*W006				
                        msg_reply.Parse(out _svGuidevalY1);				//	svGuidevalYmax:						DINT:=1000;		(*W007
                        msg_reply.Parse(out _svGuidevalX2);					//	svGuidevalXmin:						DINT:=0;		(*W008
                        msg_reply.Parse(out _svGuidevalY2);				//	svGuidevalYmin:						DINT:=1000;		(*W009
                        msg_reply.Parse(out _svTypMainComp);				//	svTypMainComp:						DWORD;			(*W010
                        msg_reply.Parse(ref _svOrderNumber);				//	svOrderNumber:						ARRAY[0..7]	OF BYTE:=4
                        msg_reply.Parse(out _svMixerRunOnTime);				//	svMixerRunOnTime:					INT;			(*W012
                        msg_reply.Parse(out _svCtctMde);					//	svCtctMde:							WORD;			(*W013
                        msg_reply.Parse(out _svRecipeNumber);				//	svRecipeNumber:						INT:=0;			(*W014

                        msg_reply.Parse(out _acDosingTime);					//	acDosingTime:						DINT;			(* -  ;R1
                        msg_reply.Parse(out _acThroughput);					//	acThroughput:						DINT;			(* -  ;R1
                        msg_reply.Parse(out _acGuideVal);					//	acGuideVal:							DINT;			(* -  ;R1
                        msg_reply.Parse(out _acRelThroughput);					//	acRelThroughput:					DINT;			(* -  ;R1			
                        msg_reply.Parse(out _acScaleNumber);					//	acAnzahlShots:						DINT;			(* -  ;R1
                        msg_reply.Parse(out _acGesamtgewicht);				//	acGesamtgewicht:					DINT:=0;		(* -  ;R1
                        msg_reply.Parse(out _acOldTotals1);					//	acOldTotals: 						ARRAY [0..3] OF DINT:=4(0
                        msg_reply.Parse(out _acOldTotals2);
                        msg_reply.Parse(out _acOldTotals3);
                        msg_reply.Parse(out _acOldTotals4);
                        msg_reply.Parse(out _acOldDates1);					//	acOldDates: 						ARRAY [0..3] OF TByteArr;			
                        msg_reply.Parse(out _acOldDates2);
                        msg_reply.Parse(out _acOldDates3);
                        msg_reply.Parse(out _acOldDates4);
                        msg_reply.Parse(out _acTotalTimeExtrusion);			//	acTotalTimeExtrusion:				DINT;			(* -  ;R1		
                        msg_reply.Parse(ref _acOrderNumber);				//	acOrderNumber:						ARRAY[0..7] OF BYTE:=45,4
                        msg_reply.Parse(out _acRecipeType);					//	acUnitType:					INT;			(* -  ;R1
                        msg_reply.Parse(out _acRecipeNumber);				//	acRecipeNumber:						INT:=0;			(* -  ;R1
                        msg_reply.Parse(out _acMsgVersion);					//	DINT:=16#170911;	(*Wxxx;Rxxx;Messageversion ;si=;factor=1;enum=;bits=;range=*)
                        msg_reply.Parse(out _svAdaptRange);					//	INT:=0;			(* prozentuale Anpassung der Dosierzeitadatption ;1;%; *)
                        msg_reply.Parse(out _svExtTolerance);				//	DINT;			(*W002;R072;Schrittweite Totzeit Niveaureg		;0.1;% *)
                        msg_reply.Parse(out _svVariant);				//	INT:=0;			(*W002;R072;Berechnungsvariante	;;[1=%,2=%HKB,3=Anteile] *)
                        msg_reply.Parse(out _svMainComp);					//	INT:=1;			(*W002;R072;Nummer Hauptkomponente		;; *)
                        msg_reply.Parse(out _acLevel);
                        msg_reply.Parse(out _acCalculatedSetThroughput);
                        msg_reply.Parse(out _svlevelsetpoint);
                        msg_reply.Parse(out _svlevelstart);
                        msg_reply.Parse(out _svlevelmin);
                        msg_reply.Parse(out _svlevelmax);
                        msg_reply.Parse(out _svRampStep);
                        msg_reply.Parse(out _svThroughputMan);
                    }
                    else
                    {
                        _acMsgVersion = 0;
                        return false;
                    }
                }
                else if (_acMsgVersion == 0x220216)
                {
                    if (msg_reply.Data.Length == 192)
                    {
                        msg_reply.Parse(out _Alarm);
                        msg_reply.Parse(out _Status);
                        msg_reply.Parse(ref _svName);						//	svName:								ARRAY [0..3] OF BYTE:=
                        msg_reply.Parse(out _svDosingTime);					//	svDosingTime:						DINT;			(*W002
                        msg_reply.Parse(out _svThroughput);				//	svThroughput:						DINT;			(*W003
                        msg_reply.Parse(out _svShotWeight);					//	svShotWeight:						DINT;			(*W004
                        msg_reply.Parse(out _svProcessTechnique);			//	svProcessTechnique:					WORD;			(*W005
                        msg_reply.Parse(out _stuffbyte);
                        msg_reply.Parse(out _svGuidevalX1);					//	svGuidevalXmax:						DINT:=100;		(*W006				
                        msg_reply.Parse(out _svGuidevalY1);				//	svGuidevalYmax:						DINT:=1000;		(*W007
                        msg_reply.Parse(out _svGuidevalX2);					//	svGuidevalXmin:						DINT:=0;		(*W008
                        msg_reply.Parse(out _svGuidevalY2);				//	svGuidevalYmin:						DINT:=1000;		(*W009
                        msg_reply.Parse(out _svTypMainComp);				//	svTypMainComp:						DWORD;			(*W010
                        msg_reply.Parse(ref _svOrderNumber);				//	svOrderNumber:						ARRAY[0..7]	OF BYTE:=4
                        msg_reply.Parse(out _svMixerRunOnTime);				//	svMixerRunOnTime:					INT;			(*W012
                        msg_reply.Parse(out _svCtctMde);					//	svCtctMde:							WORD;			(*W013
                        msg_reply.Parse(out _svRecipeNumber);				//	svRecipeNumber:						INT:=0;			(*W014

                        msg_reply.Parse(out _acDosingTime);					//	acDosingTime:						DINT;			(* -  ;R1
                        msg_reply.Parse(out _acThroughput);					//	acThroughput:						DINT;			(* -  ;R1
                        msg_reply.Parse(out _acGuideVal);					//	acGuideVal:							DINT;			(* -  ;R1
                        msg_reply.Parse(out _acRelThroughput);					//	acRelThroughput:					DINT;			(* -  ;R1			
                        msg_reply.Parse(out _acScaleNumber);					//	acAnzahlShots:						DINT;			(* -  ;R1
                        msg_reply.Parse(out _acGesamtgewicht);				//	acGesamtgewicht:					DINT:=0;		(* -  ;R1
                        msg_reply.Parse(out _acOldTotals1);					//	acOldTotals: 						ARRAY [0..3] OF DINT:=4(0
                        msg_reply.Parse(out _acOldTotals2);
                        msg_reply.Parse(out _acOldTotals3);
                        msg_reply.Parse(out _acOldTotals4);
                        msg_reply.Parse(out _acOldDates1);					//	acOldDates: 						ARRAY [0..3] OF TByteArr;			
                        msg_reply.Parse(out _acOldDates2);
                        msg_reply.Parse(out _acOldDates3);
                        msg_reply.Parse(out _acOldDates4);
                        msg_reply.Parse(out _acTotalTimeExtrusion);			//	acTotalTimeExtrusion:				DINT;			(* -  ;R1		
                        msg_reply.Parse(ref _acOrderNumber);				//	acOrderNumber:						ARRAY[0..7] OF BYTE:=45,4
                        msg_reply.Parse(out _acRecipeType);					//	acUnitType:					INT;			(* -  ;R1
                        msg_reply.Parse(out _acRecipeNumber);				//	acRecipeNumber:						INT:=0;			(* -  ;R1
                        msg_reply.Parse(out _acMsgVersion);					//	DINT:=16#170911;	(*Wxxx;Rxxx;Messageversion ;si=;factor=1;enum=;bits=;range=*)
                        msg_reply.Parse(out _svAdaptRange);					//	INT:=0;			(* prozentuale Anpassung der Dosierzeitadatption ;1;%; *)
                        msg_reply.Parse(out _svExtTolerance);				//	DINT;			(*W002;R072;Schrittweite Totzeit Niveaureg		;0.1;% *)
                        msg_reply.Parse(out _svVariant);				//	INT:=0;			(*W002;R072;Berechnungsvariante	;;[1=%,2=%HKB,3=Anteile] *)
                        msg_reply.Parse(out _svMainComp);					//	INT:=1;			(*W002;R072;Nummer Hauptkomponente		;; *)
                        msg_reply.Parse(out _acLevel);
                        msg_reply.Parse(out _acCalculatedSetThroughput);
                        msg_reply.Parse(out _svlevelsetpoint);
                        msg_reply.Parse(out _svlevelstart);
                        msg_reply.Parse(out _svlevelmin);
                        msg_reply.Parse(out _svlevelmax);
                        msg_reply.Parse(out _svRampStep);
                        msg_reply.Parse(out _svThroughputMan);

                        NewTrend_Aktiv = true;
                    }
                    else
                    {
                        _acMsgVersion = 0;
                        return false;
                    }
                }
                else if (_acMsgVersion == 0x130417)
                {
                    if (msg_reply.Data.Length == 198)
                    {
                        msg_reply.Parse(out _Alarm);
                        msg_reply.Parse(out _Status);
                        msg_reply.Parse(ref _svName);						//	svName:								ARRAY [0..3] OF BYTE:=
                        msg_reply.Parse(out _svDosingTime);					//	svDosingTime:						DINT;			(*W002
                        msg_reply.Parse(out _svThroughput);				//	svThroughput:						DINT;			(*W003
                        msg_reply.Parse(out _svShotWeight);					//	svShotWeight:						DINT;			(*W004
                        msg_reply.Parse(out _svProcessTechnique);			//	svProcessTechnique:					WORD;			(*W005
                        msg_reply.Parse(out _stuffbyte);
                        msg_reply.Parse(out _svGuidevalX1);					//	svGuidevalXmax:						DINT:=100;		(*W006				
                        msg_reply.Parse(out _svGuidevalY1);				//	svGuidevalYmax:						DINT:=1000;		(*W007
                        msg_reply.Parse(out _svGuidevalX2);					//	svGuidevalXmin:						DINT:=0;		(*W008
                        msg_reply.Parse(out _svGuidevalY2);				//	svGuidevalYmin:						DINT:=1000;		(*W009
                        msg_reply.Parse(out _svTypMainComp);				//	svTypMainComp:						DWORD;			(*W010
                        msg_reply.Parse(ref _svOrderNumber);				//	svOrderNumber:						ARRAY[0..7]	OF BYTE:=4
                        msg_reply.Parse(out _svMixerRunOnTime);				//	svMixerRunOnTime:					INT;			(*W012
                        msg_reply.Parse(out _svCtctMde);					//	svCtctMde:							WORD;			(*W013
                        msg_reply.Parse(out _svRecipeNumber);				//	svRecipeNumber:						INT:=0;			(*W014

                        msg_reply.Parse(out _acDosingTime);					//	acDosingTime:						DINT;			(* -  ;R1
                        msg_reply.Parse(out _acThroughput);					//	acThroughput:						DINT;			(* -  ;R1
                        msg_reply.Parse(out _acGuideVal);					//	acGuideVal:							DINT;			(* -  ;R1
                        msg_reply.Parse(out _acRelThroughput);					//	acRelThroughput:					DINT;			(* -  ;R1			
                        msg_reply.Parse(out _acScaleNumber);					//	acAnzahlShots:						DINT;			(* -  ;R1
                        msg_reply.Parse(out _acGesamtgewicht);				//	acGesamtgewicht:					DINT:=0;		(* -  ;R1
                        msg_reply.Parse(out _acOldTotals1);					//	acOldTotals: 						ARRAY [0..3] OF DINT:=4(0
                        msg_reply.Parse(out _acOldTotals2);
                        msg_reply.Parse(out _acOldTotals3);
                        msg_reply.Parse(out _acOldTotals4);
                        msg_reply.Parse(out _acOldDates1);					//	acOldDates: 						ARRAY [0..3] OF TByteArr;			
                        msg_reply.Parse(out _acOldDates2);
                        msg_reply.Parse(out _acOldDates3);
                        msg_reply.Parse(out _acOldDates4);
                        msg_reply.Parse(out _acTotalTimeExtrusion);			//	acTotalTimeExtrusion:				DINT;			(* -  ;R1		
                        msg_reply.Parse(ref _acOrderNumber);				//	acOrderNumber:						ARRAY[0..7] OF BYTE:=45,4
                        msg_reply.Parse(out _acRecipeType);					//	acUnitType:					INT;			(* -  ;R1
                        msg_reply.Parse(out _acRecipeNumber);				//	acRecipeNumber:						INT:=0;			(* -  ;R1
                        msg_reply.Parse(out _acMsgVersion);					//	DINT:=16#170911;	(*Wxxx;Rxxx;Messageversion ;si=;factor=1;enum=;bits=;range=*)
                        msg_reply.Parse(out _svAdaptRange);					//	INT:=0;			(* prozentuale Anpassung der Dosierzeitadatption ;1;%; *)
                        msg_reply.Parse(out _svExtTolerance);				//	DINT;			(*W002;R072;Schrittweite Totzeit Niveaureg		;0.1;% *)
                        msg_reply.Parse(out _svVariant);				//	INT:=0;			(*W002;R072;Berechnungsvariante	;;[1=%,2=%HKB,3=Anteile] *)
                        msg_reply.Parse(out _svMainComp);					//	INT:=1;			(*W002;R072;Nummer Hauptkomponente		;; *)
                        msg_reply.Parse(out _acLevel);
                        msg_reply.Parse(out _acCalculatedSetThroughput);
                        msg_reply.Parse(out _svlevelsetpoint);
                        msg_reply.Parse(out _svlevelstart);
                        msg_reply.Parse(out _svlevelmin);
                        msg_reply.Parse(out _svlevelmax);
                        msg_reply.Parse(out _svRampStep);
                        msg_reply.Parse(out _svThroughputMan);
                        msg_reply.Parse(out _svCountOfSlopeDetections);
                        msg_reply.Parse(out _acCountOfSlopeDetections);
                        msg_reply.Parse(out _svSlopeFactor);

                        NewTrend_Aktiv = true;
                    }
                    else
                    {
                        _acMsgVersion = 0;
                        return false;
                    }
                }
                else
                {
                    _acMsgVersion = 0;
                    return false;
                }


            }
            else
            {
                _acMsgVersion = 0;
                return false;
            }
            return true;
        }

        public override bool Update(bool SyncMsg)
		{
            if (SyncMsg)
            {
                XNetMessage msg_reply = this.ReadDefaultDataSet(35, 142, SyncMsg);
                if (msg_reply == null)
                    return false;

                UpdateParser(msg_reply);
            }
            else
            {
                XNetMessage msg_reply = this.ReadDefaultDataSet(35, 142, SyncMsg);
                return true;
            }
			return true;
		}
		#endregion


        #region Special WriteDataSet 246 Write Setpoints
        #region Parameter f�r WriteDataSet246
        private float[] svPercent = new float[8];
        public float[] _svPercent
        {
            get { return svPercent; }
            set 
            { 
                svPercent = value;
                RecipeType = 1;
            }
        }

        private int[] svParts = new int[8];
        public int[] _svParts
        {
            get { return svParts; }
            set 
            { 
                svParts = value;
            }
        }

        public float getSvParts(int index)
        {
            try
            {
                return ((float)svParts[index]) / 100;
            }
            catch
            {
                return 0;
            }
        }

        public void setSvParts(int index, double value)
        {
            try
            {
                _svParts[index] = (int)(value * 100);
            }
            catch
            {
                return;
            }
        }


        private float[] throughput = new float[8];
        public float[] _throughput
        {
            get { return throughput; }
            set 
            { 
                throughput = value;
            }
        }

        private byte[] Regrind = new byte[8];
        public byte[] _Regrind
        {
            get { return Regrind; }
            set
            {
                Regrind = value;
            }
        }

        private XString RecipeName = new XString(8);
        public string _RecipeName
        {
            get
            {
                return (string) RecipeName;
            }
            set
            {
                RecipeName = new XString(RecipeName.Capacity, value);
            }
        }

        public int RecipeType = 0;
        #endregion

        public bool WriteSetpoints()
        {
            if ((RecipeType <= 0) || (RecipeType > 3))
                return false; 

            DataPresentation dp = CN.DataPresentation;
            byte[] Data = new byte[44];
            byte[] d = ConvertHelper.GetBytes(RecipeType, dp);
            byte[] d1,d2,d3,d4,d5,d6,d7,d8;

            if (RecipeType == 1)
            {
                d1 = ConvertHelper.GetBytes(svPercent[0], dp);
                d2 = ConvertHelper.GetBytes(svPercent[1], dp);
                d3 = ConvertHelper.GetBytes(svPercent[2], dp);
                d4 = ConvertHelper.GetBytes(svPercent[3], dp);
                d5 = ConvertHelper.GetBytes(svPercent[4], dp);
                d6 = ConvertHelper.GetBytes(svPercent[5], dp);
                d7 = ConvertHelper.GetBytes(svPercent[6], dp);
                d8 = ConvertHelper.GetBytes(svPercent[7], dp);
            }
            else if (RecipeType == 2)
            {
                d1 = ConvertHelper.GetBytes(svParts[0], dp);
                d2 = ConvertHelper.GetBytes(svParts[1], dp);
                d3 = ConvertHelper.GetBytes(svParts[2], dp);
                d4 = ConvertHelper.GetBytes(svParts[3], dp);
                d5 = ConvertHelper.GetBytes(svParts[4], dp);
                d6 = ConvertHelper.GetBytes(svParts[5], dp);
                d7 = ConvertHelper.GetBytes(svParts[6], dp);
                d8 = ConvertHelper.GetBytes(svParts[7], dp);
            }
            else
            {
                d1 = ConvertHelper.GetBytes(throughput[0], dp);
                d2 = ConvertHelper.GetBytes(throughput[1], dp);
                d3 = ConvertHelper.GetBytes(throughput[2], dp);
                d4 = ConvertHelper.GetBytes(throughput[3], dp);
                d5 = ConvertHelper.GetBytes(throughput[4], dp);
                d6 = ConvertHelper.GetBytes(throughput[5], dp);
                d7 = ConvertHelper.GetBytes(throughput[6], dp);
                d8 = ConvertHelper.GetBytes(throughput[7], dp);
            }

            d.CopyTo(Data, 0);
            d1.CopyTo(Data, 4);
            d2.CopyTo(Data, 8);
            d3.CopyTo(Data, 12);
            d4.CopyTo(Data, 16);
            d5.CopyTo(Data, 20);
            d6.CopyTo(Data, 24);
            d7.CopyTo(Data, 28);
            d8.CopyTo(Data, 32);
            Data[36] = Regrind[0];
            Data[37] = Regrind[1];
            Data[38] = Regrind[2];
            Data[39] = Regrind[3];
            Data[40] = Regrind[4];
            Data[41] = Regrind[5];
            Data[42] = Regrind[6];
            Data[43] = Regrind[7];
            return WriteDataSet(35, 246, Data, StandardTimeout * 10);
        }
        #endregion

        #region Special ReadDataSet TrendData 247
        #region Parameter f�r WriteDataSet246
        #region Property TrendNr
        private short _TrendNr = 0;
        public short TrendNr
        {
            get
            {
                return _TrendNr;
            }
        }
        #endregion
        #region Property Trendindex
        private short _Trendindex = 0;
        public short Trendindex
        {
            get
            {
                return _Trendindex;
            }
        }
        #endregion

        #region Property Blockindex
        private short _Blockindex = 0;
        public short Blockindex
        {
            get
            {
                return _Blockindex;
            }
        }
        #endregion
        #region Property TrendNr1
        private short _TrendNr1 = 0;
        public short TrendNr1
        {
            get
            {
                return _TrendNr1;
            }
            set
            {
                _TrendNr1 = value;
            }
        }
               #endregion
        #region Property TrendNr2
        private short _TrendNr2 = 0;
        public short TrendNr2
        {
            get
            {
                return _TrendNr2;
            }
            set
            {
                _TrendNr2 = value;
            }
        }
        #endregion
        #region Property TrendNr3
        private short _TrendNr3 = 0;
        public short TrendNr3
        {
            get
            {
                return _TrendNr3;
            }
            set
            {
                _TrendNr3 = value;
            }
        }
        #endregion

        #region Property acValueCurve1
        protected float _acValueCurve1 = 0;
        public float acValueCurve1
        {
            get
            {
                return _acValueCurve1;
            }
        }
        #endregion
        #region Property acValueCurve2
        protected float _acValueCurve2 = 0;
        public float acValueCurve2
        {
            get
            {
                return _acValueCurve2;
            }
        }
        #endregion

        #region Property acValueCurve3
        protected float _acValueCurve3 = 0;
        public float acValueCurve3
        {
            get
            {
                return _acValueCurve3;
            }
        }
        #endregion

        private short[] _Curve_01;
        public short[] Curve_01
        {
            get
            {
                return _Curve_01;
            }
            set
            {
                _Curve_01 = value;
            }
        }

        private short[] _Curve_02;
        public short[] Curve_02
        {
            get
            {
                return _Curve_02;
            }
            set
            {
                _Curve_02 = value;
            }
        }

        private short[] _Curve_03;
        public short[] Curve_03
        {
            get
            {
                return _Curve_03;
            }
            set
            {
                _Curve_03 = value;
            }
        }

        private float[] _Curve_001;
        public float[] Curve_001
        {
            get
            {
                return _Curve_001;
            }
            set
            {
                _Curve_001 = value;
            }
        }

        private float[] _Curve_002;
        public float[] Curve_002
        {
            get
            {
                return _Curve_002;
            }
            set
            {
                _Curve_002 = value;
            }
        }

        private float[] _Curve_003;
        public float[] Curve_003
        {
            get
            {
                return _Curve_003;
            }
            set
            {
                _Curve_003 = value;
            }
        }
        #endregion
        
        public bool GetSingleTrendDataset(short Curve1, short CurveNumber) //1,2 oder 3)
        {
            DataPresentation dp = CN.DataPresentation;
            byte[] Data = new byte[4];
            byte[] d;

            d = ConvertHelper.GetBytes(Curve1, dp);
            d.CopyTo(Data, 0);
            d = ConvertHelper.GetBytes(CurveNumber, dp);
            d.CopyTo(Data, 2);

            XNetMessage msg_reply = ReadDataSet(35, 247, Data, 166);

            if (msg_reply == null)
                return false;
            if (msg_reply.Data.Length == 166)
            {
                msg_reply.Parse(out _TrendNr);
                msg_reply.Parse(out _Trendindex);
                msg_reply.Parse(out _svTimePerDiv);
                msg_reply.Parse(out _svTrendStunde);
                msg_reply.Parse(out _svTrendMinute);

                if (Trendindex == 1)
                {
                    _Curve_01 = new short[75];
                    for (int i = 0; i < _Curve_01.Length; i++)
                        msg_reply.Parse(out _Curve_01[i]);

                    msg_reply.Parse(out _acValueCurve1);
                    TrendNr1 = TrendNr;

                }
                else if (Trendindex == 2)
                {
                    _Curve_02 = new short[75];
                    for (int i = 0; i < _Curve_02.Length; i++)
                        msg_reply.Parse(out _Curve_02[i]);

                    msg_reply.Parse(out _acValueCurve2);
                    TrendNr2 = TrendNr;

                }
                else if (Trendindex == 3)
                {
                    _Curve_03 = new short[75];
                    for (int i = 0; i < _Curve_03.Length; i++)
                        msg_reply.Parse(out _Curve_03[i]);

                    msg_reply.Parse(out _acValueCurve3);
                    TrendNr3 = TrendNr;

                }
                return true;
            }
            else
            {
                return false;
            }
        }

        public bool GetSingleTrendDataset(short Curve1, short CurveNumber,short Blockindex) //1,2 oder 3)
        {
            DataPresentation dp = CN.DataPresentation;
            byte[] Data = new byte[6];
            byte[] d;

            d = ConvertHelper.GetBytes(Curve1, dp);
            d.CopyTo(Data, 0);
            d = ConvertHelper.GetBytes(CurveNumber, dp);
            d.CopyTo(Data, 2);
            d = ConvertHelper.GetBytes(Blockindex, dp);
            d.CopyTo(Data, 4);

            XNetMessage msg_reply = ReadDataSet(35, 248, Data, 166);

            if (msg_reply == null)
                return false;
            if (msg_reply.Data.Length == 166)
            {
                msg_reply.Parse(out _TrendNr);
                msg_reply.Parse(out _Trendindex);
                msg_reply.Parse(out _Blockindex);
                msg_reply.Parse(out _svTimePerDiv);
                msg_reply.Parse(out _svTrendStunde);
                msg_reply.Parse(out _svTrendMinute);

                if (Trendindex == 1)
                {
                    TrendNr1 = TrendNr;

                    if (Blockindex==1)
                    {
                        _Curve_001 = new float[75];
                        for (int i = 0; i < 38; i++)
                            msg_reply.Parse(out _Curve_001[i]);
                    }
                    else
                    {
                        for (int i = 38; i < 75; i++)
                            msg_reply.Parse(out _Curve_001[i]);

                        msg_reply.Parse(out _acValueCurve1);
                    }

                }
                else if (Trendindex == 2)
                {
                    TrendNr2 = TrendNr;

                    if (Blockindex == 1)
                    {
                        _Curve_002 = new float[75];
                        for (int i = 0; i < 38; i++)
                            msg_reply.Parse(out _Curve_002[i]);
                    }
                    else
                    {
                        for (int i = 38; i < 75; i++)
                            msg_reply.Parse(out _Curve_002[i]);

                        msg_reply.Parse(out _acValueCurve2);
                    }

                }
                else if (Trendindex == 3)
                {
                    TrendNr3 = TrendNr;

                    if (Blockindex == 1)
                    {
                        _Curve_003 = new float[75];
                        for (int i = 0; i < 38; i++)
                            msg_reply.Parse(out _Curve_003[i]);
                    }
                    else
                    {
                        for (int i = 38; i < 75; i++)
                            msg_reply.Parse(out _Curve_003[i]);

                        msg_reply.Parse(out _acValueCurve3);
                    }

                }
                return true;
            }
            else
            {
                return false;
            }
        }

        #endregion



    }
}