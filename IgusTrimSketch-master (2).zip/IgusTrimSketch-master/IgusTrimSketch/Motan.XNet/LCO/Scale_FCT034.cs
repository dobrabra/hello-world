/* Functional Description
 *    
 * 
 * 
 */
/* Changes:
 * 
 * 
 * 
 * 
 */
using System;
using System.Collections;

using Motan;
using Motan.XNet;
using Motan.XNet.XNetProtocol;


namespace Motan.XNet.LCO
{
	/// <summary>
	/// LCO f�r eine MCG-Komponente
	/// </summary>
	public class Scale_FCT034:LogicalControlObject
	{
		#region Alarm

		public enum AlarmCode 
		{ 
            afsetTara					    = 0, 
			afsetAddress					= 1, 
			afsetDefault    			    = 2, 
			afgetSerNo					    = 3, 
			afsetNomLoad					= 4, 
			afgetNomLoad					= 5, 
			afsetSignGain					= 6, 
			afgetSignGain					= 7, 	
            afChannel                       = 8,
            afSerialNumberMissing           = 9
		};

		public bool HasAlarm(AlarmCode alarmcode)
		{
			return base.HasAlarm((int) alarmcode);
		}

		#endregion
 
		#region Status
	
		public enum StatusCode
		{
            sfsetTara           = 0,
            sfsetAddress        = 1,
            sfsetDefault        = 2,
            sfgetSerNo          = 3,
            sfsetNomLoad        = 4,
            sfgetNomLoad        = 5,
            sfsetSignGain       = 6,
            sfgetSignGain       = 7,
		};

		public bool HasStatus(StatusCode statuscode)
		{
			return base.HasStatus((int) statuscode);
		}

        public void SetStatus(StatusCode statuscode, bool value)
        {
            base.SetStatus((int)statuscode, value);
        }

		#endregion

		#region Parameter241

        #region svGain
        private float _svGain = 0;
        public float svGain
		{
			get
			{
                return _svGain/100;
			}
			set
			{
                WriteDataPoint(34, 1, value*100, -1, _svGain);
			}
        }
        #endregion 

        #region svTara
        private float _svTara = 0;
        public float svTara
        {
            get
            {
                return   (((float)_svTara)/10);
            }
            set
            {
                WriteDataPoint(34, 2, value*10, -1, _svTara);
            }
        }
        #endregion 

        #region svRes2
        private int _svRes2 = 0;
        public int svRes2
        {
            get
            {
                return _svRes2;
            }
            set
            {
                WriteDataPoint(34, 3, value, -1, _svRes2);
            }
        }
        #endregion 

        #region svName
        private XString _svLcoName = new XString(4);
        public string svLcoName
        {
            get
            {
                return (string)_svLcoName;
            }
            set
            {
                WriteDataPoint(38, 21, new XString(_svLcoName.Capacity, value), -1, new XString(_svLcoName.Capacity, _svLcoName));
            }
        }
        #endregion

        #region acGain
        private float _acGain = 0;
        public float acGain
        {
            get
            {
                return _acGain/100;
            }
        }
        #endregion 

        #region acSerialNumber
        private int _acSerialNumber = 0;
        public int acSerialNumber
        {
            get
            {
                return _acSerialNumber;
            }
        }
        #endregion 

        #region acNominalLoad
        private int _acNominalLoad = 0;
        public int acNominalLoad
        {
            get
            {
                return _acNominalLoad;
            }
        }
        #endregion 

        #region acWeight
        private int _acWeight = 0;
        public float acWeight
        {
            get
            {
                return (((float)_acWeight)/10000);
            }
        }
        #endregion 

        #region acTara
        private float _acTara = 0;
        public float acTara
        {
            get
            {
                return _acTara;
            }
        }
        #endregion 

        #region acRes2
        private int _acRes2 = 0;
        public int acRes2
        {
            get
            {
                return _acRes2;
            }
        }
        #endregion 

 		#region acMsgVersion
		private int _acMsgVersion=0;
		public int acMsgVersion
		{
			get
			{
				return _acMsgVersion;
			}
		}
		#endregion

		#endregion

		#region Name

		public override string Name
		{
			get
			{
				return _svLcoName;
			}
		}

		#endregion

		#region Commands
        public bool cfsetTara()
		{
			if (base.WriteCommand(34,0x0001,-1,_Status))
            {
                SetStatus(Motan.XNet.LCO.Scale_FCT034.StatusCode.sfsetTara, true);
                return true;
            }
            else
            {
                return false;
            }
		}

        public bool cfsetAddress()
        {
            if (base.WriteCommand(34, 0x0002, -1, _Status))
            {
                SetStatus(Motan.XNet.LCO.Scale_FCT034.StatusCode.sfsetAddress, true);
                return true;
            }
            else
            {
                return false;
            }
        }

        public bool cfsetDefault()
        {
            if (base.WriteCommand(34, 0x0004, -1, _Status))
            {
                SetStatus(Motan.XNet.LCO.Scale_FCT034.StatusCode.sfsetDefault, true);
                return true;
            }
            else
            {
                return false;
            }
        }

        public bool cfgetSerNo()
        {
            if (base.WriteCommand(34, 0x0008, -1, _Status))
            {
              SetStatus(Motan.XNet.LCO.Scale_FCT034.StatusCode.sfgetSerNo, true);
              return true;
            }
            else
            {
                return false;
            }
        }

        public bool cfsetNomLoad()
        {
            return base.WriteCommand(34, 0x0010, -1, _Status);
        }

        public bool cfgetNomLoad()
        {
            return base.WriteCommand(34, 0x0020, -1, _Status);
        }

        public bool cfsetSignGain()
        {
            if (base.WriteCommand(34, 0x0040, -1, _Status))
            {
                SetStatus(Motan.XNet.LCO.Scale_FCT034.StatusCode.sfsetSignGain, true);
                return true;
            }
            else
            {
                return false;
            }

        }

        public bool cfgetSignGain()
        {
            if (base.WriteCommand(34, 0x0080, -1, _Status))
            {
                SetStatus(Motan.XNet.LCO.Scale_FCT034.StatusCode.sfgetSignGain, true);
                return true;
            }
            else
            {
                return false;
            }
        }

        public bool cfResetAlarm()
        {
            return base.WriteCommand(34, 0x0100, -1, _Status);
        }
		#endregion

		#region Factories			
        public Scale_FCT034(ControlNode cn, byte lconr)
            : base(cn, lconr) 
		{
	    }
		#endregion

		#region The Update Method
        public override bool UpdateParser(XNetMessage msg_reply)
        {
            if (msg_reply.Data.Length == 48)
            {
                msg_reply.Parse(out _acMsgVersion, 44);
                if (_acMsgVersion == 0x160212)
                {
                    if (msg_reply.Data.Length == 48)
                    {
                        msg_reply.Parse(out _Alarm);
                        msg_reply.Parse(out _Status);
                        msg_reply.Parse(out _svGain);
                        msg_reply.Parse(out _svTara);
                        msg_reply.Parse(out _svRes2);
                        msg_reply.Parse(ref _svLcoName);
                        msg_reply.Parse(out _acGain);
                        msg_reply.Parse(out _acSerialNumber);
                        msg_reply.Parse(out _acNominalLoad);
                        msg_reply.Parse(out _acWeight);
                        msg_reply.Parse(out _acTara);
                        msg_reply.Parse(out _acRes2);
                        msg_reply.Parse(out _acMsgVersion);
                    }
                    else
                    {
                        _acMsgVersion = 0;
                        return false;
                    }
                }
                else
                {
                    _acMsgVersion = 0;
                    return false;
                }
            }
            else
            {
                _acMsgVersion = 0;
                return false;
            }
            return true;
        }

        public override bool Update(bool SyncMsg)
		{
            if (SyncMsg)
            {
                XNetMessage msg_reply = this.ReadDefaultDataSet(34, 48, SyncMsg);
                if (msg_reply == null)
                    return false;

                UpdateParser(msg_reply);
            }
            else
            {
                XNetMessage msg_reply = this.ReadDefaultDataSet(34, 48, SyncMsg);
                return true;
            }
            return true;
		}
		#endregion

		#region ErrorHandling


		#endregion
	}
}