/* Functional Description
 *    
 * 
 * 
 */
/* Changes:
 * 
 * 
 * 
 * 
 */
using System;
using System.Collections;

using Motan;
using Motan.XNet;
using Motan.XNet.XNetProtocol;


namespace Motan.XNet.LCO
{
	/// <summary>
	/// LCO f�r eine backup/Restore Komponente
	/// </summary>
    /// 

    public enum BackupMedium
    { Flash, MemoryStick, StorageCard }

	public class Backup_FCT085:LogicalControlObject
	{
 		#region Alarm

		public enum AlarmCode
        {
            afFileMissing = 0,
            afFilesizeWrong = 1

		};

		public bool HasAlarm(AlarmCode alarmcode)
		{
			return base.HasAlarm((int) alarmcode);
		}

		#endregion
 
		#region Status
	
		public enum StatusCode
		{

            sfstartBackup =  0,
            sfstartRestore = 1,
            sfcheckMedium =  2,
            sfsaveAllSystem = 3,
            sfloadAllSystem = 4,
            sfresetBackup = 5,
            sfcheckLength = 6,
	        sfBusy = 7

		};

		public bool HasStatus(StatusCode statuscode)
		{
			return base.HasStatus((int) statuscode);
		}

		#endregion

		#region Parameter241
        #region Override Name
        private XString _svName = new XString(4);
         public override string Name
        {
            get
            {
                return _svName;
            }
        }

        #endregion

        #region Property acBackupProgress
        private ushort _acBackupProgress = 0;
        public ushort acBackupProgress
        {
            get
            {
                return _acBackupProgress;
            }
        }
        #endregion

        #region Property acRestoreProgress
        private ushort _acRestoreProgress = 0;
        public ushort acRestoreProgress
        {
            get
            {
                return _acRestoreProgress;
            }
        }
        #endregion

        #region Property acSucessfullWritings
        private ushort _acSucessfullWritings = 0;
        public ushort acSucessfullWritings
        {
            get
            {
                return _acSucessfullWritings;
            }
        }
        #endregion

        #region Property acSucessfullReadings
        private ushort _acSucessfullReadings = 0;
        public ushort acSucessfullReadings
        {
            get
            {
                return _acSucessfullReadings;
            }
        }
        #endregion

        #region Property acCountOfBackupFiles
        private ushort _acCountOfBackupFiles = 0;
        public ushort acCountOfBackupFiles
        {
            get
            {
                return _acCountOfBackupFiles;
            }
        }
        #endregion

        #region Property acBackupMedium
        private ushort _acBackupMedium = 0;
        public ushort acBackupMedium
        {
            get
            {
                return _acBackupMedium;
            }
        }
        #endregion

        #region Property acLastErrorStep
        private uint _acLastErrorStep = 0;
        public uint acLastErrorStep
        {
            get
            {
                return _acLastErrorStep;
            }
        }
        #endregion

        #region Property acStatusText
        private ushort _acStatusText = 0;
        public ushort acStatusText
        {
            get
            {
                return _acStatusText;
            }
        }
        #endregion

#endregion


        #region Commands

        public bool cfstartBackup()
        {
            return base.WriteCommand(85, 0x0001, -1, _Status);
        }

        public bool cfstartRestore()
        {
            return base.WriteCommand(85, 0x0002, -1, _Status);
        }

        public bool cfcheckMedium()
        {
            return base.WriteCommand(85, 0x0004, -1, _Status);
        }

        public bool cfsaveAllSystem()
        {
            return base.WriteCommand(85, 0x0008, -1, _Status);
        }

        public bool cfloadAllSystem()
        {
            return base.WriteCommand(85, 0x0010, -1, _Status);
        }

        public bool cfresetBackup()
        {
            return base.WriteCommand(85, 0x0020, -1, _Status);
        }

        public bool cfcheckLength()
        {
            return base.WriteCommand(85, 0x0040, -1, _Status);
        }

		#endregion

		#region Factories			
        public Backup_FCT085(ControlNode cn, byte lconr)
            : base(cn, lconr) 
		{
	    }
		#endregion

		#region The Update Method
        public override bool UpdateParser(XNetMessage msg_reply)
        {
            if (msg_reply.Data.Length >= 24)
            {
               msg_reply.Parse(out _Alarm);
               msg_reply.Parse(out _Status);
               msg_reply.Parse(ref _svName);
               msg_reply.Parse(out _acBackupProgress);
               msg_reply.Parse(out _acRestoreProgress);
               msg_reply.Parse(out _acSucessfullWritings);
               msg_reply.Parse(out _acSucessfullReadings);
               msg_reply.Parse(out _acCountOfBackupFiles);
               msg_reply.Parse(out _acBackupMedium);
               msg_reply.Parse(out _acLastErrorStep);
               msg_reply.Parse(out _acStatusText);
               return true;
             }
              else
                 return false;
        }

        public override bool Update(bool SyncMsg)
		{
            if (SyncMsg)
            {
                XNetMessage msg_reply = this.ReadDefaultDataSet(85, 24, SyncMsg);
                if (msg_reply == null)
                    return false;

                UpdateParser(msg_reply);
            }
            else
            {
                XNetMessage msg_reply = this.ReadDefaultDataSet(85, 24, SyncMsg);
                return true;
            }
			return true;
		}
		#endregion

		#region ErrorHandling


		#endregion
	}
}