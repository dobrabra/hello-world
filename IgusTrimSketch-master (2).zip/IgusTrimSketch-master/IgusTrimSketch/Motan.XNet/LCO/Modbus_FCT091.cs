/* Functional Description
 *    
 * 
 * 
 */
/* Changes:
 * 
 * 
 * 
 * 
 */
using System;
using System.Collections;

using Motan;
using Motan.XNet;
using Motan.XNet.XNetProtocol;


namespace Motan.XNet.LCO
{
	/// <summary>
	/// LCO f�r eine MCG-Komponente
	/// </summary>
    /// 

    public enum ModbusWorkingMode
    { Off, Standard, Dp, Kramaff }

	public class Modbus_FCT091:LogicalControlObject
	{
       private short _dumword =0 ;   


		#region Alarm

		public enum AlarmCode 
		{ 
		};

		public bool HasAlarm(AlarmCode alarmcode)
		{
			return base.HasAlarm((int) alarmcode);
		}

		#endregion
 
		#region Status
	
		public enum StatusCode
		{

            sfHostLifebit = 0,
            sfModbusLifebit = 1,
            sfKonfAutoRak = 2,
            sfKonfStop_bei_Timeout = 3,
            sfKonfCMD_nicht_nullen =4,
            sfRFPnew = 5,
            sfMFPnew = 6,
            sfCLIVEtimeout = 7,
            sfModbusOnOff = 8,
            sfModbusBinExist = 9,
            sfModbusOptionActivated = 10

		};

		public bool HasStatus(StatusCode statuscode)
		{
			return base.HasStatus((int) statuscode);
		}

		#endregion

		#region Parameter241
        #region Override Name
        private XString _svName = new XString(4);
         public override string Name
        {
            get
            {
                return _svName;
            }
        }

        #endregion

        #region Property acMsgVersion
        private int _acMsgVersion = 0;
        public int acMsgVersion
        {
            get
            {
                return _acMsgVersion;
            }
        }
        #endregion

        #region svSS_Typ
        private byte _svSS_Typ = 0;
        public byte svSS_Typ
        {
            get
            {
                return _svSS_Typ;
            }
            set
            {
                WriteDataPoint(91, 1, value, -1, _svSS_Typ);
            }
        }
        #endregion

        #region _svSwapcase
        private byte _svSwapcase = 0;
        public byte svSwapcase
        {
            get
            {
                return _svSwapcase;
            }
            set
            {
                WriteDataPoint(91, 2, value, -1, _svSwapcase);
            }
        }
        #endregion

        #region svSteuVarRegisterNummer
        private Int16 _svSteuVarRegisterNummer = 0;
        public Int16 svSteuVarRegisterNummer
        {
            get
            {
                return _svSteuVarRegisterNummer;
            }
            set
            {
                WriteDataPoint(91, 3, value, -1, _svSteuVarRegisterNummer);
            }
        }
        #endregion

        #region acSteuVarRegisterInhalt
        private Int16 _acSteuVarRegisterInhalt = 0;
        public Int16 acSteuVarRegisterInhalt
        {
            get
            {
                return _acSteuVarRegisterInhalt;
            }
            
        }
        #endregion

        #region acSteuVarFolgeRegisterInhalt
        private Int16 _acSteuVarFolgeRegisterInhalt = 0;
        public Int16 acSteuVarFolgeRegisterInhalt
        {
            get
            {
                return _acSteuVarFolgeRegisterInhalt;
            }

        }
        #endregion

        #region acSteuVarDoppelRegisterInhalt
        private int _acSteuVarDoppelRegisterInhalt = 0;
        public int acSteuVarDoppelRegisterInhalt
        {
            get
            {
                return _acSteuVarDoppelRegisterInhalt;
            }

        }
        #endregion

        #region acSteuVarDoppelReale
        private int _acSteuVarDoppelReale = 0;
        public int acSteuVarDoppelReale
        {
            get
            {
                return _acSteuVarDoppelReale;
            }

        }
        #endregion

        #region acReserve01
        private Int16 _acReserve01 = 0;
        public Int16 acReserve01
        {
            get
            {
                return _acReserve01;
            }

        }
        #endregion

        #region acReserve02
        private int _acReserve02 = 0;
        public int acReserve02
        {
            get
            {
                return _acReserve02;
            }

        }
        #endregion

        #region svMonitor_Feeder
        private Int16 _svMonitor_Feeder = 0;
        public Int16 svMonitor_Feeder
        {
            get
            {
                return _svMonitor_Feeder;
            }
            set
            {
                WriteDataPoint(91, 4, value, -1, _svMonitor_Feeder);
            }
        }
        #endregion

        #region svMonitor_Index
        private Int16 _svMonitor_Index = 0;
        public Int16 svMonitor_Index
        {
            get
            {
                return _svMonitor_Index;
            }
            set
            {
                WriteDataPoint(91, 5, value, -1, _svMonitor_Index);
            }
        }
        #endregion

        #region acReserve03
        private int _acReserve03 = 0;
        public int acReserve03
        {
            get
            {
                return _acReserve03;
            }

        }
        #endregion

        #region acReserve04
        private int _acReserve04 = 0;
        public int acReserve04
        {
            get
            {
                return _acReserve04;
            }

        }
        #endregion

        #region acReserve05
        private int _acReserve05 = 0;
        public int acReserve05
        {
            get
            {
                return _acReserve05;
            }

        }
        #endregion

        #region  acVersionMnemo
        private XString _acVersionMnemo = new XString(8);
        public string acVersionMnemo
        {
            get
            {
                return (string)_acVersionMnemo;
            }
            set
            {
                //WriteDataPoint(35, 1, new XString(_svName.Capacity, value), -1, new XString(_svName.Capacity, _svName));
            }
        }
        #endregion

        #region svDiagRegisterNummer
        private Int16 _svDiagRegisterNummer = 0;
        public Int16 svDiagRegisterNummer
        {
            get
            {
                return _svDiagRegisterNummer;
            }
            set
            {
                WriteDataPoint(91, 6, value, -1, _svDiagRegisterNummer);
            }
        }
        #endregion

        #region acDiagRegisterInhalt_Nminus
        private Int16 _acDiagRegisterInhalt_Nminus = 0;
        public Int16 acDiagRegisterInhalt_Nminus
        {
            get
            {
                return _acDiagRegisterInhalt_Nminus;
            }
        }
        #endregion

        #region acDiagRegisterInhalt
        private Int16 _acDiagRegisterInhalt = 0;
        public Int16 acDiagRegisterInhalt
        {
            get
            {
                return _acDiagRegisterInhalt;
            }
        }
        #endregion

        #region acDiagRegisterInhalt_Nplus
        private Int16 _acDiagRegisterInhalt_Nplus = 0;
        public Int16 acDiagRegisterInhalt_Nplus
        {
            get
            {
                return _acDiagRegisterInhalt_Nplus;
            }
        }
        #endregion

        #region acDiagDoppelRegisterString
        private XString _acDiagDoppelRegisterString = new XString(20);
        public string acDiagDoppelRegisterString
        {
            get
            {
                return _acDiagDoppelRegisterString;
            }
        }
        #endregion

        #region  acDiagMnemo
        private XString _acDiagMnemo = new XString(8);
        public string acDiagMnemo
        {
            get
            {
                return (string)_acDiagMnemo;
            }
        }
        #endregion

        #region  acDiagZugriff
        private XString _acDiagZugriff = new XString(3);
        public string acDiagZugriff
        {
            get
            {
                return (string)_acDiagZugriff;
            }
        }
        #endregion

        #region acDiagFeeder
        private Int16 _acDiagFeeder = 0;
        public Int16 acDiagFeeder
        {
            get
            {
                return _acDiagFeeder;
            }
        }
        #endregion

        #endregion


        #region Commands

        public bool cf01()
		{
			return base.WriteCommand(91,0x0001,-1,_Status);
		}

		#endregion

		#region Factories			
        public Modbus_FCT091(ControlNode cn, byte lconr)
            : base(cn, lconr) 
		{
	    }
		#endregion

		#region The Update Method
        public override bool UpdateParser(XNetMessage msg_reply)
        {
            if (msg_reply.Data.Length >= 10)
            {
                msg_reply.Parse(out _acMsgVersion, 6);
                if (_acMsgVersion == 0x221112)
                {
                        msg_reply.Parse(out _Alarm);
                        msg_reply.Parse(out _Status);
                        msg_reply.Parse(out _svSS_Typ);
                        msg_reply.Parse(out _svSwapcase);
                        msg_reply.Parse(out _acMsgVersion);
                        return true;
                }
                else
                {
                    if (_acMsgVersion == 0x270313)
                    {
                        msg_reply.Parse(out _Alarm);
                        msg_reply.Parse(out _Status);
                        msg_reply.Parse(out _svSS_Typ);
                        msg_reply.Parse(out _svSwapcase);
                        msg_reply.Parse(out _acMsgVersion);
                        msg_reply.Parse(out _dumword);
                        msg_reply.Parse(out _dumword);
                        msg_reply.Parse(out _dumword);
                        msg_reply.Parse(out _dumword);
                        msg_reply.Parse(out _dumword);
                        msg_reply.Parse(out _dumword);
                        msg_reply.Parse(out _dumword);
                        msg_reply.Parse(out _dumword);
                        msg_reply.Parse(out _dumword);
                        msg_reply.Parse(out _dumword);
                        msg_reply.Parse(out _dumword);
                        msg_reply.Parse(out _dumword);
                        msg_reply.Parse(out _dumword);
                        msg_reply.Parse(out _dumword);
                        msg_reply.Parse(out _dumword);
                        msg_reply.Parse(out _dumword);
                        msg_reply.Parse(out _dumword);
                        msg_reply.Parse(out _dumword);
                        msg_reply.Parse(ref _acVersionMnemo);
                        return true;
                    }
                    else
                        if (_acMsgVersion == 0x12052015)
                        {
                            msg_reply.Parse(out _Alarm);
                            msg_reply.Parse(out _Status);
                            msg_reply.Parse(out _svSS_Typ);
                            msg_reply.Parse(out _svSwapcase);
                            msg_reply.Parse(out _acMsgVersion);
                            msg_reply.Parse(out _svSteuVarRegisterNummer);
                            msg_reply.Parse(out _acSteuVarRegisterInhalt);
                            msg_reply.Parse(out _acSteuVarFolgeRegisterInhalt);
                            msg_reply.Parse(out _acSteuVarDoppelRegisterInhalt);
                            msg_reply.Parse(out _acSteuVarDoppelReale);
                            msg_reply.Parse(out _acReserve01);
                            msg_reply.Parse(out _acReserve02);
                            msg_reply.Parse(out _svMonitor_Feeder);
                            msg_reply.Parse(out _svMonitor_Index);
                            msg_reply.Parse(out _acReserve03);
                            msg_reply.Parse(out _acReserve04);
                            msg_reply.Parse(out _acReserve05);
                            msg_reply.Parse(ref _acVersionMnemo);
                            msg_reply.Parse(out _svDiagRegisterNummer);
                            msg_reply.Parse(out _acDiagRegisterInhalt_Nminus);
                            msg_reply.Parse(out _acDiagRegisterInhalt);
                            msg_reply.Parse(out _acDiagRegisterInhalt_Nplus);
                            msg_reply.Parse(ref _acDiagDoppelRegisterString);
                            msg_reply.Parse(ref _acDiagMnemo);
                            msg_reply.Parse(ref _acDiagZugriff);
                            msg_reply.Parse(out _acDiagFeeder);
                            return true;
                        }
                        else
                            return false;
                }
            }
              return false;
        }

        public override bool Update(bool SyncMsg)
		{
            if (SyncMsg)
            {
                XNetMessage msg_reply = this.ReadDefaultDataSet(91, 8, SyncMsg);
                if (msg_reply == null)
                    return false;

                UpdateParser(msg_reply);
            }
            else
            {
                XNetMessage msg_reply = this.ReadDefaultDataSet(91, 8, SyncMsg);
                return true;
            }
			return true;
		}
		#endregion

		#region ErrorHandling


		#endregion
	}
}