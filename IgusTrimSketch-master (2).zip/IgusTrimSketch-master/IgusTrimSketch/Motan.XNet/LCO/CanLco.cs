/* Functional Description
 *    
 * 
 * 
 */
/* Changes:
 * 
 * 
 * 
 * 
 */
using System;
using System.Collections;

using Motan;
using Motan.XNet;
using Motan.XNet.LCO;
using Motan.XNet.XNetProtocol;
using System.Threading;

namespace Motan.XNet.LCO
{
	/// <summary>
	/// LCO f�r einen Trichter
	/// </summary>
	
	public class CanLco : LogicalControlObject
	{

		#region Alarm

		public enum AlarmCode
		{
			afCommonAlarmAllNodes	=0,
			afErrorStartAllNodes	=1,
			afReceiveBufferOverflow	=13,
			afSendBufferOverflow	=14,
			afDeviceFault			=15
		};
		public bool HasAlarm(AlarmCode alarmcode)
		{
			return base.HasAlarm((int) alarmcode);
		}

		#endregion

		#region Status

		public enum StatusCode
		{
			sfSlaveAlarmOn			= 0,
			sfassigned				= 1,
			sfdetected				= 2,
			sfinitialized			= 3,
			sfrun					= 4,
			sfsfAutokonfig_run		= 8,
			sfSendBusy				= 9,
			sfAll_in_Run			= 10,
			sfAll_known				= 11,
			sfInit_run				= 12
		};

		public bool HasStatus(StatusCode statuscode)
		{
			return base.HasStatus((int) statuscode);
		}
			
		#endregion

		#region Name

		public override string Name
		{
			get
			{
				return _svName;
			}
		}


		#endregion

		#region Parameter 241
		private short _svNode=0;
		public short svNode
		{
			get
			{
				return _svNode;
			}
			set
			{
				WriteDataPoint(90,1,value,-1,_svNode);
			}
		}
		public void Update_svNode()
		{
			ReadDataPoint(90,71,ref _svNode);
		}
	
		private short _svLco=0;
		public short svLco
		{
			get
			{
				return _svLco;
			}
			set
			{
				WriteDataPoint(90,2,value,-1,_svLco);
			}
		}

		public void Update_svLco()
		{
			ReadDataPoint(90,72,ref _svLco);
		}

        private short _acTyp = 0;
        public short acTyp
        {
            get
            {
                return _acTyp;
            }
        }
        private short _svTyp = 0;
        public short svTyp
        {
            get
            {
                return _svTyp;
            }
            set
            {
                WriteDataPoint(90, 4, value, -1, _svTyp);
            }
        }

		public void Update_svTyp()
		{
			ReadDataPoint(90,74,ref _svTyp);
		}

		private short _svLCOatPort=0;
		public short svLCOatPort
		{
			get
			{
				return _svLCOatPort;
			}
			set
			{
				WriteDataPoint(90,5,value,-1,_svLCOatPort);
			}
		}

		public void Update_svLCOatPort()
		{
			ReadDataPoint(90,75,ref _svLCOatPort);
		}

		#region svName
		private XString _svName=new XString(4);
		public string svName
		{
			get
			{
				return (string)_svName;
			}
			set
			{
				WriteDataPoint(90,14, new XString(_svName.Capacity, value),-1,new XString(_svName.Capacity, _svName));
			}
		}
		public void Update_svName()
		{
			ReadDataPoint(90,84,ref _svName);
		}
		#endregion

	
		private short _acState=0;
		public short acState
		{
			get
			{
				return _acState;
			}			
		}
	
		private short _acPdoNr=0;
		public short acPdoNr
		{
			get
			{
				return _acPdoNr;
			}			
		}

		private short _acRawPdoIn1=0;
		public short acRawPdoIn1
		{
			get
			{
				return _acRawPdoIn1;
			}			
		}

		private short _acRawPdoIn2=0;
		public short acRawPdoIn2
		{
			get
			{
				return _acRawPdoIn2;
			}			
		}

		private short _acRawPdoIn3=0;
		public short acRawPdoIn3
		{
			get
			{
				return _acRawPdoIn3;
			}			
		}
		private short _acRawPdoIn4=0;
		public short acRawPdoIn4
		{
			get
			{
				return _acRawPdoIn4;
			}			
		}


		private int _acEmcyValue=0;
		public int acEmcyValue
		{
			get
			{
				return _acEmcyValue;
			}			
		}
		
		private short _acRead=0;
		public short acRead
		{
			get
			{
				return _acRead;
			}			
		}

		private short _acSend=0;
		public short acSend
		{
			get
			{
				return _acSend;
			}			
		}

		private int _acVendorID=0;
		public int acVendorID
		{
			get
			{
				return _acVendorID;
			}			
		}

		private int _acFirmware=0;
		public int acFirmware
		{
			get
			{
				return _acFirmware;
			}			
		}

		private short _acNodeFaults=0;
		public short acNodeFaults
		{
			get
			{
				return _acNodeFaults;
			}			
		}

		private int _acConfigured1;
		public int acConfigured1
		{
			get
			{
				return _acConfigured1;
			}			
		}

		private int _acConfigured2;
		public int acConfigured2
		{
			get
			{
				return _acConfigured2;
			}			
		}

		private byte[] _acStateOverview = new byte[52];	
		public byte this[int index]
		{
			get
			{
				return (_acStateOverview[index]);
			
			}
		}

		private short _acLcoTyp=0;
		public short acLcoTyp
		{
			get
			{
				return _acLcoTyp;
			}			
		}
		private short _acNodeTyp=0;
		public short acNodeTyp
		{
			get
			{
				return _acNodeTyp;
			}			
		}

		private short _acNodeNumber=0;
		public short acNodeNumber
		{
			get
			{
				return _acNodeNumber;
			}			
		}
		private short _acPortNumber=0;
		public short acPortNumber
		{
			get
			{
				return _acPortNumber;
			}			
		}

		#region Property acMsgVersion
		private int _acMsgVersion=0;
		private int MsgVersion=0x081500;
		public int acMsgVersion
		{
			get
			{
				return _acMsgVersion;
			}
		}
		public void Update_acMsgVersion()
		{
			ReadDataPoint(90,158,ref _acMsgVersion);//011211
		}
		#endregion


		
		private short _res1=0;
		public short res1
		{
			get
			{
				return _res1;
			}			
		}


		private byte[] _acPortAllocation = new byte[16];	
		public byte getPortAllocation(int index)
		{
			if ((index>=0) && (index<17)) 
				return (_acPortAllocation[index]);
			else
				return 0;
		}
		#endregion
	
		#region Commands
		public void OnOffAlrm()
		{
			base.WriteCommand(90,0x0001,-1,_Status);
		}
		
		public void ResetAllNodeAlarms()
		{
			base.WriteCommand(90,0x0002,-1,_Status);
		}

		public void NodeReset()
		{
			base.WriteCommand(90,0x0004,-1,_Status);
		}

		public void ResetAlrm()
		{
			base.WriteCommand(90,0x0008,-1,_Status);
		}
		public void ReadFW()
		{
			base.WriteCommand(90,0x0010,-1,_Status);
		}
		public void ReadVendor()
		{
			base.WriteCommand(90,0x0020,-1,_Status);
		}
		public void ResetLco()
		{
			base.WriteCommand(90,0x0040,-1,_Status);
		}
		public void OnOffAssign()
		{
			base.WriteCommand(90,0x0080,-1,_Status);
		}

		public void ReadPdoNext()
		{
			base.WriteCommand(90,0x0100,-1,_Status);
		}
		public void ResetBus()
		{
			base.WriteCommand(90,0x1000,-1,_Status);
		}
		public void ResetAllNodes()
		{
			base.WriteCommand(90,0x2000,-1,_Status);
		}
		public void StartAutoCfg()
		{
			base.WriteCommand(90,0x4000,-1,_Status);
		}
		public void NodeCfgChanged()
		{
			base.WriteCommand(90,0x8000,-1,_Status);
		}
		
		#endregion

		#region Factories			
		public CanLco(ControlNode cn, byte lconr):base(cn,lconr) 
		{
		}
		#endregion

		#region The Update Method
 
        public override bool UpdateParser(XNetMessage msg_reply)
        {
            if (msg_reply.Data.Length == 136)
            {
                msg_reply.Parse(out _Alarm);
                msg_reply.Parse(out _Status);
                msg_reply.Parse(out _svNode);
                msg_reply.Parse(out _svLco);
                msg_reply.Parse(out _res1);
                msg_reply.Parse(out _svTyp);
                msg_reply.Parse(out _svLCOatPort);
                msg_reply.Parse(out _res1);
                msg_reply.Parse(out _res1);
                msg_reply.Parse(out _res1);
                msg_reply.Parse(out _res1);
                msg_reply.Parse(out _res1);
                msg_reply.Parse(out _res1);
                msg_reply.Parse(out _res1);
                msg_reply.Parse(out _res1);
                msg_reply.Parse(ref _svName);
                msg_reply.Parse(out _acState);
                msg_reply.Parse(out _acPdoNr);
                msg_reply.Parse(out _acRawPdoIn1);
                msg_reply.Parse(out _acRawPdoIn2);
                msg_reply.Parse(out _acRawPdoIn3);
                msg_reply.Parse(out _acRawPdoIn4);
                msg_reply.Parse(out _res1);
                msg_reply.Parse(out _acEmcyValue);
                msg_reply.Parse(out _acRead);
                msg_reply.Parse(out _acSend);
                msg_reply.Parse(out _res1);
                msg_reply.Parse(out _acVendorID);
                msg_reply.Parse(out _acFirmware);
                msg_reply.Parse(out _acNodeFaults);
                msg_reply.Parse(out _acConfigured1);
                msg_reply.Parse(out _acConfigured2);
                msg_reply.Parse(ref _acStateOverview);
                msg_reply.Parse(out _acLcoTyp);
                msg_reply.Parse(out _acNodeTyp);
                msg_reply.Parse(out _acNodeNumber);
                msg_reply.Parse(out _acPortNumber);
            }
            else if (msg_reply.Data.Length >= 140)
            {
                msg_reply.Parse(out _acMsgVersion, 136);
                if (_acMsgVersion == 0x011211)
                {
                    if (msg_reply.Data.Length == 140)
                    {
                        msg_reply.Parse(out _Alarm);
                        msg_reply.Parse(out _Status);
                        msg_reply.Parse(out _svNode);
                        msg_reply.Parse(out _svLco);
                        msg_reply.Parse(out _res1);
                        msg_reply.Parse(out _svTyp);
                        msg_reply.Parse(out _svLCOatPort);
                        msg_reply.Parse(out _res1);
                        msg_reply.Parse(out _res1);
                        msg_reply.Parse(out _res1);
                        msg_reply.Parse(out _res1);
                        msg_reply.Parse(out _res1);
                        msg_reply.Parse(out _res1);
                        msg_reply.Parse(out _res1);
                        msg_reply.Parse(out _res1);
                        msg_reply.Parse(ref _svName);
                        msg_reply.Parse(out _acState);
                        msg_reply.Parse(out _acPdoNr);
                        msg_reply.Parse(out _acRawPdoIn1);
                        msg_reply.Parse(out _acRawPdoIn2);
                        msg_reply.Parse(out _acRawPdoIn3);
                        msg_reply.Parse(out _acRawPdoIn4);
                        msg_reply.Parse(out _res1);
                        msg_reply.Parse(out _acEmcyValue);
                        msg_reply.Parse(out _acRead);
                        msg_reply.Parse(out _acSend);
                        msg_reply.Parse(out _res1);
                        msg_reply.Parse(out _acVendorID);
                        msg_reply.Parse(out _acFirmware);
                        msg_reply.Parse(out _acNodeFaults);
                        msg_reply.Parse(out _acConfigured1);
                        msg_reply.Parse(out _acConfigured2);
                        msg_reply.Parse(ref _acStateOverview);
                        msg_reply.Parse(out _acLcoTyp);
                        msg_reply.Parse(out _acNodeTyp);
                        msg_reply.Parse(out _acNodeNumber);
                        msg_reply.Parse(out _acPortNumber);
                        msg_reply.Parse(out _acMsgVersion);
                    }
                    else
                    {
                        _acMsgVersion = 0;
                        return false;
                    }
                }
                else
                {
                    _acMsgVersion = 0;
                    return false;
                }
            }
            else
            {
                _acMsgVersion = 0;
                return false;
            }

            //Hashtables initialisieren, wenn der Typ sich �ndert
            if (_acMsgVersion != MsgVersion)
            {
                CanNodeTypes.InitializeNames(_acMsgVersion);
                CanNodeTypes.InitializeNodeTypes();
                CanNodeTypes.InitializePortals();
                CanNodeTypes.InitializePrizeListNames();
            }
            return true;
        }
        public override bool Update(bool SyncMsg)
		{
            if (SyncMsg)
            {
                XNetMessage msg_reply = this.ReadDefaultDataSet(90, 136,SyncMsg);
                if (msg_reply == null)
                    return false;

                UpdateParser(msg_reply);
            }
            else
            {
                XNetMessage msg_reply = this.ReadDefaultDataSet(90, 136,SyncMsg);
                return true;
            }



            //if (msg_reply.Data.Length ==136)
            //{
            //    msg_reply.Parse(out _Alarm);
            //    msg_reply.Parse(out _Status);
            //    msg_reply.Parse(out _svNode);
            //    msg_reply.Parse(out _svLco);
            //    msg_reply.Parse(out _res1);
            //    msg_reply.Parse(out _svTyp);
            //    msg_reply.Parse(out _svLCOatPort);
            //    msg_reply.Parse(out _res1);
            //    msg_reply.Parse(out _res1);
            //    msg_reply.Parse(out _res1);
            //    msg_reply.Parse(out _res1);
            //    msg_reply.Parse(out _res1);
            //    msg_reply.Parse(out _res1);
            //    msg_reply.Parse(out _res1);
            //    msg_reply.Parse(out _res1);
            //    msg_reply.Parse(ref _svName);
            //    msg_reply.Parse(out _acState);
            //    msg_reply.Parse(out _acPdoNr);
            //    msg_reply.Parse(out _acRawPdoIn1);
            //    msg_reply.Parse(out _acRawPdoIn2);
            //    msg_reply.Parse(out _acRawPdoIn3);
            //    msg_reply.Parse(out _acRawPdoIn4);
            //    msg_reply.Parse(out _res1);
            //    msg_reply.Parse(out _acEmcyValue);
            //    msg_reply.Parse(out _acRead);
            //    msg_reply.Parse(out _acSend);
            //    msg_reply.Parse(out _res1);
            //    msg_reply.Parse(out _acVendorID);
            //    msg_reply.Parse(out _acFirmware);
            //    msg_reply.Parse(out _acNodeFaults);
            //    msg_reply.Parse(out _acConfigured1);
            //    msg_reply.Parse(out _acConfigured2);
            //    msg_reply.Parse(ref _acStateOverview);
            //    msg_reply.Parse(out _acLcoTyp);
            //    msg_reply.Parse(out _acNodeTyp);
            //    msg_reply.Parse(out _acNodeNumber);
            //    msg_reply.Parse(out _acPortNumber);
            //}		
            //else if (msg_reply.Data.Length >=140)
            //{
            //    msg_reply.Parse(out _acMsgVersion,136);
            //    if (_acMsgVersion == 0x011211)
            //    {
            //        if (msg_reply.Data.Length == 140)

            //        {	
            //            msg_reply.Parse(out _Alarm);
            //            msg_reply.Parse(out _Status);
            //            msg_reply.Parse(out _svNode);
            //            msg_reply.Parse(out _svLco);
            //            msg_reply.Parse(out _res1);
            //            msg_reply.Parse(out _svTyp);
            //            msg_reply.Parse(out _svLCOatPort);
            //            msg_reply.Parse(out _res1);
            //            msg_reply.Parse(out _res1);
            //            msg_reply.Parse(out _res1);
            //            msg_reply.Parse(out _res1);
            //            msg_reply.Parse(out _res1);
            //            msg_reply.Parse(out _res1);
            //            msg_reply.Parse(out _res1);
            //            msg_reply.Parse(out _res1);
            //            msg_reply.Parse(ref _svName);
            //            msg_reply.Parse(out _acState);
            //            msg_reply.Parse(out _acPdoNr);
            //            msg_reply.Parse(out _acRawPdoIn1);
            //            msg_reply.Parse(out _acRawPdoIn2);
            //            msg_reply.Parse(out _acRawPdoIn3);
            //            msg_reply.Parse(out _acRawPdoIn4);
            //            msg_reply.Parse(out _res1);
            //            msg_reply.Parse(out _acEmcyValue);
            //            msg_reply.Parse(out _acRead);
            //            msg_reply.Parse(out _acSend);
            //            msg_reply.Parse(out _res1);
            //            msg_reply.Parse(out _acVendorID);
            //            msg_reply.Parse(out _acFirmware);
            //            msg_reply.Parse(out _acNodeFaults);
            //            msg_reply.Parse(out _acConfigured1);
            //            msg_reply.Parse(out _acConfigured2);
            //            msg_reply.Parse(ref _acStateOverview);
            //            msg_reply.Parse(out _acLcoTyp);
            //            msg_reply.Parse(out _acNodeTyp);
            //            msg_reply.Parse(out _acNodeNumber);
            //            msg_reply.Parse(out _acPortNumber);
            //            msg_reply.Parse(out _acMsgVersion);
            //        }
            //        else
            //        {
            //            _acMsgVersion = 0;
            //            return false;
            //        }
            //    }
            //    else
            //    {
            //        _acMsgVersion = 0;
            //        return false;
            //    }
            //}
            //else
            //{
            //    _acMsgVersion = 0;
            //    return false;
            //}

            ////Hashtables initialisieren, wenn der Typ sich �ndert
            //if (_acMsgVersion!=MsgVersion)
            //{
            //    CanNodeTypes.InitializeNames(_acMsgVersion);
            //    CanNodeTypes.InitializeNodeTypes();
            //    CanNodeTypes.InitializePortals();
            //    CanNodeTypes.InitializePrizeListNames();
            //}

			return true;
		}
		#endregion
		
		#region NodeFaults
		public enum NodeFaults
		{
			af_Reserve_1			=0,
			af_Lifetimeoverflow		=1,
			af_HW_Error				=2,
			af_Reserve_4			=3,
			af_ConfNodeTypFault		=4,
			af_Map_NodeTypFault		=5,
			af_UnitTyp_unknown		=6,
			af_RCDB_missing			=7,
			af_ErrorSend			=8,
			af_ErrorReceive			=9,
			af_Reserve_11			=10,
			af_NodeMissing			=11,
			af_Reserve_13			=12,
			af_Reserve_14			=13,
			af_OverflowReceive		=14,
			af_OverFlowSend			=15

		};


		protected bool HasNodeFault(int nodefaults)
		{
			return (_acNodeFaults & (1 << nodefaults)) != 0x0000;
		}

		public bool HasNodeFaults(NodeFaults nodefaults)
		{
			return this.HasNodeFault((int) nodefaults);
		}

		#endregion

		#region special Read/Write Datasets
		public  bool Update242(short NodeNumber)
		{
			byte[] _dummy1 = new byte[60];
			byte[] _NodeNumber =new byte[2];
			byte[] Senddata;
            byte acTypHi;
            byte acTypLo;

			DataPresentation dp = CN.DataPresentation;
			Senddata=ConvertHelper.GetBytes(NodeNumber,dp);
			Senddata.CopyTo(_NodeNumber,0);
			XNetMessage msg_reply = this.ReadDataSet(90, 242, _NodeNumber ,90,StandardTimeout);
			if(msg_reply==null)
				return false;

			msg_reply.Parse(ref _dummy1);
			msg_reply.Parse(ref _acPortAllocation);
			msg_reply.Parse(out _res1);
			msg_reply.Parse(out _res1);
			msg_reply.Parse(out acTypHi);
            msg_reply.Parse(out acTypLo);
            _acTyp = (short)((short)acTypHi * 256 + (short)acTypLo);
            _svTyp = _acTyp;
			msg_reply.Parse(out _acVendorID);
			msg_reply.Parse(out _acFirmware);




			return true;
		}


		public bool WriteHistoryFilter(canHistFilter Filterdata)
		{
			DataPresentation dp = CN.DataPresentation;
			byte [] Data = new byte[16];
			byte [] d;
			d = ConvertHelper.GetBytes(Filterdata.inNotNode,dp);
			d.CopyTo(Data, 2);
			d = ConvertHelper.GetBytes(Filterdata.inFilterFlags1,dp);
			d.CopyTo(Data, 3);
			d = ConvertHelper.GetBytes(Filterdata.inOnlyNode,dp);
			d.CopyTo(Data, 4);
			d = ConvertHelper.GetBytes(Filterdata.inFilterFlags2,dp);
			d.CopyTo(Data, 5);
			d = ConvertHelper.GetBytes(Filterdata.inBreakpoint,dp);
			d.CopyTo(Data, 7);

			d = ConvertHelper.GetBytes(Filterdata.outNotNode,dp);
			d.CopyTo(Data, 10);
			d = ConvertHelper.GetBytes(Filterdata.outFilterFlags1,dp);
			d.CopyTo(Data, 11);
			d = ConvertHelper.GetBytes(Filterdata.outOnlyNode,dp);
			d.CopyTo(Data, 12);
			d = ConvertHelper.GetBytes(Filterdata.outFilterFlags2,dp);
			d.CopyTo(Data, 13);
			d = ConvertHelper.GetBytes(Filterdata.outBreakpoint,dp);
			d.CopyTo(Data, 15);


			return WriteDataSet(90, 244, Data, StandardTimeout);
		}
		
		public void ReadHistoryIn()
		{
			
			XNetMessage msg_reply = this.ReadDataSet(90, 243, 60,StandardTimeout);

			if(msg_reply== null)
				return ;

			byte[] werte = new byte[60];
			msg_reply.Parse(ref werte);
			CanHistory.InHistory = werte;
		
		}

		public void ReadHistoryOut()
		{
			
			XNetMessage msg_reply = this.ReadDataSet(90, 245, 60,StandardTimeout);

			if(msg_reply== null)
				return ;

			byte[] werte = new byte[60];
			msg_reply.Parse(ref werte);
			CanHistory.OutHistory = werte;
		
		}

		#endregion



	}
	#region CAN History
	public class canHistMsg
	{
		public short Id;
		public byte Dlc;
		public byte[] Data = new byte[8];
		public short idx;
	}

	public class CanHistory
	{
		private static byte[] _InHistory= new byte[60];
		public static byte[] InHistory
			{
				get { return _InHistory;  }
				set { _InHistory = value; }
			}

		private static byte[] _OutHistory= new byte[60];
		public static byte[] OutHistory
		{
			get { return _OutHistory;  }
			set { _OutHistory = value; }
		}

		public static canHistMsg[] getinHistory()
		{
			canHistMsg[] _history = new canHistMsg[5];

			for (int i=0; i<5; i++)
			{
				canHistMsg _msg = new canHistMsg();
				_msg.Id = (short)(InHistory[i*12]*256+InHistory[i*12+1]);
				_msg.Dlc=		(InHistory[i*12+2]);
				_msg.Data[0] =	(InHistory[i*12+3]);
				_msg.Data[1] = (InHistory[i*12+4]);
				_msg.Data[2] = (InHistory[i*12+5]);
				_msg.Data[3] = (InHistory[i*12+6]);
				_msg.Data[4] = (InHistory[i*12+7]);
				_msg.Data[5] = (InHistory[i*12+8]);
				_msg.Data[6] = (InHistory[i*12+9]);
				_msg.Data[7] = (InHistory[i*12+10]);
				_msg.idx = (short)(InHistory[i*12+11]);
				_history[i] = _msg;
			}
			return _history;
		}

		public static canHistMsg[] getoutHistory()
		{
			canHistMsg[] _history = new canHistMsg[5];

			for (int i=0; i<5; i++)
			{
				canHistMsg _msg = new canHistMsg();
				_msg.Id = (short)(OutHistory[i*12]*256+OutHistory[i*12+1]);
				_msg.Dlc=		(OutHistory[i*12+2]);
				_msg.Data[0] =	(OutHistory[i*12+3]);
				_msg.Data[1] =  (OutHistory[i*12+4]);
				_msg.Data[2] =  (OutHistory[i*12+5]);
				_msg.Data[3] =  (OutHistory[i*12+6]);
				_msg.Data[4] =	(OutHistory[i*12+7]);
				_msg.Data[5] =	(OutHistory[i*12+8]);
				_msg.Data[6] =	(OutHistory[i*12+9]);
				_msg.Data[7] =	(OutHistory[i*12+10]);
				_msg.idx = (short)(OutHistory[i*12+11]);
				_history[i] = _msg;
			}
			return _history;
		}


		public CanHistory()
		{
		}

	}

	public class canHistFilter
	{
		public  short inRes1;
		public  byte  inNotNode;
		public  byte  inFilterFlags1;
		public  byte  inOnlyNode;
		public  byte  inFilterFlags2;
		public  byte  inOnlyError;
		public  byte  inBreakpoint;

		public  short outRes1;
		public  byte  outNotNode;
		public  byte  outFilterFlags1;
		public  byte  outOnlyNode;
		public  byte  outFilterFlags2;
		public  byte  outOnlyError;
		public  byte  outBreakpoint;

	}
	#endregion
}
