/* Functional Description
 *    
 * 
 * 
 */
/* Changes:
 * 
 * 
 * 
 * 
 */
using System;
using System.Collections;

using Motan;
using Motan.XNet;
using Motan.XNet.XNetProtocol;

namespace Motan.XNet.LCO
{
	/// <summary>
	/// SystemLCO von METROnet, LUXORnet, MiniCGnet
	/// </summary>
	public class SystemLCO:LogicalControlObject
	{
		#region Alarm

		public enum AlarmCode
		{
			afAlert_00				= 0,
			DP_BusFault				= 1,
			SetupMissing			= 2,
			DP_PeripheralFault	= 3,
			afAlert_04				= 4,
			afAlert_05				= 5,
			afAlert_06				= 6,
			afAlert_07				= 7,
			DataMissing				= 8, 
			DataToLong				= 9,
			WrongFormat				= 10,
			WrongHeader				= 11,
			WrongWCN					= 12,
			WrongParam				= 13,
			FaultSend				= 14,
			afAlert_15				= 15,
		};


		public bool HasAlarm(AlarmCode alarmcode)
		{
			return base.HasAlarm((int) alarmcode);
		}


		#endregion

		#region Status

		public enum StatusCode
		{
			sfPasswordOK				= 0,
			sfNoteWeekMaintenance	= 1,
			sfNoteYearMaintenance	= 2,
			sfSammelMaintenance		= 6,
			sfSammelAlarm				= 7,
			sfCelsiusTenth				= 8
		};

		public bool HasStatus(StatusCode statuscode)
		{
			return base.HasStatus((int) statuscode);
		}
			
		#endregion

		#region Parameter

		private short _svDummyF01=0;
		public short svDummyF01
		{
			get
			{
				return _svDummyF01;
			}
		}

		
		private short _acDummyF02=0;
		public short acDummyF02
		{
			get
			{
				return _acDummyF02;
			}		
		}


		private short _svLogoutTime=0;
		public short svLogoutTime
		{
			get
			{
				return _svLogoutTime;
			}
			set
			{
				WriteDataPoint(1,2,value,-1,_svLogoutTime);
			}
		}


		private short _acLogoutTime=0;
		public short acLogoutTime
		{
			get
			{
				return _acLogoutTime;
			}			
		}


		private short _svPassword_Config=0;
		public short svPassword_Config
		{
			get
			{
				return _svPassword_Config;
			}
			set
			{
				WriteDataPoint(1,3,value,-1,_svPassword_Config);
			}
		}


	
		private short _acPassword_Config=0;
		public short acPassword_Config
		{
			get
			{
				return _acPassword_Config;
			}			
		}


		private ushort _svHopperStartLCO_Count=0;
		public ushort svHopperStartLCO_Count
		{
			get
			{
				return _svHopperStartLCO_Count;
			}
			set
			{
				WriteDataPoint(1,4,value,-1,_svHopperStartLCO_Count);
			}
		}


		private ushort _acMachineLoaderStartLCO_Count=0;
		public ushort acMachineLoaderStartLCO_Count
		{
			get
			{
				return _acMachineLoaderStartLCO_Count;
			}		
			set
			{
				_acMachineLoaderStartLCO_Count=value;
			}
		}


		private ushort _svBlowerStartLCO_Count=0;
		public ushort svBlowerStartLCO_Count
		{
			get
			{
				return _svBlowerStartLCO_Count;
			}
			set
			{
				WriteDataPoint(1,5,value,-1,_svBlowerStartLCO_Count);
			}
		}


		private ushort _acBlowerStartLCO_Count=0;
		public ushort acBlowerStartLCO_Count
		{
			get
			{
				return _acBlowerStartLCO_Count;
			}		
		}


		private ushort _svBlowerSbStartLCO_Count=0;
		public ushort svBlowerSbStartLCO_Count
		{
			get
			{
				return _svBlowerSbStartLCO_Count;
			}
			set
			{
				WriteDataPoint(1,6,value,-1,_svBlowerSbStartLCO_Count);
			}
		}


		private ushort _acBlowerSbStartLCO_Count=0;
		public ushort acBlowerSbStartLCO_Count
		{
			get
			{
				return _acBlowerSbStartLCO_Count;
			}				
		}


		private ushort _svVacAllocStartLCO_Count=0;
		public ushort svVacAllocStartLCO_Count
		{
			get
			{
				return _svVacAllocStartLCO_Count;
			}
			set
			{
				WriteDataPoint(1,7,value,-1,_svVacAllocStartLCO_Count);
			}
		}


		private ushort _acVacAllocStartLCO_Count=0;
		public ushort acVacAllocStartLCO_Count
		{
			get
			{
				return _acVacAllocStartLCO_Count;
			}				
		}


		private ushort _svBlowerSwitchStartLCO_Count=0;
		public ushort svBlowerSwitchStartLCO_Count
		{
			get
			{
				return _svBlowerSwitchStartLCO_Count;
			}
			set
			{
				WriteDataPoint(1,8,value,-1,_svBlowerSwitchStartLCO_Count);
			}
		}


		private ushort _acBlowerSwitchStartLCO_Count=0;
		public ushort acBlowerSwitchStartLCO_Count
		{
			get
			{
				return _acBlowerSwitchStartLCO_Count;
			}				
		}


	
		private ushort _svLineCouplStartLCO_Count=0;
		public ushort svLineCouplStartLCO_Count
		{
			get
			{
				return _svLineCouplStartLCO_Count;
			}
			set
			{
				WriteDataPoint(1,9,value,-1,_svLineCouplStartLCO_Count);
			}
		}


		private ushort _acLineCouplStartLCO_Count=0;
		public ushort acLineCouplStartLCO_Count
		{
			get
			{
				return _acLineCouplStartLCO_Count;
			}				
		}


		private ushort _svPurgeValveCntrStartLCO_Count=0;
		public ushort svPurgeValveCntrStartLCO_Count
		{
			get
			{
				return _svPurgeValveCntrStartLCO_Count;
			}
			set
			{
				WriteDataPoint(1,10,value,-1,_svPurgeValveCntrStartLCO_Count);
			}
		}


		private ushort _acPurgeValveCntrStartLCO_Count=0;
		public ushort acPurgeValveCntrStartLCO_Count
		{
			get
			{
				return _acPurgeValveCntrStartLCO_Count;
			}				
		}


		private ushort _svMatCouplStartLCO_Count=0;
		public ushort svMatCouplStartLCO_Count
		{
			get
			{
				return _svMatCouplStartLCO_Count;
			}
			set
			{
				WriteDataPoint(1,11,value,-1,_svMatCouplStartLCO_Count);
			}
		}


		private ushort _acMatCouplStartLCO_Count=0;
		public ushort acMatCouplStartLCO_Count
		{
			get
			{
				return _acMatCouplStartLCO_Count;
			}				
		}


		private ushort _svSiloStartLCO_Count=0;
		public ushort svSiloStartLCO_Count
		{
			get
			{
				return _svSiloStartLCO_Count;
			}
			set
			{
				WriteDataPoint(1,12,value,-1,_svSiloStartLCO_Count);
			}
		}


		private ushort _acSiloStartLCO_Count=0;
		public ushort acSiloStartLCO_Count
		{
			get
			{
				return _acSiloStartLCO_Count;
			}				
		}

		private ushort _svDryerStartLCO_Count=0;
		public ushort svDryerStartLCO_Count
		{
			get
			{
				return _svDryerStartLCO_Count;
			}
			set
			{
				WriteDataPoint(1,13,value,-1,_svDryerStartLCO_Count);
			}
		}

		private ushort _acDryerStartLCO_Count=0;
		public ushort acDryerStartLCO_Count
		{
			get
			{
				return _acDryerStartLCO_Count;
			}				
		}

		private ushort _svDryBinStartLCO_Count=0;
		public ushort svDryBinStartLCO_Count
		{
			get
			{
				return _svDryBinStartLCO_Count;
			}
			set
			{
				WriteDataPoint(1,14,value,-1,_svDryBinStartLCO_Count);
			}
		}

		private ushort _acDryBinStartLCO_Count=0;
		public ushort acDryBinStartLCO_Count
		{
			get
			{
				return _acDryBinStartLCO_Count;
			}				
		}

		private ushort _svBinHopperStartLCO_Count=0;
		public ushort svBinHopperStartLCO_Count
		{
			get
			{
				return _svBinHopperStartLCO_Count;
			}
			set
			{
				WriteDataPoint(1,15,value,-1,_svBinHopperStartLCO_Count);
			}
		}

		private ushort _acBinLoaderStartLCO_Count=0;
		public ushort acBinLoaderStartLCO_Count
		{
			get
			{
				return _acBinLoaderStartLCO_Count;
			}				
			set
			{
				_acBinLoaderStartLCO_Count=value;
			}
		}

		private ushort _svMouldConStartLCO_Count=0;
		public ushort svMouldConStartLCO_Count
		{
			get
			{
				return _svMouldConStartLCO_Count;
			}
			set
			{
				WriteDataPoint(1,16,value,-1,_svMouldConStartLCO_Count);
			}
		}

		private ushort _acMouldConStartLCO_Count=0;
		public ushort acMouldConStartLCO_Count
		{
			get
			{
				return _acMouldConStartLCO_Count;
			}				
		}

		private ushort _svRes0StartLCO_Count=0;
		public ushort svRes0StartLCO_Count
		{
			get
			{
				return _svRes0StartLCO_Count;
			}
			set
			{
				WriteDataPoint(1,17,value,-1,_svRes0StartLCO_Count);
			}
		}

		private ushort _acRes0StartLCO_Count=0;
		public ushort acRes0StartLCO_Count
		{
			get
			{
				return _acRes0StartLCO_Count;
			}				
		}

		private ushort _svWeekMaintenance=0;
		public ushort svWeekMaintenance
		{
			get
			{
				return _svWeekMaintenance;
			}
			set
			{
				WriteDataPoint(1,18,value,-1,_svWeekMaintenance);
			}
		}


		private ushort _acWeekMaintenance=0;
		public ushort acWeekMaintenance
		{
			get
			{
				return _acWeekMaintenance;
			}		
		}


		private ushort _svYearMaintenance=0;
		public ushort svYearMaintenance
		{
			get
			{
				return _svYearMaintenance;
			}
			set
			{
				WriteDataPoint(1,19,value,-1,_svYearMaintenance);
			}
		}


		private ushort _acYearMaintenance=0;
		public ushort acYearMaintenance
		{
			get
			{
				return _acYearMaintenance;
			}				
		}


		private ushort _svUnit_Conf=0;
		public ushort svUnit_Conf
		{
			get
			{
				return _svUnit_Conf;
			}
			set
			{
				WriteDataPoint(1,20,value,-1,_svUnit_Conf);
			}		
		}


		private ushort _acUnit_Conf=0;
		public ushort acUnit_Conf
		{
			get
			{
				return _acUnit_Conf;
			}		
		}


		private XString _svSystemName=new XString(4);
		public string svSystemName
		{
			get
			{
				return (string)_svSystemName;
			}
			set
			{
				if ((this.CN.Geraetetyp ==768) || (this.CN.Geraetetyp ==769))
					WriteDataPoint(1,1, new XString(_svSystemName.Capacity, value),-1,new XString(_svSystemName.Capacity, _svSystemName));
				else
					WriteDataPoint(1,21, new XString(_svSystemName.Capacity, value),-1,new XString(_svSystemName.Capacity, _svSystemName));
			}
		}


		private XString _acDummyX22 = new XString(4);
		public string acDummyX22
		{
			get
			{
				return (string)_acDummyX22;
			}
		}


		private DateTime _svDateAndTime=DateTime.Now;
		public DateTime svDateAndTime
		{
			get
			{
				return _svDateAndTime;
			}
			set
			{
				WriteDataPoint(1,22,value,-1,_svDateAndTime);
			}
		}


		private DateTime _acDateAndTime=DateTime.Now;
		public DateTime acDateAndTime
		{
			get
			{
				return _acDateAndTime;
			}			
		}

		private ushort _svMiniColorStartLCO_Count=0;
		public ushort svMiniColorStartLCO_Count
		{
			get
			{
				return _svMiniColorStartLCO_Count;
			}
			set
			{
				WriteDataPoint(1,23,value,-1,_svMiniColorStartLCO_Count);
			}
		}

		private ushort _acMiniColorStartLCO_Count=0;
		public ushort acMiniColorStartLCO_Count
		{
			get
			{
				return _acMiniColorStartLCO_Count;
			}				
		}

		private ushort _svMCGDosageStartLCO_Count=0;
		public ushort svMCGDosageStartLCO_Count
		{
			get
			{
				return _svMCGDosageStartLCO_Count;
			}
			set
			{
				WriteDataPoint(1,24,value,-1,_svMCGDosageStartLCO_Count);
			}
		}

		private ushort _acMCGDosageStartLCO_Count=0;
		public ushort acMCGDosageStartLCO_Count
		{
			get
			{
				return _acMCGDosageStartLCO_Count;
			}				
		}

		private ushort _svGRAVIFlowStartLCO_COUNT=0;
		public ushort svGRAVIFlowStartLCO_COUNT
		{
			get
			{
				return _svGRAVIFlowStartLCO_COUNT;
			}
			set
			{
				WriteDataPoint(1,25,value,-1,_svGRAVIFlowStartLCO_COUNT);
			}
		}

		private ushort _acGRAVIFlowStartLCO_COUNT=0;
		public ushort acGRAVIFlowStartLCO_COUNT
		{
			get
			{
				return _acGRAVIFlowStartLCO_COUNT;
			}				
		}

		private ushort _svRes2StartLCO_Count=0;
		public ushort svRes2StartLCO_Count
		{
			get
			{
				return _svRes2StartLCO_Count;
			}
			set
			{
				WriteDataPoint(1,26,value,-1,_svRes2StartLCO_Count);
			}
		}

		private ushort _acRes2StartLCO_Count=0;
		public ushort acRes2StartLCO_Count
		{
			get
			{
				return _acRes2StartLCO_Count;
			}
        }
        #region Weightscales
        private ushort _svWeightScalesStartLCO_Count = 0;
        public ushort svWeightScalesStartLCO_Count
        {
            get
            {
                return _svWeightScalesStartLCO_Count;
            }
            set
            {
                WriteDataPoint(1, 26, value, -1, _svWeightScalesStartLCO_Count);
            }
        }

        private ushort _acWeightScalesStartLCO_Count = 0;
        public ushort acWeightScalesStartLCO_Count
        {
            get
            {
                return _acWeightScalesStartLCO_Count;
            }
        }
        #endregion
        private ushort _svRes3StartLCO_Count=0;
		public ushort svRes3StartLCO_Count
		{
			get
			{
				return _svRes3StartLCO_Count;
			}
			set
			{
				WriteDataPoint(1,27,value,-1,_svRes3StartLCO_Count);
			}
		}

		private ushort _acRes3StartLCO_Count=0;
		public ushort acRes3StartLCO_Count
		{
			get
			{
				return _acRes3StartLCO_Count;
			}
        }
        #region Motors
        private ushort _svMotorsStartLCO_Count = 0;
        public ushort svMotorsStartLCO_Count
        {
            get
            {
                return _svMotorsStartLCO_Count;
            }
            set
            {
                WriteDataPoint(1, 27, value, -1, _svMotorsStartLCO_Count);
            }
        }

        private ushort _acMotorsStartLCO_Count = 0;
        public ushort acMotorsStartLCO_Count
        {
            get
            {
                return _acMotorsStartLCO_Count;
            }
        }
        #endregion

        private ushort _svRes4StartLCO_Count=0;
		public ushort svRes4StartLCO_Count
		{
			get
			{
				return _svRes4StartLCO_Count;
			}
			set
			{
				WriteDataPoint(1,28,value,-1,_svRes4StartLCO_Count);
			}
		}

		private ushort _acRes4StartLCO_Count=0;
		public ushort acRes4StartLCO_Count
		{
			get
			{
				return _acRes4StartLCO_Count;
			}				
		}

		private ushort _svRes5StartLCO_Count=0;
		public ushort svRes5StartLCO_Count
		{
			get
			{
				return _svRes5StartLCO_Count;
			}
			set
			{
				WriteDataPoint(1,29,value,-1,_svRes5StartLCO_Count);
			}
		}

		private ushort _acRes5StartLCO_Count=0;
		public ushort acRes5StartLCO_Count
		{
			get
			{
				return _acRes5StartLCO_Count;
			}				
		}

		#region Property acMsgVersion
		private int _acMsgVersion=0;
		public int acMsgVersion
		{
			get
			{
				return _acMsgVersion;
			}
		}
		public void Update_acMsgVersion()
		{
			ReadDataPoint(1,170,ref _acMsgVersion);
		}
		#endregion

		private short _svDummyF30=0;
		public short svDummyF30
		{
			get
			{
				return _svDummyF30;
			}
		}

		#region svCommandFlagsTestmodus
		private ushort _svCommandFlagsTestmodus=0;
		public ushort svCommandFlagsTestmodus
		{
			get
			{
				return _svCommandFlagsTestmodus;
			}	
			set
			{
				WriteDataPoint(1,31,value,-1,_svCommandFlagsTestmodus);
			}	
		}
		public void Update_svCommandFlagsTestmodus()
		{
			ReadDataPoint(1,101,ref _svCommandFlagsTestmodus);
		}
		#endregion
		#region acFlagsTestmodus
		private ushort _acFlagsTestmodus=0;
		public ushort acFlagsTestmodus
		{
			get
			{
				return _acFlagsTestmodus;
			}			
		}
		#endregion


        private XString _svNameExt = new XString(16);
        public string svNameExt
        {
            get
            {
                return (string)_svNameExt;
            }
            set
            {
                WriteDataPoint(1, 32, new XString(_svNameExt.Capacity, value), -1, new XString(_svNameExt.Capacity, _svNameExt));
            }
        }

		#endregion

		#region ParameterOldGC

		private uint _acIP_Address=0;
		public uint acIP_Address
		{
			get
			{
				return _acIP_Address;
			}
		}

		private int _acGCMaintCounter=0;
		public int acGCMaintCounter
		{
			get
			{
				return _acGCMaintCounter;
			}
		}

		private int _acGCBatchCounter=0;
		public int acGCBatchCounter
		{
			get
			{
				return _acGCBatchCounter;
			}
		}

		private int _acFCycleCounter=0;
		public int acFCycleCounter
		{
			get
			{
				return _acFCycleCounter;
			}
		}

		private int _acFMaintCounter=0;
		public int acFMaintCounter
		{
			get
			{
				return _acFMaintCounter;
			}
		}
		#endregion

		#region GetSPS Version Parameter
		
		private byte [] _acStandardVersion = new byte[4];	
		public string acStandardVersion
		{
			get
			{

				return (_acStandardVersion[0].ToString()+'.'+_acStandardVersion[1].ToString()+'.'
							+(char)_acStandardVersion[2]+'.'+_acStandardVersion[3].ToString());
				// return (string)_acStandardVersion;
			}
		}
		private XString _acKundenversion=new XString(20);
		public string acKundenversion
		{
			get
			{
				return (string)_acKundenversion;
			}
		}

		private XString _acFirmware=new XString(20);
		public string acFirmware
		{
			get
			{
				return (string)_acFirmware;
			}
		}

		#endregion

		#region Name

		public override string Name
		{
			get
			{
				return _svSystemName;
			}
		}


		#endregion

		#region Commands
		public void Logout()
		{
			base.WriteCommand(1,0x0001,-1,_Status);
		}

		public void ResetWeekMaintenance()
		{
			base.WriteCommand(1,0x0002,-1,_Status);
		}

		public void ResetYearMaintenance()
		{
			base.WriteCommand(1,0x0004,-1,_Status);
		}

		public void HupeQuit()
		{
			base.WriteCommand(1,0x0008,-1,_Status);
		}

		public void RemindMaintenance()
		{
			base.WriteCommand(1, 0x0010,-1,_Status);
		}

		public void ResetMaintenance()
		{
			base.WriteCommand(1, 0x0020,-1,_Status);
		}

		public void Config_Finished()
		{
			base.WriteCommand(1,0x0080,-1,_Status);
		}

		public void CelsiusTenth()
		{
			base.WriteCommand(1,0x0100,-1,_Status);
		}

		public void Ram_To_Rom()
		{
			base.WriteCommand(1,0x4000,-1,_Status);
		}

		#endregion

		#region CommandsOldGC
		public void cfGlobalReset()
		{
			base.WriteCommand(1,0x0001,-1,_Status);
		}

		public void cfQuitMaintenance()
		{
			base.WriteCommand(1,0x0002,-1,_Status);
		}

		public void cfResetMaintenance()
		{
			base.WriteCommand(1,0x0004,-1,_Status);
		}

		public void cfOptionConveying()
		{
			base.WriteCommand(1,0x0008,-1,_Status);
		}

		public void cfConfig6Components()
		{
			base.WriteCommand(1, 0x0010,-1,_Status);
		}

		public void cfOptionStandby()
		{
			base.WriteCommand(1, 0x0020,-1,_Status);
		}

		public void cfHupequit()
		{
			base.WriteCommand(1,0x8000,-1,_Status);
		}
		#endregion

		#region Factories			
		public SystemLCO(ControlNode cn):base(cn,255) //In LuxorNet the system LCO has the number:	255
		{
			StationInfo = new ControlNodeInfo(this);
		}
		#endregion

		#region The Update Method
        public override bool UpdateParser(XNetMessage msg_reply)
        {
            if ((this.CN.Geraetetyp == 768) || (this.CN.Geraetetyp == 769))
            {
                short hfStatus;

                //XNetMessage msg_reply = this.ReadDefaultDataSet(1, 28);
                //if (msg_reply == null)
                //    return false;
                if (msg_reply.Data.Length == 28)
                {
                    msg_reply.Parse(out _Alarm);
                    msg_reply.Parse(out hfStatus);
                    msg_reply.Parse(ref _svSystemName);
                    msg_reply.Parse(out _acIP_Address);
                    msg_reply.Parse(out _acGCMaintCounter);
                    msg_reply.Parse(out _acGCBatchCounter);
                    msg_reply.Parse(out _acFCycleCounter);
                    msg_reply.Parse(out _acFMaintCounter);
                }
                else if (msg_reply.Data.Length == 44)
                {
                    msg_reply.Parse(out _Alarm);
                    msg_reply.Parse(out hfStatus);
                    msg_reply.Parse(ref _svSystemName);
                    msg_reply.Parse(out _acIP_Address);
                    msg_reply.Parse(out _acGCMaintCounter);
                    msg_reply.Parse(out _acGCBatchCounter);
                    msg_reply.Parse(out _acFCycleCounter);
                    msg_reply.Parse(out _acFMaintCounter);
                    msg_reply.Parse(out _svDateAndTime);
                    msg_reply.Parse(out _acDateAndTime);
                }
                else
                {
                    return false;
                }

                //Auswertung Status und Mapping in System.Unitconfig
                if ((hfStatus & 0x04) > 0)//6 Komponenten
                {
                    _svUnit_Conf = (ushort)(0x06);	// 6Komp aktiv
                }
                else
                {
                    _svUnit_Conf = (ushort)(0);	// 6Komp deaktiviert (4Komp)
                }
                if ((hfStatus & 0x02) > 0)//Option Conveying
                {
                    _svUnit_Conf = (ushort)(_svUnit_Conf | 0x0100);	// F�rderung aktiv
                    acMachineLoaderStartLCO_Count = (11 << 8) + 7;
                    acBinLoaderStartLCO_Count = 0;
                }
                else
                {
                    _svUnit_Conf = (ushort)(_svUnit_Conf & 0xFEFF);	// F�rderung deaktiviert
                    acMachineLoaderStartLCO_Count = (11 << 8) + 0;
                    acBinLoaderStartLCO_Count = 0;
                }
                if ((hfStatus & 0x10) > 0)//Option Standby
                {
                    _svUnit_Conf = (ushort)(_svUnit_Conf | 0x0200);	// Standby aktiv
                }
                else
                {
                    _svUnit_Conf = (ushort)(_svUnit_Conf & 0xFDFF);	// Standby deaktiviert
                }
                //Auswertung Sammelalarm und SammelWartung
                if ((hfStatus & 0x40) > 0)//sfSammelMaintenance
                {
                    _Status = (ushort)(0x0040);	// Sammelwartung aktiv
                }
                else
                {
                    _Status = (0);	// Sammelwartung nicht aktiv
                }
                if ((hfStatus & 0x80) > 0)//sfSammelAlarm
                {
                    _Status = (ushort)(_Status | 0x0080);	// SammelAlarm aktiv
                }
                else
                {
                    _Status = (ushort)(_Status & 0xFF7F);	// SammelAlarm aktiv
                }
            }
            else
            {
                //XNetMessage msg_reply = this.ReadDefaultDataSet(1, 108);
                //if (msg_reply == null)
                //    return false;
                if (msg_reply.Data.Length == 108)
                {
                    msg_reply.Parse(out _Alarm);
                    msg_reply.Parse(out _Status);
                    msg_reply.Parse(out _svDummyF01);
                    msg_reply.Parse(out _acDummyF02);
                    msg_reply.Parse(out _svLogoutTime);
                    msg_reply.Parse(out _acLogoutTime);
                    msg_reply.Parse(out _svPassword_Config);
                    msg_reply.Parse(out _acPassword_Config);
                    msg_reply.Parse(out _svHopperStartLCO_Count);
                    msg_reply.Parse(out _acMachineLoaderStartLCO_Count);
                    msg_reply.Parse(out _svBlowerStartLCO_Count);
                    msg_reply.Parse(out _acBlowerStartLCO_Count);
                    msg_reply.Parse(out _svBlowerSbStartLCO_Count);
                    msg_reply.Parse(out _acBlowerSbStartLCO_Count);
                    msg_reply.Parse(out _svVacAllocStartLCO_Count);
                    msg_reply.Parse(out _acVacAllocStartLCO_Count);
                    msg_reply.Parse(out _svBlowerSwitchStartLCO_Count);
                    msg_reply.Parse(out _acBlowerSwitchStartLCO_Count);
                    msg_reply.Parse(out _svLineCouplStartLCO_Count);
                    msg_reply.Parse(out _acLineCouplStartLCO_Count);
                    msg_reply.Parse(out _svPurgeValveCntrStartLCO_Count);
                    msg_reply.Parse(out _acPurgeValveCntrStartLCO_Count);
                    msg_reply.Parse(out _svMatCouplStartLCO_Count);
                    msg_reply.Parse(out _acMatCouplStartLCO_Count);
                    msg_reply.Parse(out _svSiloStartLCO_Count);
                    msg_reply.Parse(out _acSiloStartLCO_Count);
                    msg_reply.Parse(out _svDryerStartLCO_Count);
                    msg_reply.Parse(out _acDryerStartLCO_Count);
                    msg_reply.Parse(out _svDryBinStartLCO_Count);
                    msg_reply.Parse(out _acDryBinStartLCO_Count);
                    msg_reply.Parse(out _svBinHopperStartLCO_Count);
                    msg_reply.Parse(out _acBinLoaderStartLCO_Count);
                    msg_reply.Parse(out _svMouldConStartLCO_Count);
                    msg_reply.Parse(out _acMouldConStartLCO_Count);
                    msg_reply.Parse(out _svRes0StartLCO_Count);
                    msg_reply.Parse(out _acRes0StartLCO_Count);
                    msg_reply.Parse(out _svWeekMaintenance);
                    msg_reply.Parse(out _acWeekMaintenance);
                    msg_reply.Parse(out _svYearMaintenance);
                    msg_reply.Parse(out _acYearMaintenance);
                    msg_reply.Parse(out _svUnit_Conf);
                    msg_reply.Parse(out _acUnit_Conf);
                    msg_reply.Parse(ref _svSystemName);
                    msg_reply.Parse(ref _acDummyX22);
                    msg_reply.Parse(out _svDateAndTime);
                    msg_reply.Parse(out _acDateAndTime);
                }
                else if (msg_reply.Data.Length == 136)
                {
                    msg_reply.Parse(out _Alarm);
                    msg_reply.Parse(out _Status);
                    msg_reply.Parse(out _svDummyF01);
                    msg_reply.Parse(out _acDummyF02);
                    msg_reply.Parse(out _svLogoutTime);
                    msg_reply.Parse(out _acLogoutTime);
                    msg_reply.Parse(out _svPassword_Config);
                    msg_reply.Parse(out _acPassword_Config);
                    msg_reply.Parse(out _svHopperStartLCO_Count);
                    msg_reply.Parse(out _acMachineLoaderStartLCO_Count);
                    msg_reply.Parse(out _svBlowerStartLCO_Count);
                    msg_reply.Parse(out _acBlowerStartLCO_Count);
                    msg_reply.Parse(out _svBlowerSbStartLCO_Count);
                    msg_reply.Parse(out _acBlowerSbStartLCO_Count);
                    msg_reply.Parse(out _svVacAllocStartLCO_Count);
                    msg_reply.Parse(out _acVacAllocStartLCO_Count);
                    msg_reply.Parse(out _svBlowerSwitchStartLCO_Count);
                    msg_reply.Parse(out _acBlowerSwitchStartLCO_Count);
                    msg_reply.Parse(out _svLineCouplStartLCO_Count);
                    msg_reply.Parse(out _acLineCouplStartLCO_Count);
                    msg_reply.Parse(out _svPurgeValveCntrStartLCO_Count);
                    msg_reply.Parse(out _acPurgeValveCntrStartLCO_Count);
                    msg_reply.Parse(out _svMatCouplStartLCO_Count);
                    msg_reply.Parse(out _acMatCouplStartLCO_Count);
                    msg_reply.Parse(out _svSiloStartLCO_Count);
                    msg_reply.Parse(out _acSiloStartLCO_Count);
                    msg_reply.Parse(out _svDryerStartLCO_Count);
                    msg_reply.Parse(out _acDryerStartLCO_Count);
                    msg_reply.Parse(out _svDryBinStartLCO_Count);
                    msg_reply.Parse(out _acDryBinStartLCO_Count);
                    msg_reply.Parse(out _svBinHopperStartLCO_Count);
                    msg_reply.Parse(out _acBinLoaderStartLCO_Count);
                    msg_reply.Parse(out _svMouldConStartLCO_Count);
                    msg_reply.Parse(out _acMouldConStartLCO_Count);
                    msg_reply.Parse(out _svRes0StartLCO_Count);
                    msg_reply.Parse(out _acRes0StartLCO_Count);
                    msg_reply.Parse(out _svWeekMaintenance);
                    msg_reply.Parse(out _acWeekMaintenance);
                    msg_reply.Parse(out _svYearMaintenance);
                    msg_reply.Parse(out _acYearMaintenance);
                    msg_reply.Parse(out _svUnit_Conf);
                    msg_reply.Parse(out _acUnit_Conf);
                    msg_reply.Parse(ref _svSystemName);
                    msg_reply.Parse(ref _acDummyX22);
                    msg_reply.Parse(out _svDateAndTime);
                    msg_reply.Parse(out _acDateAndTime);
                    msg_reply.Parse(out _svMiniColorStartLCO_Count);
                    msg_reply.Parse(out _acMiniColorStartLCO_Count);
                    msg_reply.Parse(out _svMCGDosageStartLCO_Count);
                    msg_reply.Parse(out _acMCGDosageStartLCO_Count);
                    msg_reply.Parse(out _svGRAVIFlowStartLCO_COUNT);
                    msg_reply.Parse(out _acGRAVIFlowStartLCO_COUNT);
                    msg_reply.Parse(out _svRes2StartLCO_Count);
                    msg_reply.Parse(out _acRes2StartLCO_Count);
                    msg_reply.Parse(out _svRes3StartLCO_Count);
                    msg_reply.Parse(out _acRes3StartLCO_Count);
                    msg_reply.Parse(out _svRes4StartLCO_Count);
                    msg_reply.Parse(out _acRes4StartLCO_Count);
                    msg_reply.Parse(out _svRes5StartLCO_Count);
                    msg_reply.Parse(out _acRes5StartLCO_Count);
                }
                else if (msg_reply.Data.Length >= 140)
                {
                    msg_reply.Parse(out _acMsgVersion, 136);
                    if (_acMsgVersion == 0x301111)
                    {
                        if (msg_reply.Data.Length == 146)
                        {
                            msg_reply.Parse(out _Alarm);
                            msg_reply.Parse(out _Status);
                            msg_reply.Parse(out _svDummyF01);
                            msg_reply.Parse(out _acDummyF02);
                            msg_reply.Parse(out _svLogoutTime);
                            msg_reply.Parse(out _acLogoutTime);
                            msg_reply.Parse(out _svPassword_Config);
                            msg_reply.Parse(out _acPassword_Config);
                            msg_reply.Parse(out _svHopperStartLCO_Count);
                            msg_reply.Parse(out _acMachineLoaderStartLCO_Count);
                            msg_reply.Parse(out _svBlowerStartLCO_Count);
                            msg_reply.Parse(out _acBlowerStartLCO_Count);
                            msg_reply.Parse(out _svBlowerSbStartLCO_Count);
                            msg_reply.Parse(out _acBlowerSbStartLCO_Count);
                            msg_reply.Parse(out _svVacAllocStartLCO_Count);
                            msg_reply.Parse(out _acVacAllocStartLCO_Count);
                            msg_reply.Parse(out _svBlowerSwitchStartLCO_Count);
                            msg_reply.Parse(out _acBlowerSwitchStartLCO_Count);
                            msg_reply.Parse(out _svLineCouplStartLCO_Count);
                            msg_reply.Parse(out _acLineCouplStartLCO_Count);
                            msg_reply.Parse(out _svPurgeValveCntrStartLCO_Count);
                            msg_reply.Parse(out _acPurgeValveCntrStartLCO_Count);
                            msg_reply.Parse(out _svMatCouplStartLCO_Count);
                            msg_reply.Parse(out _acMatCouplStartLCO_Count);
                            msg_reply.Parse(out _svSiloStartLCO_Count);
                            msg_reply.Parse(out _acSiloStartLCO_Count);
                            msg_reply.Parse(out _svDryerStartLCO_Count);
                            msg_reply.Parse(out _acDryerStartLCO_Count);
                            msg_reply.Parse(out _svDryBinStartLCO_Count);
                            msg_reply.Parse(out _acDryBinStartLCO_Count);
                            msg_reply.Parse(out _svBinHopperStartLCO_Count);
                            msg_reply.Parse(out _acBinLoaderStartLCO_Count);
                            msg_reply.Parse(out _svMouldConStartLCO_Count);
                            msg_reply.Parse(out _acMouldConStartLCO_Count);
                            msg_reply.Parse(out _svRes0StartLCO_Count);
                            msg_reply.Parse(out _acRes0StartLCO_Count);
                            msg_reply.Parse(out _svWeekMaintenance);
                            msg_reply.Parse(out _acWeekMaintenance);
                            msg_reply.Parse(out _svYearMaintenance);
                            msg_reply.Parse(out _acYearMaintenance);
                            msg_reply.Parse(out _svUnit_Conf);
                            msg_reply.Parse(out _acUnit_Conf);
                            msg_reply.Parse(ref _svSystemName);
                            msg_reply.Parse(ref _acDummyX22);
                            msg_reply.Parse(out _svDateAndTime);
                            msg_reply.Parse(out _acDateAndTime);
                            msg_reply.Parse(out _svMiniColorStartLCO_Count);
                            msg_reply.Parse(out _acMiniColorStartLCO_Count);
                            msg_reply.Parse(out _svMCGDosageStartLCO_Count);
                            msg_reply.Parse(out _acMCGDosageStartLCO_Count);
                            msg_reply.Parse(out _svGRAVIFlowStartLCO_COUNT);
                            msg_reply.Parse(out _acGRAVIFlowStartLCO_COUNT);
                            msg_reply.Parse(out _svRes2StartLCO_Count);
                            msg_reply.Parse(out _acRes2StartLCO_Count);
                            msg_reply.Parse(out _svRes3StartLCO_Count);
                            msg_reply.Parse(out _acRes3StartLCO_Count);
                            msg_reply.Parse(out _svRes4StartLCO_Count);
                            msg_reply.Parse(out _acRes4StartLCO_Count);
                            msg_reply.Parse(out _svRes5StartLCO_Count);
                            msg_reply.Parse(out _acRes5StartLCO_Count);
                            msg_reply.Parse(out _acMsgVersion);
                            msg_reply.Parse(out _svDummyF30);
                            msg_reply.Parse(out _svCommandFlagsTestmodus);
                            msg_reply.Parse(out _acFlagsTestmodus);
                        }
                        else
                        {
                            _acMsgVersion = 0;
                            return false;
                        }
                    }
                    else if (_acMsgVersion == 0x040612)
                    {
                        if (msg_reply.Data.Length == 162)
                        {
                            msg_reply.Parse(out _Alarm);
                            msg_reply.Parse(out _Status);
                            msg_reply.Parse(out _svDummyF01);
                            msg_reply.Parse(out _acDummyF02);
                            msg_reply.Parse(out _svLogoutTime);
                            msg_reply.Parse(out _acLogoutTime);
                            msg_reply.Parse(out _svPassword_Config);
                            msg_reply.Parse(out _acPassword_Config);
                            msg_reply.Parse(out _svHopperStartLCO_Count);
                            msg_reply.Parse(out _acMachineLoaderStartLCO_Count);
                            msg_reply.Parse(out _svBlowerStartLCO_Count);
                            msg_reply.Parse(out _acBlowerStartLCO_Count);
                            msg_reply.Parse(out _svBlowerSbStartLCO_Count);
                            msg_reply.Parse(out _acBlowerSbStartLCO_Count);
                            msg_reply.Parse(out _svVacAllocStartLCO_Count);
                            msg_reply.Parse(out _acVacAllocStartLCO_Count);
                            msg_reply.Parse(out _svBlowerSwitchStartLCO_Count);
                            msg_reply.Parse(out _acBlowerSwitchStartLCO_Count);
                            msg_reply.Parse(out _svLineCouplStartLCO_Count);
                            msg_reply.Parse(out _acLineCouplStartLCO_Count);
                            msg_reply.Parse(out _svPurgeValveCntrStartLCO_Count);
                            msg_reply.Parse(out _acPurgeValveCntrStartLCO_Count);
                            msg_reply.Parse(out _svMatCouplStartLCO_Count);
                            msg_reply.Parse(out _acMatCouplStartLCO_Count);
                            msg_reply.Parse(out _svSiloStartLCO_Count);
                            msg_reply.Parse(out _acSiloStartLCO_Count);
                            msg_reply.Parse(out _svDryerStartLCO_Count);
                            msg_reply.Parse(out _acDryerStartLCO_Count);
                            msg_reply.Parse(out _svDryBinStartLCO_Count);
                            msg_reply.Parse(out _acDryBinStartLCO_Count);
                            msg_reply.Parse(out _svBinHopperStartLCO_Count);
                            msg_reply.Parse(out _acBinLoaderStartLCO_Count);
                            msg_reply.Parse(out _svMouldConStartLCO_Count);
                            msg_reply.Parse(out _acMouldConStartLCO_Count);
                            msg_reply.Parse(out _svRes0StartLCO_Count);
                            msg_reply.Parse(out _acRes0StartLCO_Count);
                            msg_reply.Parse(out _svWeekMaintenance);
                            msg_reply.Parse(out _acWeekMaintenance);
                            msg_reply.Parse(out _svYearMaintenance);
                            msg_reply.Parse(out _acYearMaintenance);
                            msg_reply.Parse(out _svUnit_Conf);
                            msg_reply.Parse(out _acUnit_Conf);
                            msg_reply.Parse(ref _svSystemName);
                            msg_reply.Parse(ref _acDummyX22);
                            msg_reply.Parse(out _svDateAndTime);
                            msg_reply.Parse(out _acDateAndTime);
                            msg_reply.Parse(out _svMiniColorStartLCO_Count);
                            msg_reply.Parse(out _acMiniColorStartLCO_Count);
                            msg_reply.Parse(out _svMCGDosageStartLCO_Count);
                            msg_reply.Parse(out _acMCGDosageStartLCO_Count);
                            msg_reply.Parse(out _svGRAVIFlowStartLCO_COUNT);
                            msg_reply.Parse(out _acGRAVIFlowStartLCO_COUNT);
                            msg_reply.Parse(out _svWeightScalesStartLCO_Count);
                            msg_reply.Parse(out _acWeightScalesStartLCO_Count);
                            msg_reply.Parse(out _svMotorsStartLCO_Count);
                            msg_reply.Parse(out _acMotorsStartLCO_Count);
                            msg_reply.Parse(out _svRes4StartLCO_Count);
                            msg_reply.Parse(out _acRes4StartLCO_Count);
                            msg_reply.Parse(out _svRes5StartLCO_Count);
                            msg_reply.Parse(out _acRes5StartLCO_Count);
                            msg_reply.Parse(out _acMsgVersion);
                            msg_reply.Parse(out _svDummyF30);
                            msg_reply.Parse(out _svCommandFlagsTestmodus);
                            msg_reply.Parse(out _acFlagsTestmodus);
                            msg_reply.Parse(ref _svNameExt);
                        }
                        else
                        {
                            _acMsgVersion = 0;
                            return false;
                        }

                    }
                    else
                    {
                        _acMsgVersion = 0;
                        return false;
                    }
                }
                else
                {
                    _acMsgVersion = 0;
                    return false;
                }
            }
            return true;
        }

        public override bool Update(bool SyncMsg)
		{
            if (SyncMsg)
            {
                XNetMessage msg_reply = this.ReadDefaultDataSet(1, 108, SyncMsg);
                if (msg_reply == null)
                    return false;

                UpdateParser(msg_reply);
            }
            else
            {
                XNetMessage msg_reply = this.ReadDefaultDataSet(1, 108, SyncMsg);
                return true;
            }
            return true;
		}
		#endregion

		#region The GetSPSVersion Method
		public bool GetSPSVersion()
		{
			XNetMessage msg_reply = this.ReadDataSet(1,245,60);
			if(msg_reply==null)
				return false;

			msg_reply.Parse(ref _acStandardVersion);
			msg_reply.Parse(ref _acKundenversion);
			msg_reply.Parse(ref _acFirmware);
			// 16 Byte Reserve ignorieren 061012 by JH
			return true;
		}
		#endregion

		#region Klassendefinition ControlNodeInfo
		
		/// <summary>
		/// ControlNodeInfo
		/// </summary>
		/// <remarks>
		/// <para>242 - WriteSpecialDataSet (Set ControlNodeInfo)</para>
		/// <para>Send :</para>
		/// <list type="table">
		/// <listheader><description>fnct</description><description>sfnc</description><description>len</description><description>datafield</description><description>Type</description><description>datacontent</description></listheader>
		/// <item><description>01</description><description>242</description><description>14</description><description>svStationName</description><description>Str[4]</description><description>alphanumeric + '_'</description></item>
		/// <item><description> </description><description> </description><description> </description><description>svGeraetetyp</description><description>Int16</description><description>[256=LXN; 412=MTN; 768=CLN]</description></item>
		/// <item><description> </description><description> </description><description> </description><description>svPasswordOperator</description><description>Int16</description><description>[1000...9999]; Default=3333</description></item>
		/// <item><description> </description><description> </description><description> </description><description>svPasswordSetter</description><description>Int16</description><description>[1000...9999]; Default=2222</description></item>
		/// <item><description> </description><description> </description><description> </description><description>svPasswordService</description><description>Int16</description><description>[1000...9999]; Default=1111</description></item>
		/// <item><description> </description><description> </description><description> </description><description>svPasswordMotan</description><description>Int16</description><description>[1000...9999]; Default=1967</description></item>
		/// </list>
		/// <para>243 - ReadSpecialDataSet (Get ControlNodeInfo)</para>
		/// <para>Request:</para>
		/// <list type="table">
		/// <listheader><description>fnct</description><description>sfnc</description><description>len</description><description>datafield</description><description>datacontent</description></listheader>
		/// <item><description>01</description><description>243</description><description>0</description><description> </description><description> </description></item>
		/// </list>
		/// <para>Response: Twisted Header + Protocol-Data-Unit</para>
		/// <list type="table">
		/// <listheader><description>fnct</description><description>sfnc</description><description>len</description><description>datafield</description><description>Type</description><description>datacontent</description></listheader>
		/// <item><description>01</description><description>242</description><description>14</description><description>svStationName</description><description>Str[4]</description><description>alphanumeric + '_'</description></item>
		/// <item><description> </description><description> </description><description> </description><description>svGeraetetyp</description><description>Int16</description><description>[256=LXN; 412=MTN; 768=CLN]</description></item>
		/// <item><description> </description><description> </description><description> </description><description>svPasswordOperator</description><description>Int16</description><description>[1000...9999]; Default=3333</description></item>
		/// <item><description> </description><description> </description><description> </description><description>svPasswordSetter</description><description>Int16</description><description>[1000...9999]; Default=2222</description></item>
		/// <item><description> </description><description> </description><description> </description><description>svPasswordService</description><description>Int16</description><description>[1000...9999]; Default=1111</description></item>
		/// <item><description> </description><description> </description><description> </description><description>svPasswordMotan</description><description>Int16</description><description>[1000...9999]; Default=1967</description></item>
		/// </list>
		/// </remarks>
		public class ControlNodeInfo
		{
			private readonly SystemLCO _SystemLCO;

			public ControlNodeInfo(SystemLCO systemlco)
			{
				_SystemLCO = systemlco;
			}

			public ControlNodeInfo(string StationName, short Geraetetyp, short PasswordOperator, short PasswordSetter, short PasswordService, short PasswordMotan)
			{
				_svStationName.Set(StationName);
				_svGeraetetyp = Geraetetyp;
				_svPasswordOperator = PasswordOperator;
				_svPasswordSetter = PasswordSetter;
				_svPasswordService = PasswordService;
				_svPasswordMotan = PasswordMotan;
			}
			
			private XString _svStationName = new XString(4);
			public string svStationName
			{
				get
				{
					return (string)_svStationName;
				}
				set
				{
					_svStationName = new XString(_svStationName.Capacity, value);
					WriteControlNodeInfo();
				}
			}

			private short _svGeraetetyp=0;
			public short svGeraetetyp
			{
				get
				{
					return _svGeraetetyp;
				}
				set
				{
					_svGeraetetyp = value;
					WriteControlNodeInfo();
				}
			}

			private short _svPasswordOperator=0;
			public short svPasswordOperator
			{
				get
				{
					return _svPasswordOperator;
				}
				set
				{
					_svPasswordOperator = value;
					WriteControlNodeInfo();
				}
			}

			private short _svPasswordSetter=0;
			public short svPasswordSetter
			{
				get
				{
					return _svPasswordSetter;
				}
				set
				{
					_svPasswordSetter = value;
					WriteControlNodeInfo();
				}

			}

			private short _svPasswordService=0;
			public short svPasswordService
			{
				get
				{
					return _svPasswordService;
				}
				set
				{
					_svPasswordService = value;
					WriteControlNodeInfo();
				}

			}

			private short _svPasswordMotan=0;
			public short svPasswordMotan
			{
				get
				{
					return _svPasswordMotan;
				}
				set
				{
					_svPasswordMotan = value;
					WriteControlNodeInfo();
				}
			}


			public void Update()
			{
				XNetMessage msg_reply = _SystemLCO.ReadDataSet(1, 243, 14);

				if(msg_reply == null)
					return;

				msg_reply.Parse(ref _svStationName);
				msg_reply.Parse(out _svGeraetetyp);
				msg_reply.Parse(out _svPasswordOperator);
				msg_reply.Parse(out _svPasswordSetter);
				msg_reply.Parse(out _svPasswordService);
				msg_reply.Parse(out _svPasswordMotan);
			}

			private void WriteControlNodeInfo()
			{
				#region Get Data To Write

				DataPresentation dp = _SystemLCO.CN.DataPresentation;

				byte [] Data = new byte[14];
				byte [] d;

				char [] c = svStationName.ToCharArray();

				d = ConvertHelper.GetBytes(_svStationName, dp);
				d.CopyTo(Data, 0);
				d = ConvertHelper.GetBytes(_svGeraetetyp,dp);
				d.CopyTo(Data, 4);
				d = ConvertHelper.GetBytes(_svPasswordOperator,dp);
				d.CopyTo(Data, 6);
				d = ConvertHelper.GetBytes(_svPasswordSetter,dp);
				d.CopyTo(Data, 8);
				d = ConvertHelper.GetBytes(_svPasswordService,dp);
				d.CopyTo(Data, 10);
				d = ConvertHelper.GetBytes(_svPasswordMotan,dp);
				d.CopyTo(Data, 12);

				#endregion

				_SystemLCO.WriteDataSet(1, 242, Data);
			}

		}		

		#endregion

		#region Testmodus und Simulation
		#region Status svTestmode
		public enum svStatusTestMode
		{
			poALML=0,			//alarmlampe
			poALMC=1,			//Alarmkontakt	
			cfTestmodus=15
		};
		protected bool Has_svTestState(int svstate)
		{
			return (_svCommandFlagsTestmodus & (1 << svstate)) != 0x0000;
		}

		public bool Has_svTestStates(svStatusTestMode svstate)
		{
			return this.Has_svTestState((int) svstate);
		}
		#endregion

		#region Status acTestmode
		public enum acStatusTestMode
		{
			sfTestmodus=15,
		};

		protected bool Has_acTestState(int acstate)
		{
			return (_acFlagsTestmodus & (1 << acstate)) != 0x0000;
		}

		public bool Has_acTestStates(acStatusTestMode acstate)
		{
			return this.Has_acTestState((int) acstate);
		}
		#endregion
		#endregion

		public readonly ControlNodeInfo StationInfo;
	}
}
