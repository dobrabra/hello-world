/* Functional Description
 *    
 * 
 * 
 */
/* Changes:
 * 
 * 
 * 
 * 
 */
using System;
using System.Collections;
using Motan;
using Motan.XNet;
using Motan.XNet.XNetProtocol;

namespace Motan.XNet.LCO
{
	public class CanNodeTypes
	{
		public CanNodeTypes()
		{
		}
		public static Hashtable PrizeListName; 
		public static Hashtable NodeTypes; 
		public static Hashtable NodeSubTypName; 
		public static Hashtable Portals; 

		public static ArrayList GetHBTypeList (bool ShowConveyNodes, bool ShowDryingNodes, bool ShowAll)
		{
			ArrayList _Typenames = new ArrayList();

			_Typenames.Add(GetHBName("0"));
			if (ShowConveyNodes || ShowAll)
			{
				_Typenames.Add(GetHBName("16"));//DIO8
				_Typenames.Add(GetHBName("112"));//XIO16
			}
			if (ShowDryingNodes || ShowAll)
			{
				_Typenames.Add(GetHBName("96"));//0927
			}
			if (ShowAll)
			{

			}
			return _Typenames;
		}

		public static ArrayList GetLBTypeList (int HB)
		{
			ArrayList _Typenames = new ArrayList();

			foreach (object key in NodeSubTypName.Keys)
			{
				if ((byte)(((Convert.ToInt16(key.ToString())) & 0xFF00) >> 8) == 0)
				{
					_Typenames.Add(NodeSubTypName[key].ToString());
				}	
			}
			if (HB != 0)
			{
				foreach (object key in NodeSubTypName.Keys)
				{
					if ((byte)(((Convert.ToInt16(key.ToString())) & 0xFF00) >> 8) == HB)
					{
						_Typenames.Add(NodeSubTypName[key].ToString());
					}
				}
			}
		
			return _Typenames;
		}
		public static string GetNodeSubTypeName(string key)
		{
			string return_string;
			if (NodeSubTypName != null && NodeSubTypName.ContainsKey(key))
			{
				return_string = NodeSubTypName[key].ToString();
			}
			else
			{
				return_string = "Special Type";
			}
			return return_string;
		}
		public static string GetPortals(string key)
		{
			string return_string;
//			InitializePortals();
			if (Portals != null && Portals.ContainsKey(key))
			{
				return_string = Portals[key].ToString();
			}
			else
			{
				return_string = "0";
			}
			return return_string;
		}





		public static string GetPrizeListName(string key)
		{
			string return_string;
//			InitializePrizeListNames();
			if (PrizeListName != null && PrizeListName.ContainsKey(key))
			{
				return_string = PrizeListName[key].ToString();
			}
			else
			{
				return_string = "Special Type";
			}
			return return_string;
		}

		public static byte GetLB_Number(string val)
		{
			byte return_val=0;
			if (NodeSubTypName != null && NodeSubTypName.ContainsValue(val))
			{
				foreach (object key in NodeSubTypName.Keys)
				{
					if (NodeSubTypName[key].ToString() == val)
					{
						return_val = (byte)((Convert.ToInt16(key.ToString())& 0x00FF));
						return return_val;
					}
				}
			}
			else
			{
				return_val = 0;
			}
			return return_val;
		}

		public static string GetHBName(string key)
		{
			string return_string;
//			InitializeNodeTypes();
			if (NodeTypes != null && NodeTypes.ContainsKey(key))
			{
				return_string = NodeTypes[key].ToString();
			}
			else
			{
				return_string = "Special Type";
			}
			return return_string;
		}

		public static string GetHBNumber(string val)
		{
			string return_string="";
//			InitializeNodeTypes();
			if (NodeTypes != null && NodeTypes.ContainsValue(val))
			{
				foreach (object key in NodeTypes.Keys)
				{
					if (NodeTypes[key].ToString() == val)
					{
						return_string = key.ToString();
						return return_string;
					}
				}
			}
			else
			{
				return_string = "0";
			}
			return return_string;
		}

		public static void InitializePrizeListNames()
		{
			PrizeListName = new Hashtable();
			PrizeListName.Add("0","---");
			PrizeListName.Add("4097","8PV");
			PrizeListName.Add("4098","4PDU");
			PrizeListName.Add("4112","4HP");
			PrizeListName.Add("4116","2HC1");
			PrizeListName.Add("4120","1HC2");
			PrizeListName.Add("4128","1BF");
			PrizeListName.Add("4136","2AL");
			PrizeListName.Add("24577","1LA");
			PrizeListName.Add("24578","1LBA");
			PrizeListName.Add("28675","2PC");
			PrizeListName.Add("28683","16HP");
			PrizeListName.Add("28684","8HC1");
			PrizeListName.Add("28685","5HCO");
			PrizeListName.Add("28692","CC16");
			PrizeListName.Add("28702","2BV");
			PrizeListName.Add("28722","16PDU");
		}
		public static void InitializeNodeTypes()
		{
			NodeTypes = new Hashtable();
			NodeTypes.Add("0","undefined");
			NodeTypes.Add("16","DIO8");
			NodeTypes.Add("96","927");
			NodeTypes.Add("112","XIO16");
		}
		public static void InitializeNames(int acMsgVersion)
		{
			NodeSubTypName = new Hashtable();
			NodeSubTypName.Add("0","undefined");
			NodeSubTypName.Add("4097","8 PurgeValves");
			NodeSubTypName.Add("4098","4 PowderPurge");
			NodeSubTypName.Add("4112","4 Loader");
			NodeSubTypName.Add("4116","2 Loader");
			NodeSubTypName.Add("4120","1 Loader");
			NodeSubTypName.Add("4128","1 Blower");
			NodeSubTypName.Add("24577","Dryer+SYS-Alarm");
			NodeSubTypName.Add("24578","Bin+BinLoader");
			NodeSubTypName.Add("28675","2 PowderLoader");
			NodeSubTypName.Add("28683","16 Loader");
			NodeSubTypName.Add("28684","8 Loader");
			NodeSubTypName.Add("28685","5 Loader");

			if (acMsgVersion == 0x011211)
			{
				NodeSubTypName.Add("4136","SYS-Alarm");
				NodeSubTypName.Add("28692","CodedCoupling");
				NodeSubTypName.Add("28702","2 FUBlower+SYS-Alarm");
				NodeSubTypName.Add("28722","16 PowderPurge");
			}
		}
		public static void InitializePortals()
		{
			Portals = new Hashtable();
			Portals.Add("0","0");
			Portals.Add("4097","1");
			Portals.Add("4098","1");
			Portals.Add("4112","4");
			Portals.Add("4116","2");
			Portals.Add("4120","1");
			Portals.Add("4128","1");
			Portals.Add("4136","1");
			Portals.Add("8193","1");
			Portals.Add("8194","8");
			Portals.Add("24577","2");
			Portals.Add("24578","2");
			Portals.Add("28675","2");
			Portals.Add("28683","16");
			Portals.Add("28684","8");
			Portals.Add("28685","5");
			Portals.Add("28692","1");
			Portals.Add("28702","3");
			Portals.Add("28722","1");
		}
	}
}
