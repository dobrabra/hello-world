/* Functional Description
 *    
 * 
 * 
 */
/* Changes:
 * 
 * 160330 by MG(3.0.0.0):	Fehlerbild:		AA16041 Daten fehlen
					     	Ursache:		Datensatz wurde im CODESYS erweitert
					     	Abhilfe:		Neue Parameter:
												svPercentBridgeAlarm
												acGravRatio
												Enum Debugflags
												NewFlowrateDetection_Aktiv
											�nderung Parameter:
												svDebugflags
												acStatusTestMode
												svStatusTestMode
											Neue Methode:
												GetCurve()inklusive zus�tzlicher Parameter, siehe region GetCurve
												DeleteCurvePoint(Pointnumber)
											Ge�nderte Methode
											UpdateParser erweitert um Parsing f�r acmsgversion 160216 
					     	Baustein:		DosFeedControl_FCT038.cs
 * 
 * 
 */
using System;
using System.Collections;

using Motan;
using Motan.XNet;
using Motan.XNet.XNetProtocol;


namespace Motan.XNet.LCO
{
	/// <summary>
	/// LCO f�r eine MCG-Komponente
	/// </summary>
	public class DosFeedControl_FCT038:LogicalControlObject
	{
		#region Alarm

		public enum AlarmCode 
		{ 
			afRefillFault					= 0, 
			afThroughputToHigh			    = 1,
			afThroughputToLow				= 2,
			afBinEmpty						= 3,
            afDistWeight                    = 4,
            afCalibr                        = 5,
            afNomThroughputToHigh           = 6,
		};

		public bool HasAlarm(AlarmCode alarmcode)
		{
			return base.HasAlarm((int) alarmcode);
		}

		#endregion
 
		#region Status
	
		public enum StatusCode
		{

			sfOnOff				= 0,
            sfZoneobserverOnOff = 1,
            sfEnabAdjustInitialFF = 3,
            sfRunVolBelowRefillStart = 5,
            sfRefillManual = 6,
			sfRefillActive		= 7,
			sfFeedDetActive		= 8,
            sfDriveOn       =     9,
            sfDistWght          = 10,
			sfStartCalib		= 11,
			sfDischargeActive	= 12,
            sfInSetPointDelay   = 15,
		};

		public bool HasStatus(StatusCode statuscode)
		{
			return base.HasStatus((int) statuscode);
		}

        public void SetStatus(StatusCode statuscode, bool value)
        {
            base.SetStatus((int)statuscode, value);
        }

		#endregion

		#region Parameter241

		private ushort _svWeightOverfilled=0;
		public float svWeightOverfilled
		{
			get
			{
				return (float)(_svWeightOverfilled/100.0);
			}
			set
			{
				WriteDataPoint(38,1,value,-1,_svWeightOverfilled);
			}
		}


		private short  _svPercentOverfilled=0;
		public short svPercentOverfilled
		{
			get
			{
				return _svPercentOverfilled;
			}
			set
			{
				WriteDataPoint(38,2,value,-1,_svPercentOverfilled);
			}
		}
		private short  _svBulkDensity=0;
		public short svBulkDensity
		{
			get
			{
				return _svBulkDensity;
			}
			set
			{
				WriteDataPoint(38,3,value,-1,_svBulkDensity);
			}
		}
		private short  _svAlarmlimitThroughput=0;
		public short svAlarmlimitThroughput
		{
			get
			{
				return _svAlarmlimitThroughput;
			}
			set
			{
                if (WriteDataPoint(38,4,value,-1,_svAlarmlimitThroughput))
                {
                    _svAlarmlimitThroughput = value;
                };
			}
		}
		private short  _svAlarmdelayThroughput=0;
		public short svAlarmdelayThroughput
		{
			get
			{
				return _svAlarmdelayThroughput;
			}
			set
			{
                if (WriteDataPoint(38, 5, value, -1, _svAlarmdelayThroughput))
                {
                    _svAlarmdelayThroughput = value;
                };

			}
		}
		private ushort  _svWeightEmpty=0;
		public float svWeightEmpty
		{
			get
			{
				return (float)(_svWeightEmpty/100.0);
			}
			set
			{
                if (WriteDataPoint(38, 6, value, -1, _svWeightEmpty))
                {
                    _svWeightEmpty = (ushort)(value*100.0);
                };
    		}
		}

		private short  _svPercentEmpty=0;
		public short svPercentEmpty
		{
			get
			{
				return _svPercentEmpty;
			}
			set
			{
				WriteDataPoint(38,7,value,-1,_svPercentEmpty);
			}
		}
		private short  _svWeightMaskingUp=0;
		public short svWeightMaskingUp
		{
			get
			{
				return _svWeightMaskingUp;
			}
			set
			{
				WriteDataPoint(38,8,value,-1,_svWeightMaskingUp);
			}
		}
		private short  _svWeightMaskingDown=0;
		public short svWeightMaskingDown
		{
			get
			{
				return _svWeightMaskingDown;
			}
			set
			{
				WriteDataPoint(38,9,value,-1,_svWeightMaskingDown);
			}
		}
		private ushort  _svWeightRefillStop=0;
		public float svWeightRefillStop
		{
			get
			{
				return (float)(_svWeightRefillStop/100.0);
			}
			set
			{
                if (WriteDataPoint(38, 10, value, -1, _svWeightRefillStop))
                {
                    _svWeightRefillStop = (ushort)(value*100.0);
                };
			}
		}
		private short  _svPercentRefillStop=0;
		public short svPercentRefillStop
		{
			get
			{
				return _svPercentRefillStop;
			}
			set
			{
				WriteDataPoint(38,11,value,-1,_svPercentRefillStop);
			}
		}
		private ushort  _svWeightRefillStart=0;
		public float svWeightRefillStart
		{
			get
			{
				return (float)(_svWeightRefillStart/100.0);
			}
			set
			{
                if (WriteDataPoint(38, 12, value, -1, _svWeightRefillStart))
                {
                    _svWeightRefillStart = (ushort)(value * 100.0);
                };
			}
		}
		private short  _svPercentRefillStart=0;
		public short svPercentRefillStart
		{
			get
			{
				return _svPercentRefillStart;
			}
			set
			{
				WriteDataPoint(38,13,value,-1,_svPercentRefillStart);
			}
		}
		private int    _svVolumeBin=0;
		public float svVolumeBin
		{
			get
			{
				return (float)(_svVolumeBin/100.0);
			}
			set
			{
				WriteDataPoint(38,14,value,-1,_svVolumeBin);
			}
		}
		private short  _svRefillTime=0;
		public short svRefillTime
		{
			get
			{
				return _svRefillTime;
			}
			set
			{
                if (WriteDataPoint(38, 15, value, -1, _svRefillTime))
                {
                    _svRefillTime = value;
                };
			}
		}
		private short  _svRefillType=0;
		public short svRefillType
		{
			get
			{
				return _svRefillType;
			}
			set
			{
                if (WriteDataPoint(38,16,value,-1,_svRefillType))
                {
                    _svRefillType = value;
                }
			
			}
		}
		private short  _svDisturbance=0;
		public short svDisturbance
		{
			get
			{
				return _svDisturbance;
			}
			set
			{
				WriteDataPoint(38,17,value,-1,_svDisturbance);
			}
		}
		private short  _svFeedFactorArraySize=0;
		public short svFeedFactorArraySize
		{
			get
			{
				return _svFeedFactorArraySize;
			}
			set
			{
				WriteDataPoint(38,18,value,-1,_svFeedFactorArraySize);
			}
		}
        private short _svPercentBridgeAlarm = 0;
        public short svPercentBridgeAlarm
        {
            get
            {
                return _svPercentBridgeAlarm;
            }
            set
            {
                WriteDataPoint(38, 18, value, -1, _svPercentBridgeAlarm);
            }
        }
		private short  _svLimitFeedFactor=0;
		public short svLimitFeedFactor
		{
			get
			{
				return _svLimitFeedFactor;
			}
			set
			{
				WriteDataPoint(38,19,value,-1,_svLimitFeedFactor);
			}
		}
		private short  _svBridgeAlarmDelay=0;
        public short svBridgeAlarmDelay
		{
			get
			{
                return _svBridgeAlarmDelay;
			}
			set
			{
                WriteDataPoint(38, 20, value, -1, _svBridgeAlarmDelay);
			}
		}

        private short _svMedianArraySize = 0;
        public short svMedianArraySize
        {
            get
            {
                return _svMedianArraySize;
            }
            set
            {
                WriteDataPoint(38, 20, value, -1, _svMedianArraySize);
            }
        }

		private XString _svLcoName=new XString(4);
		public string svLcoName
		{
			get
			{
				return (string)_svLcoName;
			}
			set
			{
				WriteDataPoint(38,21, new XString(_svLcoName.Capacity, value),-1,new XString(_svLcoName.Capacity, _svLcoName));
			}
		}

        private Int16 _svPartRealValues = 0;
        public Int16 svPartRealValues
		{
			get
			{
                return (_svPartRealValues);
			}
			set
			{
                WriteDataPoint(38, 50, value, -1, _svPartRealValues);
			}
		}

        private int _svReserve1 = 0;

        private Int16 _svReserve2 = 0;
        public Int16 svReserve2
		{
            get
            {
                return (_svReserve2);
            }
		}

        private int _svReserve3 = 0;


		private int _acFeedFactor=0;
		public int acFeedFactor
		{
			get
			{
				return _acFeedFactor;
			}		
		}
		private int _acThroughput=0;
		public float acThroughput
		{
			get
			{
				return (float)(_acThroughput/100.0);
			}		
		}
		private int _acWeight=0;
		public float acWeight
		{
			get
			{
				return (float)(_acWeight/1000.0);
			}		
		}
		private int _acStdDevFeedFactor=0;
		public int acStdDevFeedFactor
		{
			get
			{
				return _acStdDevFeedFactor;
			}		
		}
		private short _acRefillTime=0;
		public int acRefillTime
		{
			get
			{
				return _acRefillTime;
			}		
		}
		private int _acReserve1=0;
		private int _acReserve2=0;
		private int _acReserve3=0;
		private int _acReserve4=0;
		private int _acReserve5=0;

        private short _acGravRatio = 0;
        public short acGravRatio
        {
            get
            {
                return _acGravRatio;
            }
        }

		#region Property acMsgVersion
		private int _acMsgVersion=0;
		public int acMsgVersion
		{
			get
			{
				return _acMsgVersion;
			}
		}
		#endregion

		private short _svOperatingMode=0;
		public int svOperatingMode
		{
			get
			{
				return _svOperatingMode;
			}
            set
            {
                if (WriteDataPoint(38, 22, value, -1, _svOperatingMode))
                {
                    _svOperatingMode = (short)value;
                };

                
            }
		}
		private int _svManualOutputNom=0;
		public int svManualOutputNom
		{
			get
			{
				return _svManualOutputNom;
			}
			set
			{
                if (WriteDataPoint(38, 23, value, -1, _svManualOutputNom))
                {
                    _svManualOutputNom = value;
                };


			}
		}
		private int _svKp=0;
		public int svKp
		{
			get
			{
				return _svKp;
			}
			set
			{
				WriteDataPoint(38,26,value,-1,_svKp);
			}
		}
		private int _svTn=0;
		public int svTn
		{
			get
			{
				return _svTn;
			}
			set
			{
				WriteDataPoint(38,27,value,-1,_svTn);
			}
		}
		private  int _svThroughput=0;
		public float svThroughput
		{
			get
			{
				return (float)(_svThroughput/100.0);
			}
			set
			{
                if (WriteDataPoint(38, 38, value, -1, _svThroughput))
                {
                    _svThroughput = (short)(value*100.0);
                };

			}
		}
		private float _svInitialFeedfactor=0;
		public float svInitialFeedfactor
		{
			get
			{
				return (float)(_svInitialFeedfactor*10.0);
			}
			set
			{
                if (WriteDataPoint(38, 24, value / 10, -1, _svInitialFeedfactor))
                {
                    _svInitialFeedfactor = (short)(value /10.0);
                };

			}
		}
		private short _svModeChangeSet=0;
		public short svModeChangeSet
		{
			get
			{
				return _svModeChangeSet;
			}		
			set
			{
				WriteDataPoint(38,30,value,-1,_svModeChangeSet);
			}
		}
		private short _svModeError=0;
		public short svModeError
		{
			get
			{
				return _svModeError;
			}		
			set
			{
				WriteDataPoint(38,31,value,-1,_svModeError);
			}
		}
		private short _svLoaderWcn=0;
		public short svLoaderWcn
		{
			get
			{
				return _svLoaderWcn;
			}		
			set
			{
				WriteDataPoint(38,32,value,-1,_svLoaderWcn);
			}
		}
		private short _svLoaderLco=0;
		public short svLoaderLco
		{
			get
			{
				return _svLoaderLco;
			}		
			set
			{
				WriteDataPoint(38,33,value,-1,_svLoaderLco);
			}
		}
		private short _svPartMiddle=0;
		public short svPartMiddle
		{
			get
			{
				return _svPartMiddle;
			}		
			set
			{
				WriteDataPoint(38,34,value,-1,_svPartMiddle);
			}
		}
		private short _svPartMedian=0;
		public short svPartMedian
		{
			get
			{
				return _svPartMedian;
			}		
			set
			{
				WriteDataPoint(38,35,value,-1,_svPartMedian);
			}
		}
		private short _svDisplayFilter=0;
		public float svDisplayFilter
		{
			get
			{
				return (float)(_svDisplayFilter);
			}		
			set
			{
				WriteDataPoint(38,36,(short)(value),-1,_svDisplayFilter);
			}
		}
		private short _svDistWeight=0;
		public short svDistWeight
		{
			get
			{
				return _svDistWeight;
			}		
			set
			{
				WriteDataPoint(38,37,value,-1,_svDistWeight);
			}
		}
		private short _svSlowDownTime=0;
		public short svSlowDownTime
		{
			get
			{
				return _svSlowDownTime;
			}		
			set
			{
                if (WriteDataPoint(38, 25, value, -1, _svSlowDownTime))
                {
                    _svSlowDownTime = value;
                };

			}
		}

		private int _acMedianWeight=0;
		public int acMedianWeight
		{
			get
			{
				return _acMedianWeight;
			}
		}
		private int _acRawFeedFactor=0;
		public int acRawFeedFactor
		{
			get
			{
				return _acRawFeedFactor;
			}
		}
        private int _acDeviation = 0;
        public int acDeviation
        {
            get
            {
                return _acDeviation;
            }
        }

		private int _acSpeed=0;
		public int acSpeed
		{
			get
			{
				return _acSpeed;
			}
		}
		private int _acTotal=0;
		public float acTotal
		{
			get
			{
				return (float)(_acTotal/100.0);
			}
		}
		private int _svFlowRateNom=0;
		public int svFlowRateNom
		{
			get
			{
				return _svFlowRateNom;
			}		
//			set
//			{
//				WriteDataPoint(38,X,value);Noch nicht ben�tigt!
//			}
		}
		private int _acFeedFactor2=0;
		public float acFeedFactor2
		{
			get
			{
				return (float)(_acFeedFactor2/10.0);
			}
		}
		private int _acOutputNom=0;
		public float acOutputNom
		{
			get
			{
				return (float)(_acOutputNom/100.0);
			}
		}
		private int _acOutputRpm=0;
		public int acOutputRpm
		{
			get
			{
				return _acOutputRpm;
			}
		}
		private byte _acControlerStatus=0;
		public byte acControlerStatus
		{
			get
			{
				return _acControlerStatus;
			}
		}
		private int _svDelayTime=0;
		public int svDelayTime
		{
			get
			{
				return _svDelayTime;
			}
		}

		private int _svMeasTime=0;
		public float svMeasTime
		{
			get
			{
                return (float)(_svMeasTime/1000.0);
			}
			set
            {
              
                if (WriteDataPoint(38, 28, (int)(value * 1000), -1, _svMeasTime))
                {
                    _svMeasTime = (int)(value * 1000);
                };
			}


		}
		private int _svLowPassTime=0;
		public int svLowPassTime
		{
			get
			{
				return _svLowPassTime;
			}
			set
			{
				WriteDataPoint(38,29,value,-1,_svLowPassTime);
			}
		}
		private XString _custom1=new XString(4);
		public string custom1
		{
			get
			{
				return (string)_custom1;
			}
		}
		private XString _custom2=new XString(8);
		public string custom2
		{
			get
			{
				return (string)_custom2;
			}
		}
		private XString _custom3=new XString(8);
		public string custom3
		{
			get
			{
				return (string)_custom3;
			}
		}
		private XString _custom4=new XString(8);
		public string custom4
		{
			get
			{
				return (string)_custom4;
			}
		}
        private int _custom5 = 0;
        public int custom5
        {
            get
            {
                return _custom5;
            }
        }
        private short _custom6 = 0;
        public short custom6
        {
            get
            {
                return _custom6;
            }
        }

		private short  _svRefillTimeFactor=0;
		public short svRefillTimeFactor
		{
			get
			{
				return _svRefillTimeFactor;
			}
			set
			{
                if (WriteDataPoint(38, 15, value, -1, _svRefillTimeFactor))
                {
                    _svRefillTimeFactor = value;
                };


			}
		}

        private byte _svMode1 = 0;
        public byte svMode1
        {
            get
            {
                return _svMode1;
            }
            set
            {
                if (WriteDataPoint(38, 30, value, -1, _svMode1))
                {
                    _svMode1 = value;
                };

            }
        }

        private byte _svMode2 = 0;
        public byte svMode2
        {
            get
            {
                return _svMode2;
            }
            set
            {
                if (WriteDataPoint(38, 39, value, -1, _svMode2))
                {
                    _svMode2 = value;
                };

            }
        }

        private float _svthroughputMax = 0;
        public float svthroughputMax
        {
            get
            {
                return _svthroughputMax;
            }
            set
            {
                if (WriteDataPoint(38, 40, value, -1, _svthroughputMax))
                {
                    _svthroughputMax = value;
                };

            }
        }

        private float _acthroughputVisu = 0;
        public float acthroughputVisu
        {
            get
            {
                return _acthroughputVisu;
            }
        }



        private ushort _svLineStopMode = 0;
        public ushort svLineStopMode
        {
            get
            {
                return _svLineStopMode;
            }
            set
            {
                WriteDataPoint(38, 17, value, -1, _svLineStopMode);
            }
        }

        #region acCalStatus + CalStatus Enum

        private short _acCalStatus = 0;
        public short acCalStatus
        {
            get
            {
                return _acCalStatus;
            }
        }

        public enum CalStatus
        {
            Idle    = 0,
            Pre     = 1,
            Run     = 2,
            ToIni   = 3,
            Error   = 5
        };

        public bool HasCalibrationstatus(CalStatus calstatus)
        {
            return (_acCalStatus & (1 << (int)calstatus)) != 0x0000;
        }

        #endregion

        #region acLineStop
        private short _acLineStopMode = 0;
        public short acLineStopMode
        {
            get
            {
                return _acLineStopMode;
            }
        }

        public enum LineStop
        {
            MotorAlarm = 0,
            DosageEmpty = 1,
            DeviationAlarm = 2,
        };

        public bool HasLineStopstatus(LineStop lineStop)
        {
            return (_acLineStopMode & (1 << (int)lineStop)) != 0x0000;
        }
        #endregion

        #region svStartDelayTime
        private short _svStartDelayTime = 0;
        public short svStartDelayTime
        {
            get
            {
                return _svStartDelayTime;
            }
            set
            {
                WriteDataPoint(38, 41, value, -1, _svStartDelayTime);
            }
        }
        #endregion

        #region svStopDelayTime
        private short _svStopDelayTime = 0;
        public short svStopDelayTime
        {
            get
            {
                return _svStopDelayTime;
            }
            set
            {
                WriteDataPoint(38, 42, value, -1, _svStopDelayTime);
            }
        }
        #endregion

        #region svDeltaSollAllowed
        private short _svDeltaSollAllowed = 0;
        public short svDeltaSollAllowed
        {
            get
            {
                return _svDeltaSollAllowed;
            }
            set
            {
                WriteDataPoint(38, 46, value, -1, _svDeltaSollAllowed);
            }
        }
       #endregion

        #region svDebugFlags
       private ushort _svDebugFlags = 0;
       public ushort svDebugFlags
       {
           get
           {
               return _svDebugFlags;
           }
           set
           {
               WriteDataPoint(38, 47, value, -1, _svDebugFlags);
           }
       }
        public enum DebugFlags
        {
            ProportionalAdjustment = 0,
            SetCurve = 1,
            ResetCurve = 2,
            SetCurveEnabled = 3,
            SetVoluStableModeActive = 4
        }
        public bool HasDebugFlags(DebugFlags debugFlags)
        {
            return (_svDebugFlags & (1 << (int)debugFlags)) != 0x0000;
        }
        #endregion

        private short _svResultDistWeight = 0;
        private short _svRefillBorder = 0;

        private short _acRefillDeviationRun = 0;
        public short acRefillDeviationRun
        {
            get
            {
                return (_acRefillDeviationRun);
            }
        }

        private short _acRefillDeviationCali = 0;
        public short acRefillDeviationCali
        {
            get
            {
                return (_acRefillDeviationCali);
            }
        }

        private short _acSaveFeedFactor = 0;
        public short acSaveFeedFactor
        {
            get
            {
                return (_acSaveFeedFactor);
            }
        }

        private short _svManRefillEna = 0;
        public short svManRefillEna
        {
            get
            {
                return (_svManRefillEna);
            }

            set
            {
                if (WriteDataPoint(38, 49, value, -1, _svManRefillEna))
                {
                    _svManRefillEna = value;
                };


            }
        }

        private short _svDistThrgptFactor = 0;
        public short svDistThrgptFactor
        {
            get
            {
                return (_svDistThrgptFactor);
            }
            set
            {
                if (WriteDataPoint(38, 48, value, -1, _svDistThrgptFactor))
                {
                    _svDistThrgptFactor = value;
                };


            }
 
        }

        private short _acThrgptDeviation = 0;
        public short acThrgptDeviation
        {
            get
            {
                return (_acThrgptDeviation);
            }

        }

        private short _acdWeightDeviation = 0;
        public short acdWeightDeviation
        {
            get
            {
                return (_acdWeightDeviation);
            }

        }
       private short _acdWeightAverage = 0;
        public short acdWeightAverage
        {
            get
            {
                return (_acdWeightAverage);
            }

        }

       private short _acThrgptAverage = 0;
        public short acThrgptAverage
        {
            get
            {
                return (_acThrgptAverage);
            }

        }

        private int _acFeedFactorVisu = 0;
        public float acFeedFactorVisu
        {
            get
            {
                return (float)(_acFeedFactorVisu / 10.0);
            }
        }

 
        #endregion

        #region ControlerStatus

        public enum ControlerStatus
		{
			Disabled	= 0,
			Off			= 1,
			Manual		= 2,
			Volumetric	= 3,
			Gravimetric = 4
		};

		public bool HasControllerstatus(ControlerStatus controlerStatus)
		{
			return (_acControlerStatus & (1 << (int)controlerStatus)) != 0x0000;
		}

		#endregion

		#region OperatingMode			
		
		public enum OperatingMode
		{
			FeedConrol_OFF			= 0,
			FeedControl_HAND		= 1,
			FeedControl_Volumetric	= 2,
			FeedControl_GraviMetric	= 3,
		};

		public bool HasControllerstatus(OperatingMode operatingMode)
		{
			return (_svOperatingMode & (1 << (int)operatingMode)) != 0x0000;
		}

		#endregion

		#region Name

		public override string Name
		{
			get
			{
				return _svLcoName;
			}
		}

		#endregion

		#region Commands
		public bool cfOnOff()
		{

            if (WriteCommand(38, 0x0001, -1, _Status))
            {
                if (!HasStatus(Motan.XNet.LCO.DosFeedControl_FCT038.StatusCode.sfOnOff))
                {
                    SetStatus(Motan.XNet.LCO.DosFeedControl_FCT038.StatusCode.sfOnOff, true);
                }
                else
                {
                    SetStatus(Motan.XNet.LCO.DosFeedControl_FCT038.StatusCode.sfOnOff, false);
                }
                return true;
            }
            else
            {
                return false;
            }

		}

        public bool cfZoneobserverOnOff()
        {

            if (WriteCommand(38, 0x0002, -1, _Status))
            {
                if (!HasStatus(Motan.XNet.LCO.DosFeedControl_FCT038.StatusCode.sfZoneobserverOnOff))
                {
                    SetStatus(Motan.XNet.LCO.DosFeedControl_FCT038.StatusCode.sfZoneobserverOnOff, true);
                }
                else
                {
                    SetStatus(Motan.XNet.LCO.DosFeedControl_FCT038.StatusCode.sfZoneobserverOnOff, false);
                }
                return true;
            }
            else
            {
                return false;
            }

        }

        public bool cfEnabAdjustInitialFF()
        {

            if (WriteCommand(38, 0x0008, -1, _Status))
            {
                if (!HasStatus(Motan.XNet.LCO.DosFeedControl_FCT038.StatusCode.sfEnabAdjustInitialFF))
                {
                    SetStatus(Motan.XNet.LCO.DosFeedControl_FCT038.StatusCode.sfEnabAdjustInitialFF, true);
                }
                else
                {
                    SetStatus(Motan.XNet.LCO.DosFeedControl_FCT038.StatusCode.sfEnabAdjustInitialFF, false);
                }
                return true;
            }
            else
            {
                return false;
            }

        }

		public bool cfReset()
		{
			return base.WriteCommand(38,0x0010,-1,_Status);
		}

        public bool cfRunVolBelowRefillStart()
		{
            if (WriteCommand(38, 0x0020, -1, _Status))
            {
                if (!HasStatus(Motan.XNet.LCO.DosFeedControl_FCT038.StatusCode.sfRunVolBelowRefillStart))
                {
                    SetStatus(Motan.XNet.LCO.DosFeedControl_FCT038.StatusCode.sfRunVolBelowRefillStart, true);
                }
                else
                {
                    SetStatus(Motan.XNet.LCO.DosFeedControl_FCT038.StatusCode.sfRunVolBelowRefillStart, false);
                }
                return true;
            }
            else
            {
                return false;
            }

		}

		public bool cfRefillManual()
		{
			return base.WriteCommand(38,0x0040,-1,_Status);
		}

		public bool cfFeedDet()
		{
			return base.WriteCommand(38,0x0080,-1,_Status);
		}
		public bool cfFeedDetToIni()
		{
			return base.WriteCommand(38,0x0100,-1,_Status);
		}
		public bool cfRstDistWght()
		{
			return base.WriteCommand(38,0x0200,-1,_Status);
		}
        public bool cfStartCalib()
        {
            return base.WriteCommand(38, 0x0800, -1, _Status);
        }
        public bool cfRes()
        {
            return base.WriteCommand(38, 0x1000, -1, _Status);
        }
        public bool cfSendDiagData()
        {
            return base.WriteCommand(38, 0x2000, -1, _Status);
        }
		#endregion

		#region Factories			
		public DosFeedControl_FCT038(ControlNode cn, byte lconr):base(cn,lconr) 
		{
	    }
		#endregion

        #region NewFlowrateDetection_Aktiv
        private bool _NewFlowrateDetection_Aktiv = false;
        public bool NewFlowrateDetection_Aktiv
        {
            get { return _NewFlowrateDetection_Aktiv; }
            set { _NewFlowrateDetection_Aktiv = value; }
        }
        #endregion

		#region The Update Method
        public override bool UpdateParser(XNetMessage msg_reply)
        {
            _NewFlowrateDetection_Aktiv = false;

            if (msg_reply.Data.Length == 100)
            {
                msg_reply.Parse(out _Alarm);
                msg_reply.Parse(out _Status);
                msg_reply.Parse(out _svWeightOverfilled);
                msg_reply.Parse(out _svPercentOverfilled);
                msg_reply.Parse(out _svBulkDensity);
                msg_reply.Parse(out _svAlarmlimitThroughput);
                msg_reply.Parse(out _svAlarmdelayThroughput);
                msg_reply.Parse(out _svWeightEmpty);
                msg_reply.Parse(out _svPercentEmpty);
                msg_reply.Parse(out _svWeightMaskingUp);
                msg_reply.Parse(out _svWeightMaskingDown);
                msg_reply.Parse(out _svWeightRefillStop);
                msg_reply.Parse(out _svPercentRefillStop);
                msg_reply.Parse(out _svWeightRefillStart);
                msg_reply.Parse(out _svPercentRefillStart);
                msg_reply.Parse(out _svVolumeBin);
                msg_reply.Parse(out _svRefillTime);
                msg_reply.Parse(out _svRefillType);
                msg_reply.Parse(out _svDisturbance);
                msg_reply.Parse(out _svFeedFactorArraySize);
                msg_reply.Parse(out _svLimitFeedFactor);
                msg_reply.Parse(out _svMedianArraySize);
                msg_reply.Parse(ref _svLcoName);

                msg_reply.Parse(out _svReserve1);
                msg_reply.Parse(out _svReserve2);
                msg_reply.Parse(out _svReserve3);

                msg_reply.Parse(out _acFeedFactor);
                msg_reply.Parse(out _acThroughput);
                msg_reply.Parse(out _acWeight);
                msg_reply.Parse(out _acStdDevFeedFactor);
                msg_reply.Parse(out _acRefillTime);
                msg_reply.Parse(out _acReserve1);
                msg_reply.Parse(out _acReserve2);
                msg_reply.Parse(out _acReserve3);
                msg_reply.Parse(out _acReserve4);
                msg_reply.Parse(out _acReserve5);
            }
            else if (msg_reply.Data.Length >= 104)
            {
                msg_reply.Parse(out _acMsgVersion, 100);
                if (_acMsgVersion == 0x170911)
                {
                    if (msg_reply.Data.Length == 193)
                    {
                        msg_reply.Parse(out _Alarm);
                        msg_reply.Parse(out _Status);
                        msg_reply.Parse(out _svWeightOverfilled);
                        msg_reply.Parse(out _svPercentOverfilled);
                        msg_reply.Parse(out _svBulkDensity);
                        msg_reply.Parse(out _svAlarmlimitThroughput);
                        msg_reply.Parse(out _svAlarmdelayThroughput);
                        msg_reply.Parse(out _svWeightEmpty);
                        msg_reply.Parse(out _svPercentEmpty);
                        msg_reply.Parse(out _svWeightMaskingUp);
                        msg_reply.Parse(out _svWeightMaskingDown);
                        msg_reply.Parse(out _svWeightRefillStop);
                        msg_reply.Parse(out _svPercentRefillStop);
                        msg_reply.Parse(out _svWeightRefillStart);
                        msg_reply.Parse(out _svPercentRefillStart);
                        msg_reply.Parse(out _svVolumeBin);
                        msg_reply.Parse(out _svRefillTimeFactor);
                        msg_reply.Parse(out _svRefillType);
                        msg_reply.Parse(out _svSlowDownTime);
                        msg_reply.Parse(out _svDisturbance);
                        msg_reply.Parse(out _svFeedFactorArraySize);
                        msg_reply.Parse(out _svLimitFeedFactor);
                        msg_reply.Parse(out _svMedianArraySize);
                        msg_reply.Parse(ref _svLcoName);
                        msg_reply.Parse(out _svDelayTime);
                        msg_reply.Parse(out _svMeasTime);
                        msg_reply.Parse(out _svLowPassTime);
                        msg_reply.Parse(ref _custom1);
                        msg_reply.Parse(ref _custom2);
                        msg_reply.Parse(ref _custom3);
                        msg_reply.Parse(ref _custom4);
                        msg_reply.Parse(out _custom5);

                        msg_reply.Parse(out _acMsgVersion);
                        msg_reply.Parse(out _svOperatingMode);
                        msg_reply.Parse(out _svManualOutputNom);
                        msg_reply.Parse(out _svKp);
                        msg_reply.Parse(out _svTn);
                        msg_reply.Parse(out _svThroughput);
                        msg_reply.Parse(out _svInitialFeedfactor);
                        msg_reply.Parse(out _svModeChangeSet);
                        msg_reply.Parse(out _svModeError);
                        msg_reply.Parse(out _svLoaderWcn);
                        msg_reply.Parse(out _svLoaderLco);
                        msg_reply.Parse(out _svPartMiddle);
                        msg_reply.Parse(out _svPartMedian);
                        msg_reply.Parse(out _svDisplayFilter);
                        msg_reply.Parse(out _svDistWeight);
                        msg_reply.Parse(out _acFeedFactor);
                        msg_reply.Parse(out _acThroughput);
                        msg_reply.Parse(out _acWeight);
                        msg_reply.Parse(out _acStdDevFeedFactor);
                        msg_reply.Parse(out _acRefillTime);
                        msg_reply.Parse(out _acMedianWeight);
                        msg_reply.Parse(out _acRawFeedFactor);
                        msg_reply.Parse(out _acSpeed);
                        msg_reply.Parse(out _acTotal);
                        msg_reply.Parse(out _svFlowRateNom);
                        msg_reply.Parse(out _acFeedFactor2);
                        msg_reply.Parse(out _acOutputNom);
                        msg_reply.Parse(out _acOutputRpm);
                        msg_reply.Parse(out _acControlerStatus);
                    }
                    else
                    {
                        _acMsgVersion = 0;
                        return false;
                    }
                }
                else if (_acMsgVersion == 0x310112)
                {
                    if (msg_reply.Data.Length == 197)
                    {
                        msg_reply.Parse(out _Alarm);
                        msg_reply.Parse(out _Status);
                        msg_reply.Parse(out _svWeightOverfilled);
                        msg_reply.Parse(out _svPercentOverfilled);
                        msg_reply.Parse(out _svBulkDensity);
                        msg_reply.Parse(out _svAlarmlimitThroughput);
                        msg_reply.Parse(out _svAlarmdelayThroughput);
                        msg_reply.Parse(out _svWeightEmpty);
                        msg_reply.Parse(out _svPercentEmpty);
                        msg_reply.Parse(out _svWeightMaskingUp);
                        msg_reply.Parse(out _svWeightMaskingDown);
                        msg_reply.Parse(out _svWeightRefillStop);
                        msg_reply.Parse(out _svPercentRefillStop);
                        msg_reply.Parse(out _svWeightRefillStart);
                        msg_reply.Parse(out _svPercentRefillStart);
                        msg_reply.Parse(out _svVolumeBin);
                        msg_reply.Parse(out _svRefillTimeFactor);
                        msg_reply.Parse(out _svRefillType);
                        msg_reply.Parse(out _svSlowDownTime);
                        msg_reply.Parse(out _svLineStopMode);
                        msg_reply.Parse(out _svFeedFactorArraySize);
                        msg_reply.Parse(out _svLimitFeedFactor);
                        msg_reply.Parse(out _svMedianArraySize);
                        msg_reply.Parse(ref _svLcoName);
                        msg_reply.Parse(out _svStartDelayTime);
                        msg_reply.Parse(out _svStopDelayTime);
                        msg_reply.Parse(out _svMeasTime);
                        msg_reply.Parse(out _svLowPassTime);
                        msg_reply.Parse(out _acthroughputVisu);
                        msg_reply.Parse(out _svDistThrgptFactor);
                        msg_reply.Parse(out _acThrgptDeviation);
                        msg_reply.Parse(out _acdWeightDeviation);
                        msg_reply.Parse(out _acdWeightAverage);
                        msg_reply.Parse(out _acThrgptAverage);
                   
                        msg_reply.Parse(ref _custom1);
 
                        msg_reply.Parse(out _acMsgVersion);
                        msg_reply.Parse(out _svOperatingMode);
                        msg_reply.Parse(out _svManualOutputNom);
                        msg_reply.Parse(out _svKp);
                        msg_reply.Parse(out _svTn);
                        msg_reply.Parse(out _svThroughput);
                        msg_reply.Parse(out _svInitialFeedfactor);
                        msg_reply.Parse(out _svMode1);
                        msg_reply.Parse(out _svMode2);
                        msg_reply.Parse(out _svModeError);
                        msg_reply.Parse(out _svLoaderWcn);
                        msg_reply.Parse(out _svLoaderLco);
                        msg_reply.Parse(out _svPartMiddle);
                        msg_reply.Parse(out _svPartMedian);
                        msg_reply.Parse(out _svDisplayFilter);
                        msg_reply.Parse(out _svDistWeight);
                        msg_reply.Parse(out _svCommandFlagsTestmodus);
                        msg_reply.Parse(out _acFlagsTestmodus);
                        msg_reply.Parse(out _acThroughput);
                        msg_reply.Parse(out _acWeight);
                        msg_reply.Parse(out _acCalStatus);
                        msg_reply.Parse(out _acLineStopMode);
                        msg_reply.Parse(out _acRefillTime);
                        msg_reply.Parse(out _acMedianWeight);
                        msg_reply.Parse(out _acRawFeedFactor);
                        msg_reply.Parse(out _acSpeed);
                        msg_reply.Parse(out _acTotal);
                        msg_reply.Parse(out _svFlowRateNom);
                        msg_reply.Parse(out _acFeedFactor2);
                        msg_reply.Parse(out _acOutputNom);
                        msg_reply.Parse(out _acOutputRpm);
                        msg_reply.Parse(out _acControlerStatus);
                        msg_reply.Parse(out _svthroughputMax);
                    }
                    else
                    {
                        _acMsgVersion = 0;
                        return false;
                    }
                }
                else if (_acMsgVersion == 0x140213)
                {
                    if (msg_reply.Data.Length == 197)
                    {
                        msg_reply.Parse(out _Alarm);
                        msg_reply.Parse(out _Status);
                        msg_reply.Parse(out _svWeightOverfilled);
                        msg_reply.Parse(out _svPercentOverfilled);
                        msg_reply.Parse(out _svBulkDensity);
                        msg_reply.Parse(out _svAlarmlimitThroughput);
                        msg_reply.Parse(out _svAlarmdelayThroughput);
                        msg_reply.Parse(out _svWeightEmpty);
                        msg_reply.Parse(out _svPercentEmpty);
                        msg_reply.Parse(out _svWeightMaskingUp);
                        msg_reply.Parse(out _svWeightMaskingDown);
                        msg_reply.Parse(out _svWeightRefillStop);
                        msg_reply.Parse(out _svPercentRefillStop);
                        msg_reply.Parse(out _svWeightRefillStart);
                        msg_reply.Parse(out _svPercentRefillStart);
                        msg_reply.Parse(out _svVolumeBin);
                        msg_reply.Parse(out _svRefillTimeFactor);
                        msg_reply.Parse(out _svRefillType);
                        msg_reply.Parse(out _svSlowDownTime);
                        msg_reply.Parse(out _svLineStopMode);
                        msg_reply.Parse(out _svFeedFactorArraySize);
                        msg_reply.Parse(out _svLimitFeedFactor);
                        msg_reply.Parse(out _svMedianArraySize);
                        msg_reply.Parse(ref _svLcoName);
                        msg_reply.Parse(out _svStartDelayTime);
                        msg_reply.Parse(out _svStopDelayTime);
                        msg_reply.Parse(out _svMeasTime);
                        msg_reply.Parse(out _svLowPassTime);
                        msg_reply.Parse(out _acthroughputVisu);
                        msg_reply.Parse(out _svDistThrgptFactor);
                        msg_reply.Parse(out _acThrgptDeviation);
                        msg_reply.Parse(out _acdWeightDeviation);
                        msg_reply.Parse(out _acdWeightAverage);
                        msg_reply.Parse(out _acThrgptAverage);

                        //msg_reply.Parse(ref _custom1);
                        //msg_reply.Parse(ref _custom2);
                        //msg_reply.Parse(ref _custom3);
                        msg_reply.Parse(ref _custom4);
                        msg_reply.Parse(out _custom6);
                        msg_reply.Parse(out _svDeltaSollAllowed);
                        msg_reply.Parse(out _svResultDistWeight);
                        msg_reply.Parse(out _svRefillBorder);
                        msg_reply.Parse(out _acRefillDeviationRun);
                        msg_reply.Parse(out _acRefillDeviationCali);
                        msg_reply.Parse(out _svDebugFlags);

                        msg_reply.Parse(out _acMsgVersion);
                        msg_reply.Parse(out _svOperatingMode);
                        msg_reply.Parse(out _svManualOutputNom);
                        msg_reply.Parse(out _svKp);
                        msg_reply.Parse(out _svTn);
                        msg_reply.Parse(out _svThroughput);
                        msg_reply.Parse(out _svInitialFeedfactor);
                        msg_reply.Parse(out _svMode1);
                        msg_reply.Parse(out _svMode2);
                        msg_reply.Parse(out _svModeError);
                        msg_reply.Parse(out _svLoaderWcn);
                        msg_reply.Parse(out _svLoaderLco);
                        msg_reply.Parse(out _svPartMiddle);
                        msg_reply.Parse(out _svPartMedian);
                        msg_reply.Parse(out _svDisplayFilter);
                        msg_reply.Parse(out _svDistWeight);
                        msg_reply.Parse(out _svCommandFlagsTestmodus);
                        msg_reply.Parse(out _acFlagsTestmodus);
                        msg_reply.Parse(out _acThroughput);
                        msg_reply.Parse(out _acWeight);
                        msg_reply.Parse(out _acCalStatus);
                        msg_reply.Parse(out _acLineStopMode);
                        msg_reply.Parse(out _acRefillTime);
                        msg_reply.Parse(out _acMedianWeight);
                        msg_reply.Parse(out _acRawFeedFactor);
                        msg_reply.Parse(out _acSpeed);
                        msg_reply.Parse(out _acTotal);
                        msg_reply.Parse(out _svFlowRateNom);
                        msg_reply.Parse(out _acFeedFactor2);
                        msg_reply.Parse(out _acOutputNom);
                        msg_reply.Parse(out _acOutputRpm);
                        msg_reply.Parse(out _acControlerStatus);
                        msg_reply.Parse(out _svthroughputMax);
                    }
                    else
                    {
                        _acMsgVersion = 0;
                        return false;
                    }
                }
                else if (_acMsgVersion == 0x101013)
                {
                    if (msg_reply.Data.Length == 197)
                    {
                        msg_reply.Parse(out _Alarm);
                        msg_reply.Parse(out _Status);
                        msg_reply.Parse(out _svWeightOverfilled);
                        msg_reply.Parse(out _svPercentOverfilled);
                        msg_reply.Parse(out _svBulkDensity);
                        msg_reply.Parse(out _svAlarmlimitThroughput);
                        msg_reply.Parse(out _svAlarmdelayThroughput);
                        msg_reply.Parse(out _svWeightEmpty);
                        msg_reply.Parse(out _svPercentEmpty);
                        msg_reply.Parse(out _svWeightMaskingUp);
                        msg_reply.Parse(out _svWeightMaskingDown);
                        msg_reply.Parse(out _svWeightRefillStop);
                        msg_reply.Parse(out _svPercentRefillStop);
                        msg_reply.Parse(out _svWeightRefillStart);
                        msg_reply.Parse(out _svPercentRefillStart);
                        msg_reply.Parse(out _svVolumeBin);
                        msg_reply.Parse(out _svRefillTimeFactor);
                        msg_reply.Parse(out _svRefillType);
                        msg_reply.Parse(out _svSlowDownTime);
                        msg_reply.Parse(out _svLineStopMode);
                        msg_reply.Parse(out _svFeedFactorArraySize);
                        msg_reply.Parse(out _svLimitFeedFactor);
                        msg_reply.Parse(out _svMedianArraySize);
                        msg_reply.Parse(ref _svLcoName);
                        msg_reply.Parse(out _svStartDelayTime);
                        msg_reply.Parse(out _svStopDelayTime);
                        msg_reply.Parse(out _svMeasTime);
                        msg_reply.Parse(out _svLowPassTime);
                        msg_reply.Parse(out _acthroughputVisu);
                        msg_reply.Parse(out _svDistThrgptFactor);
                        msg_reply.Parse(out _acThrgptDeviation);
                        msg_reply.Parse(out _acdWeightDeviation);
                        msg_reply.Parse(out _acdWeightAverage);
                        msg_reply.Parse(out _acThrgptAverage);
                        msg_reply.Parse(out _custom6);
                        msg_reply.Parse(out _acFeedFactorVisu);
                        msg_reply.Parse(out _custom6);
                        msg_reply.Parse(out _custom6);
                        msg_reply.Parse(out _svDeltaSollAllowed);
                        msg_reply.Parse(out _svResultDistWeight);
                        msg_reply.Parse(out _svRefillBorder);
                        msg_reply.Parse(out _acRefillDeviationRun);
                        msg_reply.Parse(out _acRefillDeviationCali);
                        msg_reply.Parse(out _svDebugFlags);

                        msg_reply.Parse(out _acMsgVersion);
                        msg_reply.Parse(out _svOperatingMode);
                        msg_reply.Parse(out _svManualOutputNom);
                        msg_reply.Parse(out _svKp);
                        msg_reply.Parse(out _svTn);
                        msg_reply.Parse(out _svThroughput);
                        msg_reply.Parse(out _svInitialFeedfactor);
                        msg_reply.Parse(out _svMode1);
                        msg_reply.Parse(out _svMode2);
                        msg_reply.Parse(out _svModeError);
                        msg_reply.Parse(out _svLoaderWcn);
                        msg_reply.Parse(out _svLoaderLco);
                        msg_reply.Parse(out _svPartMiddle);
                        msg_reply.Parse(out _svPartMedian);
                        msg_reply.Parse(out _svDisplayFilter);
                        msg_reply.Parse(out _svDistWeight);
                        msg_reply.Parse(out _svCommandFlagsTestmodus);
                        msg_reply.Parse(out _acFlagsTestmodus);
                        msg_reply.Parse(out _acThroughput);
                        msg_reply.Parse(out _acWeight);
                        msg_reply.Parse(out _acCalStatus);
                        msg_reply.Parse(out _acLineStopMode);
                        msg_reply.Parse(out _acRefillTime);
                        msg_reply.Parse(out _acMedianWeight);
                        msg_reply.Parse(out _acRawFeedFactor);
                        msg_reply.Parse(out _acSpeed);
                        msg_reply.Parse(out _acTotal);
                        msg_reply.Parse(out _svFlowRateNom);
                        msg_reply.Parse(out _acFeedFactor2);
                        msg_reply.Parse(out _acOutputNom);
                        msg_reply.Parse(out _acOutputRpm);
                        msg_reply.Parse(out _acControlerStatus);
                        msg_reply.Parse(out _svthroughputMax);
                    }
                    else
                    {
                        _acMsgVersion = 0;
                        return false;
                    }
                }
                else if (_acMsgVersion == 0x150615)
                {
                    if (msg_reply.Data.Length == 197)
                    {
                        msg_reply.Parse(out _Alarm);
                        msg_reply.Parse(out _Status);
                        msg_reply.Parse(out _svWeightOverfilled);
                        msg_reply.Parse(out _svPercentOverfilled);
                        msg_reply.Parse(out _svBulkDensity);
                        msg_reply.Parse(out _svAlarmlimitThroughput);
                        msg_reply.Parse(out _svAlarmdelayThroughput);
                        msg_reply.Parse(out _svWeightEmpty);
                        msg_reply.Parse(out _svPercentEmpty);
                        msg_reply.Parse(out _svWeightMaskingUp);
                        msg_reply.Parse(out _svWeightMaskingDown);
                        msg_reply.Parse(out _svWeightRefillStop);
                        msg_reply.Parse(out _svPercentRefillStop);
                        msg_reply.Parse(out _svWeightRefillStart);
                        msg_reply.Parse(out _svPercentRefillStart);
                        msg_reply.Parse(out _svVolumeBin);
                        msg_reply.Parse(out _svRefillTimeFactor);
                        msg_reply.Parse(out _svRefillType);
                        msg_reply.Parse(out _svSlowDownTime);
                        msg_reply.Parse(out _svLineStopMode);
                        msg_reply.Parse(out _svFeedFactorArraySize);
                        msg_reply.Parse(out _svLimitFeedFactor);
                        msg_reply.Parse(out _svMedianArraySize);
                        msg_reply.Parse(ref _svLcoName);
                        msg_reply.Parse(out _svStartDelayTime);
                        msg_reply.Parse(out _svStopDelayTime);
                        msg_reply.Parse(out _svMeasTime);
                        msg_reply.Parse(out _svLowPassTime);
                        msg_reply.Parse(out _acthroughputVisu);
                        msg_reply.Parse(out _svDistThrgptFactor);
                        msg_reply.Parse(out _acThrgptDeviation);
                        msg_reply.Parse(out _acdWeightDeviation);
                        msg_reply.Parse(out _acdWeightAverage);
                        msg_reply.Parse(out _acThrgptAverage);
                        msg_reply.Parse(out _acGravRatio);
                        msg_reply.Parse(out _acFeedFactorVisu);
                        msg_reply.Parse(out _svPartRealValues);
                        msg_reply.Parse(out _svReserve2);
                        msg_reply.Parse(out _svDeltaSollAllowed);
                        msg_reply.Parse(out _svResultDistWeight);
                        msg_reply.Parse(out _svRefillBorder);
                        msg_reply.Parse(out _acSaveFeedFactor);
                        msg_reply.Parse(out _svManRefillEna);
                        msg_reply.Parse(out _svDebugFlags);

                        msg_reply.Parse(out _acMsgVersion);
                        msg_reply.Parse(out _svOperatingMode);
                        msg_reply.Parse(out _svManualOutputNom);
                        msg_reply.Parse(out _svKp);
                        msg_reply.Parse(out _svTn);
                        msg_reply.Parse(out _svThroughput);
                        msg_reply.Parse(out _svInitialFeedfactor);
                        msg_reply.Parse(out _svMode1);
                        msg_reply.Parse(out _svMode2);
                        msg_reply.Parse(out _svModeError);
                        msg_reply.Parse(out _svLoaderWcn);
                        msg_reply.Parse(out _svLoaderLco);
                        msg_reply.Parse(out _svPartMiddle);
                        msg_reply.Parse(out _svPartMedian);
                        msg_reply.Parse(out _svDisplayFilter);
                        msg_reply.Parse(out _svDistWeight);
                        msg_reply.Parse(out _svCommandFlagsTestmodus);
                        msg_reply.Parse(out _acFlagsTestmodus);
                        msg_reply.Parse(out _acThroughput);
                        msg_reply.Parse(out _acWeight);
                        msg_reply.Parse(out _acCalStatus);
                        msg_reply.Parse(out _acLineStopMode);
                        msg_reply.Parse(out _acRefillTime);
                        msg_reply.Parse(out _acMedianWeight);
                        msg_reply.Parse(out _acDeviation);
                        msg_reply.Parse(out _acSpeed);
                        msg_reply.Parse(out _acTotal);
                        msg_reply.Parse(out _svFlowRateNom);
                        msg_reply.Parse(out _acFeedFactor2);
                        msg_reply.Parse(out _acOutputNom);
                        msg_reply.Parse(out _acOutputRpm);
                        msg_reply.Parse(out _acControlerStatus);
                        msg_reply.Parse(out _svthroughputMax);
                    }
                    else
                    {
                        _acMsgVersion = 0;
                        return false;
                    }
                }
                else if (_acMsgVersion == 0x160216)
                {
                    if (msg_reply.Data.Length == 197)
                    {
                        msg_reply.Parse(out _Alarm);
                        msg_reply.Parse(out _Status);
                        msg_reply.Parse(out _svWeightOverfilled);
                        msg_reply.Parse(out _svPercentOverfilled);
                        msg_reply.Parse(out _svBulkDensity);
                        msg_reply.Parse(out _svAlarmlimitThroughput);
                        msg_reply.Parse(out _svAlarmdelayThroughput);
                        msg_reply.Parse(out _svWeightEmpty);
                        msg_reply.Parse(out _svPercentEmpty);
                        msg_reply.Parse(out _svWeightMaskingUp);
                        msg_reply.Parse(out _svWeightMaskingDown);
                        msg_reply.Parse(out _svWeightRefillStop);
                        msg_reply.Parse(out _svPercentRefillStop);
                        msg_reply.Parse(out _svWeightRefillStart);
                        msg_reply.Parse(out _svPercentRefillStart);
                        msg_reply.Parse(out _svVolumeBin);
                        msg_reply.Parse(out _svRefillTimeFactor);
                        msg_reply.Parse(out _svRefillType);
                        msg_reply.Parse(out _svSlowDownTime);
                        msg_reply.Parse(out _svLineStopMode);
                        msg_reply.Parse(out _svPercentBridgeAlarm);
                        msg_reply.Parse(out _svLimitFeedFactor);
                        msg_reply.Parse(out _svMedianArraySize);
                        msg_reply.Parse(ref _svLcoName);
                        msg_reply.Parse(out _svStartDelayTime);
                        msg_reply.Parse(out _svStopDelayTime);
                        msg_reply.Parse(out _svMeasTime);
                        msg_reply.Parse(out _svLowPassTime);
                        msg_reply.Parse(out _acthroughputVisu);
                        msg_reply.Parse(out _svDistThrgptFactor);
                        msg_reply.Parse(out _acThrgptDeviation);
                        msg_reply.Parse(out _acdWeightDeviation);
                        msg_reply.Parse(out _acdWeightAverage);
                        msg_reply.Parse(out _acThrgptAverage);
                        msg_reply.Parse(out _acGravRatio);
                        msg_reply.Parse(out _acFeedFactorVisu);
                        msg_reply.Parse(out _svPartRealValues);
                        msg_reply.Parse(out _svReserve2);
                        msg_reply.Parse(out _svDeltaSollAllowed);
                        msg_reply.Parse(out _svResultDistWeight);
                        msg_reply.Parse(out _svRefillBorder);
                        msg_reply.Parse(out _acSaveFeedFactor);
                        msg_reply.Parse(out _svManRefillEna);
                        msg_reply.Parse(out _svDebugFlags);

                        msg_reply.Parse(out _acMsgVersion);
                        msg_reply.Parse(out _svOperatingMode);
                        msg_reply.Parse(out _svManualOutputNom);
                        msg_reply.Parse(out _svKp);
                        msg_reply.Parse(out _svTn);
                        msg_reply.Parse(out _svThroughput);
                        msg_reply.Parse(out _svInitialFeedfactor);
                        msg_reply.Parse(out _svMode1);
                        msg_reply.Parse(out _svMode2);
                        msg_reply.Parse(out _svModeError);
                        msg_reply.Parse(out _svLoaderWcn);
                        msg_reply.Parse(out _svLoaderLco);
                        msg_reply.Parse(out _svPartMiddle);
                        msg_reply.Parse(out _svPartMedian);
                        msg_reply.Parse(out _svDisplayFilter);
                        msg_reply.Parse(out _svDistWeight);
                        msg_reply.Parse(out _svCommandFlagsTestmodus);
                        msg_reply.Parse(out _acFlagsTestmodus);
                        msg_reply.Parse(out _acThroughput);
                        msg_reply.Parse(out _acWeight);
                        msg_reply.Parse(out _acCalStatus);
                        msg_reply.Parse(out _acLineStopMode);
                        msg_reply.Parse(out _acRefillTime);
                        msg_reply.Parse(out _acMedianWeight);
                        msg_reply.Parse(out _acDeviation);
                        msg_reply.Parse(out _acSpeed);
                        msg_reply.Parse(out _acTotal);
                        msg_reply.Parse(out _svFlowRateNom);
                        msg_reply.Parse(out _acFeedFactor2);
                        msg_reply.Parse(out _acOutputNom);
                        msg_reply.Parse(out _acOutputRpm);
                        msg_reply.Parse(out _acControlerStatus);
                        msg_reply.Parse(out _svthroughputMax);
                        _NewFlowrateDetection_Aktiv = true;
                    }
                    else
                    {
                        _acMsgVersion = 0;
                        return false;
                    }
                }
                    else if (_acMsgVersion == 0x120816)
                    {
                        if (msg_reply.Data.Length == 197)
                        {
                            msg_reply.Parse(out _Alarm);
                            msg_reply.Parse(out _Status);
                            msg_reply.Parse(out _svWeightOverfilled);
                            msg_reply.Parse(out _svPercentOverfilled);
                            msg_reply.Parse(out _svBulkDensity);
                            msg_reply.Parse(out _svAlarmlimitThroughput);
                            msg_reply.Parse(out _svAlarmdelayThroughput);
                            msg_reply.Parse(out _svWeightEmpty);
                            msg_reply.Parse(out _svPercentEmpty);
                            msg_reply.Parse(out _svWeightMaskingUp);
                            msg_reply.Parse(out _svWeightMaskingDown);
                            msg_reply.Parse(out _svWeightRefillStop);
                            msg_reply.Parse(out _svPercentRefillStop);
                            msg_reply.Parse(out _svWeightRefillStart);
                            msg_reply.Parse(out _svPercentRefillStart);
                            msg_reply.Parse(out _svVolumeBin);
                            msg_reply.Parse(out _svRefillTimeFactor);
                            msg_reply.Parse(out _svRefillType);
                            msg_reply.Parse(out _svSlowDownTime);
                            msg_reply.Parse(out _svLineStopMode);
                            msg_reply.Parse(out _svPercentBridgeAlarm);
                            msg_reply.Parse(out _svLimitFeedFactor);
                            msg_reply.Parse(out _svBridgeAlarmDelay);
                            msg_reply.Parse(ref _svLcoName);
                            msg_reply.Parse(out _svStartDelayTime);
                            msg_reply.Parse(out _svStopDelayTime);
                            msg_reply.Parse(out _svMeasTime);
                            msg_reply.Parse(out _svLowPassTime);
                            msg_reply.Parse(out _acthroughputVisu);
                            msg_reply.Parse(out _svDistThrgptFactor);
                            msg_reply.Parse(out _acThrgptDeviation);
                            msg_reply.Parse(out _acdWeightDeviation);
                            msg_reply.Parse(out _acdWeightAverage);
                            msg_reply.Parse(out _acThrgptAverage);
                            msg_reply.Parse(out _acGravRatio);
                            msg_reply.Parse(out _acFeedFactorVisu);
                            msg_reply.Parse(out _svPartRealValues);
                            msg_reply.Parse(out _svReserve2);
                            msg_reply.Parse(out _svDeltaSollAllowed);
                            msg_reply.Parse(out _svResultDistWeight);
                            msg_reply.Parse(out _svRefillBorder);
                            msg_reply.Parse(out _acSaveFeedFactor);
                            msg_reply.Parse(out _svManRefillEna);
                            msg_reply.Parse(out _svDebugFlags);

                            msg_reply.Parse(out _acMsgVersion);
                            msg_reply.Parse(out _svOperatingMode);
                            msg_reply.Parse(out _svManualOutputNom);
                            msg_reply.Parse(out _svKp);
                            msg_reply.Parse(out _svTn);
                            msg_reply.Parse(out _svThroughput);
                            msg_reply.Parse(out _svInitialFeedfactor);
                            msg_reply.Parse(out _svMode1);
                            msg_reply.Parse(out _svMode2);
                            msg_reply.Parse(out _svModeError);
                            msg_reply.Parse(out _svLoaderWcn);
                            msg_reply.Parse(out _svLoaderLco);
                            msg_reply.Parse(out _svPartMiddle);
                            msg_reply.Parse(out _svPartMedian);
                            msg_reply.Parse(out _svDisplayFilter);
                            msg_reply.Parse(out _svDistWeight);
                            msg_reply.Parse(out _svCommandFlagsTestmodus);
                            msg_reply.Parse(out _acFlagsTestmodus);
                            msg_reply.Parse(out _acThroughput);
                            msg_reply.Parse(out _acWeight);
                            msg_reply.Parse(out _acCalStatus);
                            msg_reply.Parse(out _acLineStopMode);
                            msg_reply.Parse(out _acRefillTime);
                            msg_reply.Parse(out _acMedianWeight);
                            msg_reply.Parse(out _acDeviation);
                            msg_reply.Parse(out _acSpeed);
                            msg_reply.Parse(out _acTotal);
                            msg_reply.Parse(out _svFlowRateNom);
                            msg_reply.Parse(out _acFeedFactor2);
                            msg_reply.Parse(out _acOutputNom);
                            msg_reply.Parse(out _acOutputRpm);
                            msg_reply.Parse(out _acControlerStatus);
                            msg_reply.Parse(out _svthroughputMax);
                            _NewFlowrateDetection_Aktiv = true;
                        }
                        else
                        {
                            _acMsgVersion = 0;
                            return false;
                        }
                    }
                       
            }
            
            return true;
        }

        public override bool Update(bool SyncMsg)
		{

            if (SyncMsg)
            {
                XNetMessage msg_reply = this.ReadDefaultDataSet(38, 100, SyncMsg);
                if (msg_reply == null)
                    return false;

                UpdateParser(msg_reply);
            }
            else
            {
                XNetMessage msg_reply = this.ReadDefaultDataSet(38, 100, SyncMsg);
                return true;
            }
            return true;
		}
		#endregion

		#region ErrorHandling


		#endregion

        #region Testmodus und Simulation

        #region svCommandFlagsTestmodus
        private ushort _svCommandFlagsTestmodus = 0;
        public ushort svCommandFlagsTestmodus
        {
            get
            {
                return _svCommandFlagsTestmodus;
            }
            set
            {
                WriteDataPoint(20, 14, value, -1, _svCommandFlagsTestmodus);
            }
        }
        #endregion

        #region Status svTestmode
        public enum svStatusTestMode
        {
            DriveOn = 0,
            poRefill = 1,
            MassFlowError=2, //FastMassFlowValid = 2,
            SetValueChanged=3,//SlowMassFlowValid = 3,
            RampDetected = 4,
            DO_6 = 5,
            DO_7 = 6,
            DO_8 = 7,
            DO_9 = 8,
            DO_10 = 9,
            DO_11 = 10,
            DO_12 = 11,
            DO_13 = 12,
            DO_14 = 13,
            cf_Simu = 14,
            cfTestmodus = 15
        };
        protected bool Has_svTestState(int svstate)
        {
            return (_svCommandFlagsTestmodus & (1 << svstate)) != 0x0000;
        }

        public bool Has_svTestStates(svStatusTestMode svstate)
        {
            return this.Has_svTestState((int)svstate);
        }
        #endregion

        #region acFlagsTestmodus
        private ushort _acFlagsTestmodus = 0;
        public ushort acFlagsTestmodus
        {
            get
            {
                return _acFlagsTestmodus;
            }
        }
        public void Update_acFlagsTestmodus()
        {
            ReadDataPoint(20, 154, ref _acFlagsTestmodus);
        }
        #endregion

        #region Status acTestmode
        public enum acStatusTestMode
        {
            piEnAx = 0,
            piStrAx = 1,
            piErrMot = 2,
            scaleOk = 3,
            wghtAllwd = 4,
            EnRf = 5,
            EnFr = 6,
            EnDrv = 7,
            LineOn = 8,
            LinStrt = 9,
            LocOn = 10,
            Grv = 11,
            FlowrateDetectionValid  = 12,
            FlowrateRawValid = 13,
            DistWeightActive = 14,
            RefillInfluenceActive = 15
        };

        protected bool Has_acTestState(int acstate)
        {
            return (_acFlagsTestmodus & (1 << acstate)) != 0x0000;
        }

        public bool Has_acTestStates(acStatusTestMode acstate)
        {
            return this.Has_acTestState((int)acstate);
        }
        #endregion

        #endregion
        

        #region GetCurve

        public struct CurveParams
        {
            public float X;
            public float Y;
        }
        private CurveParams[] _Curve1;

        public CurveParams[] Curve1
        {
            get
            {
                return _Curve1;
            }
            set
            {
                _Curve1 = value;
            }
        }

        public int Maxwertindex;

        public bool GetCurve()
        {
            XNetMessage msg_reply = ReadDataSet(38, 244, 88);
         
            if (msg_reply == null)
                return false;
            if (msg_reply.Data.Length == 88)
            {
                _Curve1 = new CurveParams[11];
                for (int i = 0; i < _Curve1.Length; i++)
                {
                    msg_reply.Parse(out _Curve1[i].X);
                    msg_reply.Parse(out _Curve1[i].Y);
                }
                Maxwertindex = 0;
                float Maxwert = 0;
                for (int i = 0; i < _Curve1.Length; i++)
                {
                     if (_Curve1[i].X > Maxwert)
                    {
                        Maxwertindex = i;
                        Maxwert = _Curve1[i].X;
                    }
                }    
                return true;
            }
            else
            {
                return false;
            }
        }

        public bool DeleteCurvePoint(byte Pointnumber)
        {
            byte[] data  = new byte[1];
            data[0]=Pointnumber;
            XNetMessage msg_reply = ReadDataSet(38, 244,data, 88);
         
            if (msg_reply == null)
                return false;
            if (msg_reply.Data.Length == 88)
            {
                _Curve1 = new CurveParams[11];
                for (int i = 0; i < _Curve1.Length; i++)
                {
                    msg_reply.Parse(out _Curve1[i].X);
                    msg_reply.Parse(out _Curve1[i].Y);
                }
                Maxwertindex = 0;
                float Maxwert = 0;
                for (int i = 0; i < _Curve1.Length; i++)
                {
                     if (_Curve1[i].X > Maxwert)
                    {
                        Maxwertindex = i;
                        Maxwert = _Curve1[i].X;
                    }
                }    
                return true;
            }
            else
            {
                return false;
            }
        }
        #endregion
    }
}