using System;
using System.IO;
using System.Collections.Generic;
using System.Text;
using Motan.XNet.XNetProtocol;
using System.Windows.Forms;

namespace Motan.XNet.LCO
{
    public class ParaDesrciption 
    {
        private string _Name = null;
        public string Name
        {
            get
            {
                return _Name;
            }
            set
            {
                _Name = value;
            }
        }

        private string _Type = null;
        public string Type
        {
            get
            {
                return _Type;
            }
            set
            {
                _Type = value;
            }
        }

        private string _Function = null;
        public byte Function 
        {			
            get
            {
                return Convert.ToByte(_Function);
            }
            set
            {
                _Function = value.ToString(); 
            }
        }

        private string _SubFunction = null;
        public byte SubFunction
        {
            get
            {
                return Convert.ToByte(_SubFunction);
            }
            set
            {
                _SubFunction = value.ToString();
            }
        }
        private string _Factor = null;
        public double Factor 
        { 
            get 
            {
                return Convert.ToDouble(_Factor);
            }
            set
            {
                _Factor = value.ToString();
            }
        }

        private string _Unit = null;
        public string Unit 
        { 
            get 
            {
                return _Unit;
            }
            set
            {
                _Unit = value;
            }
        }

        
        private string _BitInfo = null;
        public string BitInfo
        {
            get
            {
                return _BitInfo;
            }
            set
            {
                _BitInfo = value;
            }
        }

        


        public ParaDesrciption()
        {
            
        }
    }
    
    public class ParaInfo
    {
        List<ParaDesrciption> parameter = new List<ParaDesrciption>();

        public ParaInfo()
        {
            //Konstruktor
            #region readDefFiles
            string currentDirectory = Directory.GetCurrentDirectory();
            string[] fileEntries = Directory.GetFiles(currentDirectory + @"\Def");
            if(File.Exists(currentDirectory+@"\ParaInfo.txt"))
            {
                File.Delete(currentDirectory + @"\ParaInfo.txt");
            }

                for (int i = 0; i < fileEntries.Length; i++)
                {
                    try
                    {
                        if(fileEntries[i].Contains(".def"))
                        {
                            string[] readText = File.ReadAllLines(fileEntries[i]);
                            for (int k = 0; k < readText.Length; k++)
                            {
                                if (readText[k].Contains("WriteItem") | 
                                   (readText[k].Contains("subfunction=232") & readText[k].Contains("ReadItem")))
                                {
                                    using (StreamWriter sw = new StreamWriter(currentDirectory + @"\ParaInfo.txt", true))
                                    {
                                        sw.WriteLine(readText[k]);
                                    }
                                }        
                            }
                        }  
                    }
                    catch
                    {
                        //ToDo
                    }
                }
            #endregion

            #region Read Parameter Description
            using (StreamReader srPara = new StreamReader("ParaInfo.txt"))
            {
                string line;
                string[] lineElement;
                parameter.Clear();

                while ((line = srPara.ReadLine()) != null)
                { 
                    lineElement=line.Split(new char[]{' '});
                    try
                    {                      
                        ParaDesrciption para = new ParaDesrciption();

                        lineElement[1] = lineElement[1].Remove(0,5);
                        para.Name = lineElement[1];
                        lineElement[2] = lineElement[2].Remove(0, 5);
                        para.Type = lineElement[2];

                        lineElement[3] = lineElement[3].Remove(0, 9);
                        para.Function = Convert.ToByte(lineElement[3]);
                        lineElement[4] = lineElement[4].Remove(0, 12);
                        para.SubFunction = Convert.ToByte(lineElement[4]);


                        if ((lineElement.Length>=6) && (lineElement[5].Contains("si=")))
                        {
                            lineElement[5] = lineElement[5].Remove(0, 3);
                            para.Unit = lineElement[5];

                            if ((lineElement.Length>=7)&&(lineElement[6].Contains("factor=")))
                            {
                                lineElement[6] = lineElement[6].Remove(0, 7);
                                if (lineElement[6].Length == 0)
                                {
                                    lineElement[6] = "1";
                                }
                                para.Factor = Convert.ToDouble(lineElement[6]);
                            }
                            para.BitInfo = "-1";
                        }

                        else
                        {
                            
                            if ((lineElement.Length >= 6) && (lineElement[5].Contains("bits=") | (lineElement[5].Contains("enum="))))
                            {
                                para.BitInfo = lineElement[5];
                                para.Unit = "";
                                para.Factor = -1;
                            }
                            else
                            {
                                para.BitInfo = "-1";
                                para.Unit = "";
                                para.Factor = 1;
                            }
                        }

                        parameter.Add(para);
                        
                    }
                    catch
                    {
                        MessageBox.Show(String.Format("Error while reading definition-Files! \n {0}", line), "Warning");
                        /*
                        #region Exception 
                        Exception e = new Exception(line);
                        throw e;
                        #endregion
                         */
                    }
                }
                parameter.Add(null);
            }
            #endregion         
        }             

        public ParaDesrciption getParaInfo(byte Fnct, byte SbFnct)
        {
            ParaDesrciption para = new ParaDesrciption();
            for (int i = 0; i < parameter.Count; i++)
			{
			   para = parameter[i];
               if(para.Function==Fnct & para.SubFunction==SbFnct)
               {
                   para = parameter[i];
                   break;
               }
               
			}
            return para;
        }

        
    }
}
