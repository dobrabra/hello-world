/* Functional Description
 *    
 * 
 * 
 */
/* Changes:
 * 
 * 
 * 
 * 
 */
using System;
using System.Collections;

using Motan;
using Motan.XNet;
using Motan.XNet.XNetProtocol;


namespace Motan.XNet.LCO
{
	/// <summary>
	/// LCO f�r eine MCG-Komponente
	/// </summary>
    /// 

    public enum MotorWorkingMode
    { Standard, OutputFix, OutputRatio }

	public class Motor_FCT033:LogicalControlObject
	{
		#region Alarm

		public enum AlarmCode 
		{ 
			afMotorNotRunning					= 0,
            afSetpointToHigh                    = 1,
            afSetpointToLow                     = 2,
		};

		public bool HasAlarm(AlarmCode alarmcode)
		{
			return base.HasAlarm((int) alarmcode);
		}

		#endregion
 
		#region Status
	
		public enum StatusCode
		{

			sf01			= 0,
		};

		public bool HasStatus(StatusCode statuscode)
		{
			return base.HasStatus((int) statuscode);
		}

		#endregion

		#region Parameter241

        #region svName
        private XString _svName = new XString(4);
        public string svName
        {
            get
            {
                return (string)_svName;
            }
            set
            {
                WriteDataPoint(33, 1, new XString(_svName.Capacity, value), -1, new XString(_svName.Capacity, _svName));
            }
        }
        #endregion

        #region svMotorGearRatio
        private Int32 _svMotorGearRatio = 0;
        public Int32 svMotorGearRatio
		{
			get
			{
                return _svMotorGearRatio;
			}
			set
			{
                WriteDataPoint(33, 2, value, -1, _svMotorGearRatio);
			}
        }
        #endregion

        #region svScrewSpeedMax
        private int _svScrewSpeedMax = 0;
        public int svScrewSpeedMax
        {
            get
            {
                return _svScrewSpeedMax;
            }
            set
            {
                WriteDataPoint(33, 3, value, -1, _svScrewSpeedMax);
            }
        }
        #endregion

        #region svOutputNom
        private int _svOutputNom = 0;
        public int svOutputNom
        {
            get
            {
                return _svOutputNom;
            }
            set
            {
                WriteDataPoint(33, 4, value, -1, _svOutputNom);
            }
        }
        #endregion

        #region svMotorSpeedMax
        private int _svMotorSpeedMax = 0;
        public float svMotorSpeedMax
        {
            get
            {
                return (float)(_svMotorSpeedMax);
            }
            set
            {
                WriteDataPoint(33, 5, value, -1,    _svMotorSpeedMax);
            }
        }
        #endregion

        #region acOutputNom
        private int _acOutputNom = 0;
        public float acOutputNom
        {
            get
            {
                return (float)(_acOutputNom / 100.0);
            }
        }
        #endregion

        #region acOutputRpm
        private int _acOutputRpm = 0;
        public int acOutputRpm
        {
            get
            {
                return _acOutputRpm;
            }
        }
        #endregion

        #region acOutputHz
        private int _acOutputHz = 0;
        public int acOutputHz
        {
            get
            {
                return _acOutputHz;
            }
        }
        #endregion

        #region acMsgVersion
        private int _acMsgVersion = 0;
        public int acMsgVersion
        {
            get
            {
                return _acMsgVersion;
            }
        }
        #endregion

        #region svMotorStepSize
        private int _svMotorStepSize = 0;
        public int svMotorStepSize
        {
            get
            {
                return _svMotorStepSize;
            }
            set
            {
                WriteDataPoint(33, 6, value, -1, _svMotorStepSize);
            }

        }
        #endregion

        #region svTypeInfo
        private XString _svTypeInfo = new XString(8);
        public string svTypeInfo
        {
            get
            {
                return (string)_svTypeInfo;
            }
            set
            {
                WriteDataPoint(33, 7, new XString(_svTypeInfo.Capacity, value), -1, new XString(_svTypeInfo.Capacity, _svTypeInfo));
            }
        }
        #endregion

        #region svWorkingMode
        private Int32 _svWorkingMode = 0;
        public Int32 svWorkingMode
        {
            get
            {
                return _svWorkingMode;
            }
            set
            {
                WriteDataPoint(33, 8, value, -1, _svWorkingMode);
            }
        }
        #endregion

        #region svOutputFix
        private Int32 _svOutputFix = 0;
        public Int32 svOutputFix
        {
            get
            {
                return _svOutputFix;
            }
            set
            {
                WriteDataPoint(33, 9, value, -1, _svOutputFix);
            }
        }
        #endregion

        #region svOutputRatio
        private Int32 _svOutputRatio = 0;
        public Int32 svOutputRatio
        {
            get
            {
                return _svOutputRatio;
            }
            set
            {
                WriteDataPoint(33, 10, value, -1, _svOutputRatio);
            }
        }
        #endregion

        #region svOutputNomMax
        private Int32 _svOutputNomMax = 0;
        public Int32 svOutputNomMax
        {
            get
            {
                return _svOutputNomMax;
            }
            set
            {
                WriteDataPoint(33, 11, value, -1, _svOutputNomMax);
            }
        }
        #endregion

        #region svOutputNomMin
        private Int32 _svOutputNomMin = 0;
        public Int32 svOutputNomMin
        {
            get
            {
                return _svOutputNomMin;
            }
            set
            {
                WriteDataPoint(33, 12, value, -1, _svOutputNomMin);
            }
        }
        #endregion

        #region svStopLineDriveCmd
        private Int32 _svStopLineDriveCmd = 0;
        public float svStopLineDriveCmd
        {
            get
            {
                return (float)(_svStopLineDriveCmd/100.0);
            }
            set
            {
                if (WriteDataPoint(33, 13, value, -1, _svStopLineDriveCmd))
                {
                    _svStopLineDriveCmd = (Int32)(value * 100.0);
                }
                
            }
        }
        #endregion

        #region svStartLineDriveCmd
        private Int32 _svStartLineDriveCmd = 0;
        public float svStartLineDriveCmd
        {
            get
            {
                return (float)(_svStartLineDriveCmd/100.0);
            }
            set
            {
                if (WriteDataPoint(33, 14, value, -1, _svStartLineDriveCmd))
                {
                    _svStartLineDriveCmd = (Int32)(value * 100.0);
                }
            }
        }
        #endregion

        #region Override Name

        public override string Name
        {
            get
            {
                return _svName;
            }
        }

        #endregion

		#region Commands

		public bool cf01()
		{
			return base.WriteCommand(33,0x0001,-1,_Status);
		}

		#endregion

		#region Factories			
        public Motor_FCT033(ControlNode cn, byte lconr)
            : base(cn, lconr) 
		{
	    }
		#endregion

		#region The Update Method
        public override bool UpdateParser(XNetMessage msg_reply)
        {
            if (msg_reply.Data.Length >= 40)
            {

                msg_reply.Parse(out _acMsgVersion, 36);
                if (_acMsgVersion == 0x160212)
                {
                    if (msg_reply.Data.Length == 64)
                    {
                        msg_reply.Parse(out _Alarm);
                        msg_reply.Parse(out _Status);
                        msg_reply.Parse(ref _svName);
                        msg_reply.Parse(out _svMotorGearRatio);
                        msg_reply.Parse(out _svScrewSpeedMax);
                        msg_reply.Parse(out _svOutputNom);
                        msg_reply.Parse(out _svMotorSpeedMax);
                        msg_reply.Parse(out _acOutputNom);
                        msg_reply.Parse(out _acOutputRpm);
                        msg_reply.Parse(out _acOutputHz);
                        msg_reply.Parse(out _acMsgVersion);
                        msg_reply.Parse(out _svMotorStepSize);
                        msg_reply.Parse(ref _svTypeInfo);
                        msg_reply.Parse(out _svWorkingMode);
                        msg_reply.Parse(out _svOutputFix);
                        msg_reply.Parse(out _svOutputRatio);
                    }
                    else if (msg_reply.Data.Length == 72)
                    {
                        msg_reply.Parse(out _Alarm);
                        msg_reply.Parse(out _Status);
                        msg_reply.Parse(ref _svName);
                        msg_reply.Parse(out _svMotorGearRatio);
                        msg_reply.Parse(out _svScrewSpeedMax);
                        msg_reply.Parse(out _svOutputNom);
                        msg_reply.Parse(out _svMotorSpeedMax);
                        msg_reply.Parse(out _acOutputNom);
                        msg_reply.Parse(out _acOutputRpm);
                        msg_reply.Parse(out _acOutputHz);
                        msg_reply.Parse(out _acMsgVersion);
                        msg_reply.Parse(out _svMotorStepSize);
                        msg_reply.Parse(ref _svTypeInfo);
                        msg_reply.Parse(out _svWorkingMode);
                        msg_reply.Parse(out _svOutputFix);
                        msg_reply.Parse(out _svOutputRatio);
                        msg_reply.Parse(out _svOutputNomMax);
                        msg_reply.Parse(out _svOutputNomMin);
                    }
                    else if (msg_reply.Data.Length == 80)
                    {
                        msg_reply.Parse(out _Alarm);
                        msg_reply.Parse(out _Status);
                        msg_reply.Parse(ref _svName);
                        msg_reply.Parse(out _svMotorGearRatio);
                        msg_reply.Parse(out _svScrewSpeedMax);
                        msg_reply.Parse(out _svOutputNom);
                        msg_reply.Parse(out _svMotorSpeedMax);
                        msg_reply.Parse(out _acOutputNom);
                        msg_reply.Parse(out _acOutputRpm);
                        msg_reply.Parse(out _acOutputHz);
                        msg_reply.Parse(out _acMsgVersion);
                        msg_reply.Parse(out _svMotorStepSize);
                        msg_reply.Parse(ref _svTypeInfo);
                        msg_reply.Parse(out _svWorkingMode);
                        msg_reply.Parse(out _svOutputFix);
                        msg_reply.Parse(out _svOutputRatio);
                        msg_reply.Parse(out _svOutputNomMax);
                        msg_reply.Parse(out _svOutputNomMin);
                        msg_reply.Parse(out _svStopLineDriveCmd);
                        msg_reply.Parse(out _svStartLineDriveCmd);
                    }
                    else
                    {
                        _acMsgVersion = 0;
                        return false;
                    }
                }
                else
                {
                    _acMsgVersion = 0;
                    return false;
                }
            }
            else
            {
                _acMsgVersion = 0;
                return false;
            }
            return true;
        }
        #endregion

        public override bool Update(bool SyncMsg)
		{
            if (SyncMsg)
            {
                XNetMessage msg_reply = this.ReadDefaultDataSet(33, 40, SyncMsg);
                if (msg_reply == null)
                    return false;

                UpdateParser(msg_reply);
            }
            else
            {
                XNetMessage msg_reply = this.ReadDefaultDataSet(33, 40, SyncMsg);
                return true;
            }
			return true;
		}
		

		#region ErrorHandling


		#endregion
    }
        #endregion
}