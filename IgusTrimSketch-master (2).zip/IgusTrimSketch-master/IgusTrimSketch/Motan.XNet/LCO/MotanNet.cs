/* Functional Description
 *    
 * 
 * 
 */
/* Changes:
 * 
 * 160330 by MG(3.0.0.0):	Fehlerbild:		AA16041 LCO Report und LCO UDP nicht vorhanden
					     	Ursache:		Bisher nicht implementiert
					     	Abhilfe:		Fixe Initialisierung der beiden LCO's
					     	Baustein:		MotanNet.cs
 * 
 * 
 */
using System;
using System.Collections;
using Motan;
using Motan.XNet;
using Motan.XNet.LCO;
using Motan.XNet.XNetProtocol;

namespace Motan.MotanNet
{
	public class MotanNetNode:AlarmServerControlNode
	{
		#region Factories
		public MotanNetNode(UDPAdapter udp, ControlNodeInfo cni):base(udp, cni)
		{		
		}
		#endregion

		#region Declaration of LCO's

		public CanLco					TheCanLCO;
		public SystemLCO				SystemLCO;
        public Blendmgr_FCT035[]        Blendmanager;
        public DosComp_FCT036[]         DosComponents;
		public DosFeedControl_FCT038[]	FeedControls;
        public Motor_FCT033[]           Motors;
        public Motor_FCT033[]           Motors2;
        public Scale_FCT034[]           Scales;
        public Modbus_FCT091            TheModbusLCO;
        public Backup_FCT085            TheBackupLCO;
        public EventDataServer          TheEventDataServer;
        public Report                   ReportServer;
        public UDP_FCT252               UDP;


		#endregion

		#region Lokale Indizes

		private int _CurrentNode						= 0;
		private int _CurrentDosComp						= 0;
        
		#endregion

		#region Properties Public Indizes

		#region CurrentNode
		public int CurrentNode
		{
			get { return _CurrentNode; }
			set 
			{
				if (value > 48)
				{
					_CurrentNode = 1;
				}
				else
				{
					if (value<1)
						_CurrentNode = 48;
					else
						_CurrentNode = value;
				}
			}
		}

		#endregion
		#region CurrentDosComp
		public int CurrentDosComp
		{
			get { return _CurrentDosComp; }
			set 
			{
				if (value > DosComponents.Length-1)
				{
                    _CurrentDosComp = 0;
					if (_CurrentDosComp<0)
						_CurrentDosComp = 0;
				}
				else
				{
					if (value<0)
						_CurrentDosComp = DosComponents.Length-1;
					else
						_CurrentDosComp = value;
				}
			}
		}

		#endregion

		#endregion

		#region Initialize

		protected override bool Initialize()
		{
			#region Basisimplementierung aufrufen
			//Basisimplementierung l�st alle LCO - Anmeldungen auf
			if(base.Initialize() == false)
				return false;

			#endregion

			#region vorhandene LCO's auf null stellen, ev. Collections aufr�umen

			Blendmanager    =	null;
			DosComponents   =	null;
			TheCanLCO		=   null;
			FeedControls    =   null;
            TheModbusLCO    =   null;
            TheEventDataServer = null;

            
			#endregion

			#region SystemLCO erzeugen

				this.SystemLCO	= new SystemLCO(this);
				//Wenn das Auslesen fehlschl�gt, dann das SystemLCO
				//wieder abmelden und Ausgangszustand wieder herstellen
				if(SystemLCO.Update(true) == false)
				{
					this.SystemLCO = null;
					return false;
				}

			#endregion

			#region LCO's instanzieren

                byte _lcoNrEventData = 246;
                byte _lcoNrModbus = 247;
                byte _lcoNrBackup = 248;
                byte _lcoNrCan = 250;
                byte _lcoNrReportServer = 251;
                byte _lcoNrUDP = 245;

			{
				#region Blendingmanager �ber Systemdatensatz instanzieren

				Blendmanager = new Blendmgr_FCT035[SystemLCO.acMiniColorStartLCO_Count & 0xFF];
				for(int i=0;i<Blendmanager.Length;i++)
                    Blendmanager[i] = new Blendmgr_FCT035(this, (byte)(i + (SystemLCO.acMiniColorStartLCO_Count >> 8)));	
		
				#endregion

 				#region Dosage �ber Systemdatensatz instanzieren 

				DosComponents = new DosComp_FCT036[SystemLCO.acMCGDosageStartLCO_Count & 0xFF];
				for(int i=0;i<DosComponents.Length;i++)								
					DosComponents[i] = new DosComp_FCT036(this,(byte)(i+(SystemLCO.acMCGDosageStartLCO_Count >> 8)));

				#endregion

				#region FeedControl �ber Datensatz instanzieren
					FeedControls = new DosFeedControl_FCT038[SystemLCO.acGRAVIFlowStartLCO_COUNT & 0xFF];
				for(int i=0;i<FeedControls.Length;i++)								
					FeedControls[i] = new DosFeedControl_FCT038(this,(byte)(i+(SystemLCO.acGRAVIFlowStartLCO_COUNT >> 8)));
				#endregion
                
                #region Feste Instanzierungen

                #region CANLCO 
                TheCanLCO = new CanLco(this, (byte)_lcoNrCan);//Can hat die LCO 250
                #endregion

                #region Motors
                Motors = new Motor_FCT033[8];
                for (int i = 0; i < Motors.Length; i++)
                    Motors[i] = new Motor_FCT033(this, (byte)(i + (221)));
                #endregion

                #region Motors2
                Motors2 = new Motor_FCT033[8];
                for (int i = 0; i < Motors.Length; i++)
                    Motors2[i] = new Motor_FCT033(this, (byte)(i + (231)));
                #endregion

                #region Scales
                Scales = new Scale_FCT034[10];
                for (int i = 0; i < Scales.Length; i++)
                    Scales[i] = new Scale_FCT034(this, (byte)(i + (SystemLCO.acWeightScalesStartLCO_Count >> 8)));
                #endregion

                #region Modbus 
                TheModbusLCO = new Modbus_FCT091(this, (byte)_lcoNrModbus);//Can hat die LCO 248
                #endregion

                #region BackupRestore
                TheBackupLCO = new Backup_FCT085(this, (byte)_lcoNrBackup);
                #endregion

                #region EventDataServer
                TheEventDataServer = new EventDataServer(this, (byte)_lcoNrEventData);
                TheEventDataServer.SetListener();
                #endregion

                #region Report
                ReportServer = new Report(this, (byte)_lcoNrReportServer);
                #endregion

                #region UDP
                UDP = new UDP_FCT252(this, (byte)_lcoNrUDP);
                #endregion

                #endregion

            }
			#endregion

	    	return true;
		}	
		#endregion
	}
}
