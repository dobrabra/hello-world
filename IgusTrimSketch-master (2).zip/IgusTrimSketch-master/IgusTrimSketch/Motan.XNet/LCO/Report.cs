/* Changes:
 * 
 * 
 * 
 */
using System;
using System.Collections;

using Motan;
using Motan.XNet;
using Motan.XNet.XNetProtocol;


namespace Motan.XNet.LCO
{
	/// <summary>
	/// LCO f�r die Volunet-Report LCO
	/// </summary>
	public class Report:LogicalControlObject
	{
		#region Alarm

		public enum AlarmCode
		{
            afAlert_00              = 0,
			afAlert_01				= 1,
			afAlert_02				= 2,
			afAlert_03				= 3,
			afAlert_04				= 4,
			afAlert_05				= 5,
			afAlert_06				= 6,
			afAlert_07				= 7,
			afAlert_08				= 8,
			afAlert_09				= 9,
			afAlert_10				= 10,
			afAlert_11				= 11,
			afAlert_12				= 12,
			afAlert_13				= 13,
			afAlert_14				= 14,
			afAlert_15				= 15,
		};

		public bool HasAlarm(AlarmCode alarmcode)
		{
			return base.HasAlarm((int) alarmcode);
		}

		#endregion

		#region Status

		public enum StatusCode
		{
			sfSendWorkShiftReport	= 0,
			sfSendRecipeReport		= 1,
			sfSendBmConfigReport	= 2,
			sfSendProcessDataReport	= 3,
			sfSendFeedControlReport	= 4,
			sfSendScaleDataReport	= 5,
            sfSendDiagnosticReport  = 7,
            sfSendDiagReportPerCycle  = 8,
        };

		public bool HasStatus(StatusCode statuscode)
		{
			return base.HasStatus((int) statuscode);
		}
			
		#endregion

		#region Parameter

		#region Property svReportGcName
		private XString _svReportGcName=new XString (4,"    ");	// by Ho wegen Kompatibilit�t;Name=String with 4 blanks
		public string svReportGcName
		{
			get
			{
				return (string)_svReportGcName;
			}
//			set		// by Ho : no message defined
//			{
//				WriteDataPoint(70,10, new XString(_svReportGcName.Capacity, value));
//			}
		}

		#endregion
		#region Property svStundeStartSchicht
		private byte _svStundeStartSchicht=0;
		public byte svStundeStartSchicht
		{
			get
			{
				return _svStundeStartSchicht;
			}
			set
			{
				WriteDataPoint(70,1,value,-1,_svStundeStartSchicht);
			}
		}

		#endregion
		#region Property svMinuteStartSchicht
		private byte _svMinuteStartSchicht=0;
		public byte svMinuteStartSchicht
		{
			get
			{
				return _svMinuteStartSchicht;
			}
			set
			{
				WriteDataPoint(70,2,value,-1,_svMinuteStartSchicht);
			}
		}

		#endregion
		#region Property svStundeInterSchicht
		private byte _svStundeInterSchicht=0;
		public byte svStundeInterSchicht
		{
			get
			{
				return _svStundeInterSchicht;
			}
			set
			{
				WriteDataPoint(70,3,value,-1,_svStundeInterSchicht);
			}
		}

		#endregion
		#region Property svMinuteInterSchicht
		private byte _svMinuteInterSchicht=0;
		public byte svMinuteInterSchicht
		{
			get
			{
				return _svMinuteInterSchicht;
			}
			set
			{
				WriteDataPoint(70,4,value,-1,_svMinuteInterSchicht);
			}
		}

		#endregion
		#region Property acUDPListener1
		private NodeAddress _acUDPListener1=NodeAddress.Empty;
		public NodeAddress acUDPListener1
		{
			get
			{
				return _acUDPListener1;
			}		
		}

		#endregion
		#region Property acUDPListener2
		private NodeAddress _acUDPListener2=NodeAddress.Empty;
		public NodeAddress acUDPListener2
		{
			get
			{
				return _acUDPListener2;
			}		
		}

		#endregion
		#region Property svMinuteInterProcess
		private byte _svMinuteInterProcess=0;
		public byte svMinuteInterProcess
		{
			get
			{
				return _svMinuteInterProcess;
			}
			set
			{
				WriteDataPoint(70,7,value,-1,_svMinuteInterProcess);
			}
		}

		#endregion
		#region Property svSekundenInterProcess
		private byte _svSekundenInterProcess=0;
		public byte svSekundenInterProcess
		{
			get
			{
				return _svSekundenInterProcess;
			}
			set
			{
				WriteDataPoint(70,8,value,-1,_svSekundenInterProcess);
			}
		}

		#endregion
		#region Property acMsgVersion
		private int _acMsgVersion=0;
		public int acMsgVersion
		{
			get
			{
				return _acMsgVersion;
			}
		}
		public void Update_acMsgVersion()
		{
			ReadDataPoint(70,149,ref _acMsgVersion);
		}
		#endregion

		#endregion	

		#region Name

		public override string Name
		{
			get
			{
				return _svReportGcName;
			}
		}

		#endregion

		#region Commands

        public void cfSendWorkShiftReport()
		{
			base.WriteCommand(70,0x0001,-1,_Status);
		}

		public void cfSendBmConfigReport()
		{
			base.WriteCommand(70,0x0004,-1,_Status);
		}

		public void cfSendProcessDataReport()
		{
			base.WriteCommand(70,0x0008,-1,_Status);
		}

		public void cfSendFeedControlReport()
		{
			base.WriteCommand(70,0x0010,-1,_Status);
		}

        public void cfSendDiagnosticReport()
        {
            base.WriteCommand(70, 0x0080, -1, _Status);
        }

        public void cfSendDiagReportPerCycle()
        {
            base.WriteCommand(70, 0x0100, -1, _Status);
        }
		#endregion

		#region Factories			
		public Report(ControlNode cn, byte lconr):base(cn,lconr) 
		{
		}
		#endregion

		#region The Update Method
        public override bool UpdateParser(XNetMessage msg_reply)
		{
            if(msg_reply.Data.Length >= 18)
			{
				msg_reply.Parse(out _acMsgVersion,12);
				if(_acMsgVersion == 0x071014) 
				{
					msg_reply.Parse(out _Alarm);
					msg_reply.Parse(out _Status);
					msg_reply.Parse(out _svStundeStartSchicht);
					msg_reply.Parse(out _svMinuteStartSchicht);
					msg_reply.Parse(out _svStundeInterSchicht);
					msg_reply.Parse(out _svMinuteInterSchicht);
					msg_reply.Parse(out _acUDPListener1);
					msg_reply.Parse(out _acUDPListener2);
					msg_reply.Parse(out _acMsgVersion);
					msg_reply.Parse(out _svMinuteInterProcess);
					msg_reply.Parse(out _svSekundenInterProcess);
				}	   
			}
			else
			{
				return false;
			}

			return true;
		}

        public override bool Update(bool SyncMsg)
        {
            if (SyncMsg)
            {
                XNetMessage msg_reply = this.ReadDefaultDataSet(70, 12, SyncMsg);
                if (msg_reply == null)
                    return false;

                UpdateParser(msg_reply);
            }
            else
            {
                XNetMessage msg_reply = this.ReadDefaultDataSet(70, 12, SyncMsg);
                return true;
            }
            return true;
        }
		#endregion
	}
}