/* Functional Description
 *    
 * 
 * 
 */
/* Changes:
 * 
 *              
 * 
 * 
 * 
 */
using System;
using System.Collections;
using System.Collections.Generic;
using Motan;
using Motan.XNet;
using Motan.XNet.XNetProtocol;
using System.Data;
using System.Windows.Forms;
using System.Xml;
using System.IO;


namespace Motan.XNet.LCO
{
    /// <summary>
    /// LCO f�r den EventDataServer
    /// </summary>
    /// 
    public delegate void NotifyEventData(object sender, EventDataServer.EventDataMessage e); 

    public class EventDataServer : LogicalControlObject
    {
        string xmlFilename = "eventhistorie.xml";

        public event NotifyEventData NotifyEventDataEvent;    

        DataSet ds = new DataSet();
        DataSet ProtDataSet = new DataSet();
        int EventDataRowCount = 0;
        DataTable table = null;
        

        #region Name
        public override string Name
        {
            get
            {
                return "Eventserver";
            }
        }
        #endregion

        #region Factories

        public EventDataServer(ControlNode cn, byte lconr)  : base(cn, lconr)
        {

            //ds = new DataSet();
            try
            {
                ProtDataSet.ReadXml(xmlFilename, XmlReadMode.Auto);
            }
            catch
            {
                CreateProtocolXML();
            }

            try
            {
                ProtDataSet.ReadXml(xmlFilename, XmlReadMode.Auto);
            }
            catch 
            {
                #region Exception als XNetError buchen
                byte[] sByteArray = System.Text.Encoding.GetEncoding(1252).GetBytes("Eventerver");
                XNetMessage xme = new XNetMessage(this.Address, this.Address, XNetMessageType.Fault, 0, 0, sByteArray, DataPresentation.BigEndian);
                XNetException xe = new XNetException(xme);
                OnXNetError(xe);
                #endregion
            }

            ProtDataSet = OpenProtocolDataSet(xmlFilename); 
        }

       

        private void CreateProtocolXML()
        {
            
           
            XmlWriter writer = XmlWriter.Create(xmlFilename);
            writer.WriteStartDocument();
            writer.WriteStartElement("EventDatum");

            writer.WriteElementString("DateTime", DateTime.Now.ToString("dd.MM.yy HH:mm:ss"));
            writer.WriteElementString("SourceIP", "0");
            writer.WriteElementString("StationName", "GGP1");
            writer.WriteElementString("TargetLCO", "0");
            writer.WriteElementString("LCOName", "Start History");
            writer.WriteElementString("Funktion", "0");
            writer.WriteElementString("Subfunktion", "0");
            writer.WriteElementString("alterWert", "0");
            writer.WriteElementString("neuerWert", "0");
            writer.WriteElementString("Einheit", "");
            writer.WriteElementString("Parameter", "");
            writer.WriteElementString("userLevel", "0");
            writer.WriteElementString("userName", "");
            writer.WriteEndElement();
            writer.WriteEndDocument();
            writer.Close();
            

        }
        #endregion

        private DataSet OpenProtocolDataSet(string xmlFilename)
        {
            DataSet ds = new DataSet();
            try
            {
                ds.ReadXml(xmlFilename, XmlReadMode.Auto);
            }
            catch
            {
                CreateProtocolXML();
                ds.ReadXml(xmlFilename, XmlReadMode.Auto);
            }
            return ds;
        }

        private void WritePdmToDataSet(EventDataMessage pdm, DataSet ds)
        {        
            try
            {     
                table = ds.Tables[0];
                DataRow newRow = table.NewRow();
               
                newRow["DateTime"] = DateTime.Now.ToString("dd.MM.yyyy HH:mm:ss");
                newRow["SourceIP"] = String.Format("{0}", pdm.acDestWcn);
                newRow["StationName"] = pdm.acStationName;
                newRow["TargetLCO"] = String.Format("{0}", pdm.acDestLco);
                newRow["LCOName"] = pdm.acLcoName;
                newRow["Funktion"] = String.Format("{0}", pdm.acFnct);
                newRow["Subfunktion"] = String.Format("{0}", pdm.acSbFnct);
                newRow["alterWert"] = String.Format("{0}", pdm.acOldValue);
                newRow["neuerWert"] = String.Format("{0}", pdm.acNewValue);
                newRow["Einheit"] = "";
                newRow["Parameter"] = "";
                newRow["userLevel"] = String.Format("{0}", pdm.acUserLevel);
                newRow["userName"] = pdm.acUserName;

                table.Rows.Add(newRow);
                ds.AcceptChanges();



                if (table.Rows.Count > Motan.XNet.ApplicationSettings.CountHistory)
                {
                    int _countToDelete = (table.Rows.Count - Motan.XNet.ApplicationSettings.CountHistory) + 10;

                    for (int i = 1; i < _countToDelete; i++)
                        if (table.Rows.Count > 0)
                            table.Rows.RemoveAt(0);
                    ds.AcceptChanges();
                }

                EventDataRowCount++;
                if (EventDataRowCount >= 100)
                {
                    saveEventsToXML();
                }
                
            }
            catch
            {
                #region Exception als XNetError buchen
                byte[] sByteArray = System.Text.Encoding.GetEncoding(1252).GetBytes("WriteEventToXML");
                XNetMessage xme = new XNetMessage(this.Address, this.Address, XNetMessageType.Fault, 0, 0, sByteArray, DataPresentation.BigEndian);
                XNetException xe = new XNetException(xme);
                OnXNetError(xe);
                #endregion
            }
        }
        
        #region The Update Method
        public override bool UpdateParser(XNetMessage msg_reply)
        {
            if (msg_reply == null || msg_reply.Empty)
                return false;

            EventDataMessage pdm = new EventDataMessage();

            msg_reply.Parse(out pdm.acDestWcn);
            msg_reply.Parse(ref pdm.acStationName);
            msg_reply.Parse(out pdm.acDestLco);
            msg_reply.Parse(ref pdm.acLcoName);
            msg_reply.Parse(out pdm.acFnct);
            msg_reply.Parse(out pdm.acSbFnct);
            msg_reply.Parse(out pdm.acOldValue);
            msg_reply.Parse(out pdm.acNewValue);
            msg_reply.Parse(out pdm.acUserLevel);

            if (ProtDataSet == null)
            {
                ProtDataSet = OpenProtocolDataSet(xmlFilename); 
            }     
            
            
            WritePdmToDataSet(pdm, ProtDataSet);

            if (NotifyEventDataEvent != null)
            {
                NotifyEventDataEvent(this, pdm);
            }
            
            return true;
        }

        public override bool Update(bool SyncMsg)
        {

            if (SyncMsg)
            {
                XNetMessage msg_reply = this.ReadDefaultDataSet(251, 36, SyncMsg);
                if (msg_reply == null)
                    return false;

                UpdateParser(msg_reply);
            }
            else
            {
                XNetMessage msg_reply = this.ReadDefaultDataSet(251, 36, SyncMsg);
                return true;
            }
            return true;
        }

        #endregion

        #region Klassendefinition EventDataMessage

        public class EventDataMessage
        {
            public short acDestWcn;
            public XString acStationName= new XString(4);
            public short acDestLco;
            public XString acLcoName = new XString(4);
            public short acFnct;
            public short acSbFnct;
            public long acOldValue;
            public long acNewValue;
            public short acUserLevel;
            public XString acUserName = new XString(16);
            

            public EventDataMessage()
            {
            }

        }

        #endregion

        #region GetListener Parameter

        private NodeAddress _acEventListener1 = NodeAddress.Empty;
        public NodeAddress acEventListener1
        {
            get
            {
                return _acEventListener1;
            }
        }

        private NodeAddress _acEventListener2 = NodeAddress.Empty;
        public NodeAddress acEventListener2
        {
            get
            {
                return _acEventListener2;
            }
        }

        #endregion

        #region The GetListener Method

        public bool GetListener()
        {
            XNetMessage msg_reply = this.ReadDataSet(251, 253, 4, StandardTimeout);

            if (msg_reply == null)
                return false;

            msg_reply.Parse(out _acEventListener1);
            msg_reply.Parse(out _acEventListener2);

            return true;
        }

        #endregion

        #region Reset Listener
        public bool ResetListener(byte WCN_Nr, byte LCO_Nr)
        {
            DataPresentation dp = CN.DataPresentation;

            byte[] Data = new byte[4];

            Data[0] = WCN_Nr;
            Data[1] = LCO_Nr;

            // f�r das Speichern bekommt die Steuerung 10 mal die DefaultTimeout Zeit...
            return WriteDataSet(251, 251, Data, ApplicationSettings.DefaultTimeout * 10);
        }
        #endregion

        #region Set Listener
        public bool SetListener()
        {
            DataPresentation dp = CN.DataPresentation;

            byte[] Data = new byte[4];

            // f�r das Speichern bekommt die Steuerung 10 mal die DefaultTimeout Zeit...
            return WriteDataSet(251, 250, Data, ApplicationSettings.DefaultTimeout * 10);
        }
        #endregion
     
        #region saveEventsToXML
        public void saveEventsToXML()
        {
            EventDataRowCount = 0;           
            ProtDataSet.WriteXml(xmlFilename);
            ProtDataSet.Dispose();   
        }
        #endregion

        #region getEventDataTable
        public DataTable getEventDataTable()
        {
            DataTable dt = new DataTable();
            DataRow row;
            DataColumn column;

            for (int i = 0; i < ProtDataSet.Tables[0].Columns.Count; i++)
            {
                column = new DataColumn();
                #region switch Anweisung
                switch (i)
                {
                    case 0:
                        column.ColumnName = "DateTime";
                        break;
                    case 1:
                        column.ColumnName = "SourceIP";
                        break;
                    case 2:
                        column.ColumnName = "StationName";
                        break;
                    case 3:
                        column.ColumnName = "TargetLCO";
                        break;
                    case 4:
                        column.ColumnName = "LCOName";
                        break;
                    case 5:
                        column.ColumnName = "Funktion";
                        break;
                    case 6:
                        column.ColumnName = "Subfunktion";
                        break;
                    case 7:
                        column.ColumnName = "alterWert";
                        break;
                    case 8:
                        column.ColumnName = "neuerWert";
                        break;
                    case 9:
                        column.ColumnName = "Einheit";
                        break;
                    case 10:
                        column.ColumnName = "Parameter";
                        break;
                    case 11:
                        column.ColumnName = "userLevel";
                        break;
                    case 12:
                        column.ColumnName = "userName";
                        break;
                    case 13:
                        column.ColumnName = "default";
                        break;
                }
                #endregion
                dt.Columns.Add(column);
            }
       
            try
            {
                
                object[] arr = new object[ProtDataSet.Tables[0].Columns.Count];
                for (int i = 0; i < ProtDataSet.Tables[0].Rows.Count; i++)
                {
                    ProtDataSet.Tables[0].Rows[i].ItemArray.CopyTo(arr, 0);
                    row = dt.NewRow();
                    row["DateTime"] = arr[0].ToString();
                    row["SourceIP"] = arr[1].ToString();
                    row["StationName"] = arr[2].ToString();
                    row["TargetLCO"] = arr[3].ToString();
                    row["LCOName"] = arr[4].ToString();
                    row["Funktion"] = arr[5].ToString();
                    row["Subfunktion"] = arr[6].ToString();
                    row["alterWert"] = arr[7].ToString();
                    row["neuerWert"] = arr[8].ToString();
                    row["Einheit"] = arr[9].ToString();
                    row["Parameter"] = arr[10].ToString();
                    row["userLevel"] = arr[11].ToString();  
                    row["userName"] = arr[12].ToString();
                    dt.Rows.Add(row);
                }
                dt.AcceptChanges();
            }
            catch 
            {
                
                MessageBox.Show("Copy Error","Note", MessageBoxButtons.OK);
            }

            return dt;  
           
        }
        #endregion
         
    }
}
