/* Functional Description
 *    
 * 
 * 
 */
/* Changes:
 * 
 * 
 * 
 * 
 */
using System;
using Motan.XNet.LCO;
using Motan.XNet.XNetProtocol;

namespace Motan.XNet
{
	/// <summary>
	/// Basisklasse f�r ControlNodes, welche einen AlarmServer als LCO beinhalten.
	/// (Ist somit Basisklasse f�r Metro-, Luxor- und GraviNet
	/// </summary>
	public class AlarmServerControlNode : ControlNode
	{

		#region Factories
		internal AlarmServerControlNode(UDPAdapter udp, ControlNodeInfo cni):base(udp, cni)
		{		
		}
		#endregion

		protected override bool Initialize()
		{
			#region Basisimplementierung aufrufen
			//Basisimplementierung l�st alle LCO - Anmeldungen auf
			base.Initialize();
			#endregion

			#region vorhandene LCO's auf null stellen, ev. Collections aufr�umen

			AlarmManager = null;

			#endregion

			#region LCO's instanzieren

			AlarmManager = new Alarmserver(this,(byte)253);

			#endregion

			return true;
		}		


		/// <summary>
		/// Alarm-LCO
		/// </summary>
		public Alarmserver AlarmManager;
	}
}
