/* Functional Description
 *    
 * 
 * 
 */
/* Changes:
 * 
 * 
 * 
 * 
 */
using System;
using System.Collections;

using Motan;
using Motan.XNet;
using Motan.XNet.XNetProtocol;


namespace Motan.XNet.LCO
{
	/// <summary>
	/// LCO f�r eine backup/Restore Komponente
	/// </summary>
    /// 

 	public class UDP_FCT252:LogicalControlObject
	{
 		#region Alarm

		public enum AlarmCode
        {
            afConnectionNotOK = 0,
		};

		public bool HasAlarm(AlarmCode alarmcode)
		{
			return base.HasAlarm((int) alarmcode);
		}

		#endregion
 
		#region Status
	
		public enum StatusCode
		{
            Login_IsLoggedOut=0,
            Login_inLogin=1,
            Login_IsLoggedIn=2,
            Login_inLogOut=3,
            Conn_Passive=4,
            Conn_Ok=5,
            Conn_inCheck=6,
            Conn_Nok=7
		};

		public bool HasStatus(StatusCode statuscode)
		{
			return base.HasStatus((int) statuscode);
		}

		#endregion

		#region Parameter241

        #region Property acMsgVersion
        private int _acMsgVersion = 0;
        public int acMsgVersion
        {
            get
            {
                return _acMsgVersion;
            }
        }
        #endregion

        #region Override Name
        private XString _svName = new XString(4);
         public override string Name
        {
            get
            {
                return _svName;
            }
        }

        #endregion

        #region Property acUdpBroadcastListener
        private NodeAddress _acUdpBroadcastListener =NodeAddress.Empty;
        public NodeAddress acUdpBroadcastListener
        {
            get
            {
                return _acUdpBroadcastListener;
            }
        }
        #endregion
        #region Property Listenertype
        protected byte _Listenertype = 0;
        public byte Listenertype
        {
            get
            {
                return _Listenertype;
            }
        }

        #endregion
        #region Property OffsetPort
        protected byte _OffsetPort = 0;
        public byte OffsetPort
        {
            get
            {
                return _OffsetPort;
            }
        }

        #endregion


        #endregion


        #region Commands

        public bool Login()
        {
            return base.WriteDataPoint(252, 220,0,0,0);
        }

        public bool Login(byte WCN)
        {
            return base.WriteDataPoint(252, 1, WCN, 0,acUdpBroadcastListener.ControlNode);
        }

        public bool Logout()
        {
            return base.WriteDataPoint(252, 221, 0, 0, 0);
        }

 		#endregion

		#region Factories			
        public UDP_FCT252(ControlNode cn, byte lconr)
            : base(cn, lconr) 
		{
	    }
		#endregion

		#region The Update Method
        public override bool UpdateParser(XNetMessage msg_reply)
        {
            if (msg_reply.Data.Length >= 16)
            {
               msg_reply.Parse(out _Alarm);
               msg_reply.Parse(out _Status);
               msg_reply.Parse(out _acMsgVersion);
               msg_reply.Parse(ref _svName);
               msg_reply.Parse(out _acUdpBroadcastListener);
               msg_reply.Parse(out _Listenertype);
               msg_reply.Parse(out _OffsetPort);


               return true;
             }
              else
                 return false;
        }

        public override bool Update(bool SyncMsg)
		{
            if (SyncMsg)
            {
                XNetMessage msg_reply = this.ReadDefaultDataSet(252, 16, SyncMsg);
                if (msg_reply == null)
                    return false;

                UpdateParser(msg_reply);
            }
            else
            {
                XNetMessage msg_reply = this.ReadDefaultDataSet(252, 16, SyncMsg);
                return true;
            }
			return true;
		}
		#endregion

		#region ErrorHandling


		#endregion
	}
}