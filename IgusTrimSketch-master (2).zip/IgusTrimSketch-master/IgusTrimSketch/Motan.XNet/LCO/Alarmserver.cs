/* Functional Description
 *    
 * 
 * 
 */
/* Changes:
 * 29.09.12 AB: Alarmhistory nicht mehr aus PLC lesen, sondern in Datei speichern
 *              neu:CompareMessages;WriteAlarmsToXML;ge�ndert:MessageList 
 * 
 * 
 * 
 */
using System;
using System.Collections;
using Motan;
using Motan.XNet;
using Motan.XNet.XNetProtocol;
using System.Data;
using System.Windows.Forms;


namespace Motan.XNet.LCO
{
	/// <summary>
	/// LCO f�r den Alarmserver
	/// </summary>
	public class Alarmserver : LogicalControlObject
	{
        ArrayList OldMessageList = new ArrayList();

        DataSet dsa = new DataSet();
        DataTable table = null;
        bool restarted = false;

        public AlarmMessage[] ActMessageList;

		#region Status

		public enum StatusCode
		{
			sfSammelalarm			= 0,
			sfSammelmeldung		= 1,
			sfAlarmClass1			= 4,
			sfAlarmClass2			= 5,
			sfNewAlarm				= 6, 
			sfAlarmArchiveExist	= 7
		};

		public bool HasStatus(StatusCode statuscode)
		{
			return base.HasStatus((int) statuscode);
		}

		#endregion

		#region Parameter

		private short _svDummyF01=0;
		public short svDummyF01
		{
			get
			{
				return _svDummyF01;
			}	
		}
		

		private short _acAlarmCounter=0;
		public short acAlarmCounter
		{
			get
			{
				return _acAlarmCounter;
			}
				
		}


		private short _svDummyF03=0;
		public short svDummyF03
		{
			get
			{
				return _svDummyF03;
			}	
		}


		private short _acMessageCounter=0;
		public short acMessageCounter
		{
			get
			{
				return _acMessageCounter;
			}		
		}


		#endregion

		#region Name

		public override string Name
		{
			get
			{
				return "Alarmserver";
			}
		}


		#endregion

		#region Factories			
		public Alarmserver(ControlNode cn, byte lconr):base(cn,lconr) 
		{
            string xmlFilename = "alarmhistory.xml";
            DataSet ds = new DataSet();
            try
            {
                ds.ReadXml(xmlFilename, XmlReadMode.Auto);
            }
            catch
            {
                ds = new DataSet("alarmdataSet");
                ds.Namespace = "NetFrameWork";
                table = new DataTable("table");
                DataColumn kommtGeht = new DataColumn("KommtGeht", Type.GetType("System.String"));
                DataColumn datumUhrzeit = new DataColumn("DatumUhrzeit", Type.GetType("System.String"));
                DataColumn name = new DataColumn("Name", Type.GetType("System.String"));
                DataColumn lco = new DataColumn("Lco", Type.GetType("System.Int32"));
                DataColumn lcotype = new DataColumn("Lcotype", Type.GetType("System.Int32"));
                DataColumn messagecode = new DataColumn("Messagecode", Type.GetType("System.Int32"));
                table.Columns.Add(kommtGeht);
                table.Columns.Add(datumUhrzeit);
                table.Columns.Add(lco);
                table.Columns.Add(name);
                table.Columns.Add(lcotype);
                table.Columns.Add(messagecode);
                ds.Tables.Add(table);

                DataRow newRow = table.NewRow();
                newRow["KommtGeht"] = "K";
                newRow["DatumUhrzeit"] = DateTime.Now.ToString("dd'.'MM'.'yyyy HH':'mm':'ss");
                newRow["Name"] = "Sys";
                newRow["Lcotype"] = 1;
                newRow["Lco"] = 255;
                newRow["Messagecode"] = 6;

                table.Rows.Add(newRow);
                ds.AcceptChanges();
                restarted = true;

            }
            try
            {
                ds.WriteXml(xmlFilename);
                ds.Dispose();
            }
            catch{
                #region Exception als XNetError buchen
                byte[] sByteArray = System.Text.Encoding.GetEncoding(1252).GetBytes("Alarmserver");
                XNetMessage xme = new XNetMessage(this.Address, this.Address, XNetMessageType.Fault, 0, 0, sByteArray, DataPresentation.BigEndian);
                XNetException xe = new XNetException(xme);
                OnXNetError(xe);
                #endregion
            }
		}
		#endregion

		#region The Update Method
        public override bool UpdateParser(XNetMessage msg_reply)
        {
            if (msg_reply.Data.Length == 12)
            {
                msg_reply.Parse(out _Alarm);
                msg_reply.Parse(out _Status);
                msg_reply.Parse(out _svDummyF01);
                msg_reply.Parse(out _acAlarmCounter);
                msg_reply.Parse(out _svDummyF03);
                msg_reply.Parse(out _acMessageCounter);
            }
            else
            {
                return false;
            }

            return true;
        }

        public override bool Update(bool SyncMsg)
		{

            if (SyncMsg)
            {
                XNetMessage msg_reply = this.ReadDefaultDataSet(79, 12, SyncMsg);
                if (msg_reply == null)
                    return false;

                UpdateParser(msg_reply);
            }
            else
            {
                XNetMessage msg_reply = this.ReadDefaultDataSet(79, 12, SyncMsg);
                return true;
            }
            return true;
		}

		#endregion

		#region Klassendefinition AlarmMessage

		public class AlarmMessage
		{
			public AlarmMessage(byte lco, byte lcotype, byte messagecode, byte messagetyp)
			{
				Lco			= lco;
				LcoType		= lcotype;
				MessageCode = messagecode;
				MessageTyp	= messagetyp;
			}

			public readonly byte Lco;
			public readonly byte LcoType;
			public readonly byte MessageCode;
			public readonly byte MessageTyp;

			public override bool Equals(object obj)
			{
				return this == (AlarmMessage) obj;
			}

			public static bool operator!=(AlarmMessage m1, AlarmMessage m2)
			{
				return !(m1 == m2);

			}

			public static bool operator==(AlarmMessage m1, AlarmMessage m2)
			{

				if((object) m1 == null && (object) m2 == null)			return true;
				if((object) m1 == null || (object) m2 == null)			return false;
				if(m1.Lco != m2.Lco)					return false;
				if(m1.LcoType != m2.LcoType)			return false;
				if(m1.MessageCode != m2.MessageCode)	return false;
				if(m1.MessageTyp != m2.MessageTyp)		return false;

				return true;
			}
			public override int GetHashCode()
			{
				return base.GetHashCode ();
			}
		}

		#endregion

		#region Klassendefinition ArchivAlarmMessage

		public class myArchiveAlarmMessageComparer : IComparer  
		{
			// Vergleich via Gehend-Zeitstempel
			int IComparer.Compare( Object x, Object y )  
			{
				if ( ((ArchiveAlarmMessage)x).Gehend > ((ArchiveAlarmMessage)y).Gehend )
				{
					return 1;
				}
				if ( ((ArchiveAlarmMessage)x).Gehend < ((ArchiveAlarmMessage)y).Gehend )
				{
					return -1;
				}				
				return 0 ;
			}
		}


		public class ArchiveAlarmMessage
		{
			public ArchiveAlarmMessage(byte kTag, byte kMonat, byte kStunde, byte kMinute,
												byte gTag, byte gMonat, byte gStunde, byte gMinute,
												byte lco, byte lcotype, byte messagecode, byte messagetyp)
			{
				// �bernahme der Zeitstempel inklusive Pr�fung auf zul�ssige Parameter
				DateTime dt = DateTime.Now;
				int aktMonth = dt.Month;
				int aktJahr = dt.Year;

				try
				{
					if (aktMonth >= kMonat)
					{
						Kommend = new DateTime(aktJahr, kMonat, kTag, kStunde, kMinute, 0 /* Seconds*/);
					}
					else
					{
						Kommend = new DateTime(aktJahr-1, kMonat, kTag, kStunde, kMinute, 0 /* Seconds*/);
					}
				}
				catch
				{
					Kommend = new DateTime(2006, 1, 1, 0, 0, 0 /* Seconds*/);		// auf 01.01.2006 0:00 Uhr setzen
				}

				try
				{
					if (aktMonth >= gMonat)
					{
						Gehend = new DateTime(aktJahr, gMonat, gTag, gStunde, gMinute, 0 /* Seconds*/);
					}
					else
					{
						Gehend = new DateTime(aktJahr-1, gMonat, gTag, gStunde, gMinute, 0 /* Seconds*/);
					}
					}
				catch
				{
					Gehend = new DateTime(2006, 1, 1, 0, 0, 0 /* Seconds*/);		// auf 01.01.2006 0:00 Uhr setzen
				}

				Lco			= lco;
				LcoType		= lcotype;
				MessageCode = messagecode;
				MessageTyp	= messagetyp;
			}

			public readonly DateTime Kommend;
			public readonly DateTime Gehend;
			public readonly byte Lco;
			public readonly byte LcoType;
			public readonly byte MessageCode;
			public readonly byte MessageTyp;

			public override bool Equals(object obj)
			{
				return this == (ArchiveAlarmMessage) obj;
			}


			public static bool operator!=(ArchiveAlarmMessage m1, ArchiveAlarmMessage m2)
			{
				return !(m1 == m2);
			}

			public static bool operator==(ArchiveAlarmMessage m1, ArchiveAlarmMessage m2)
			{
				// Zeitstempel wird ignoriert, sollte bei Anzeige auch nicht gepr�ft werden!
				if((object) m1 == null && (object) m2 == null)			return true;
				if((object) m1 == null || (object) m2 == null)			return false;
				if(m1.Lco != m2.Lco)					return false;
				if(m1.LcoType != m2.LcoType)			return false;
				if(m1.MessageCode != m2.MessageCode)	return false;
				if(m1.MessageTyp != m2.MessageTyp)		return false;

				return true;
			}
			public override int GetHashCode()
			{
				return base.GetHashCode ();
			}
		}

		#endregion

		#region Read list of acual messages / Build Alarmhistory

        #region Alarmhistory
        private void CompareMessages(AlarmMessage[] newbies, ArrayList oldies)
		{
            ArrayList _coming = new ArrayList();
            ArrayList _going = new ArrayList(); 
            ArrayList _oldies = new ArrayList();
            AlarmMessage newbie;
            AlarmMessage oldie;
            bool found = false;

            foreach (Object o in oldies)
                _oldies.Add(o);
            try
            {
                //kommende Alarme suchen
                foreach (AlarmMessage n in newbies)
                {
                    newbie = (AlarmMessage)n;
                    foreach (Object o in oldies)
                    {
                        found = false;
                        oldie = (AlarmMessage)o;
                        if (newbie.Lco == oldie.Lco)
                        {
                            found = true;
                            break;
                        }
                    }
                    if (!found)
                    {
                        _coming.Add(newbie);
                        _oldies.Add(newbie);
                    }
                }

                //gehende Alarme suchen
                foreach (Object o in oldies)
                {
                    oldie = (AlarmMessage)o;
                    foreach (AlarmMessage n in newbies)
                    {
                        found = false;
                        newbie = (AlarmMessage)n;
                        if (newbie.Lco == oldie.Lco)
                        {
                            found = true;
                            break;
                        }
                    }
                    if (!found)
                    {
                        _going.Add(oldie);
                        _oldies.Remove(oldie);
                    }
                }
                oldies.Clear();
                foreach (Object o in _oldies)
                    oldies.Add(o);
            }
            catch
            {
                #region Exception als XNetError buchen
                byte[] sByteArray = System.Text.Encoding.GetEncoding(1252).GetBytes("CompareMessages");
                XNetMessage xme = new XNetMessage(this.Address, this.Address, XNetMessageType.Fault, 0, 0, sByteArray, DataPresentation.BigEndian);
                XNetException xe = new XNetException(xme);
                OnXNetError(xe);
                #endregion
            }

            WriteAlarmsToXML(_coming, _going);
        }

        private void WriteAlarmsToXML(ArrayList _coming, ArrayList _going)
        {
            string xmlFilename = "alarmhistory.xml";
            AlarmMessage newbie;
            if ( (_coming.Count==0) & (_going.Count==0) )
                return;

            DataSet ds = new DataSet();
            try
            {
                ds.ReadXml(xmlFilename, XmlReadMode.Auto);
            }
            catch
            {
               
                ds = new DataSet("alarmdataSet");
                ds.Namespace = "NetFrameWork";
                table = new DataTable("table");
                DataColumn kommtGeht =      new DataColumn("KommtGeht", Type.GetType("System.String"));
                DataColumn datumUhrzeit =   new DataColumn("DatumUhrzeit", Type.GetType("System.DateTime"));
                DataColumn name =           new DataColumn("Name", Type.GetType("System.String"));
                DataColumn lco =            new DataColumn("Lco", Type.GetType("System.Int32"));
                DataColumn lcotype =        new DataColumn("Lcotype", Type.GetType("System.Int32"));
                DataColumn messagecode = new DataColumn("Messagecode", Type.GetType("System.Int32"));
                //DataColumn dateTime = new DataColumn("dateTime", Type.GetType("System.DateTime"));
                table.Columns.Add(kommtGeht);
                table.Columns.Add(datumUhrzeit);
                table.Columns.Add(lco);
                table.Columns.Add(name);
                table.Columns.Add(lcotype);
                table.Columns.Add(messagecode);
                //table.Columns.Add(dateTime);
                ds.Tables.Add(table);
            }
            try
            {
                foreach (Object o in _coming)
                {
                    newbie = (AlarmMessage)o;
                    table = ds.Tables[0];
                    DataRow newRow = table.NewRow();

                    newRow["KommtGeht"] = "K";
                    //newRow["dateTime"] = DateTime.Now;
                    newRow["DatumUhrzeit"] = DateTime.Now.ToString("dd.MM.yyyy HH:mm:ss");

                    #region LCOName holen

                    Motan.XNet.LogicalControlObject AlrmMsglco = this.CN.GetLCO(newbie.Lco);
                    string LCOName;
                    if (AlrmMsglco != null)
                    {
                        LCOName = AlrmMsglco.Name.Trim();	// wenn mit dem LCO bereits einmal kommuniziert wurde, so ist der Name gesetzt
                        if (LCOName == "")   // String mit 4 Blanks bedeutet, Name noch nie gelesen
                        {
                            AlrmMsglco.Update(true);	 // dann Namen holen
                            LCOName = AlrmMsglco.Name.Trim();
                        }
                    }
                    else
                    {
                        LCOName = "----";
                    }
                    #endregion

                    newRow["Name"] = LCOName;
                    newRow["Lcotype"] = newbie.LcoType;
                    newRow["Lco"] = newbie.Lco;
                    newRow["Messagecode"] = newbie.MessageCode;
                    table.Rows.Add(newRow);
                    ds.AcceptChanges();
                }

                foreach (Object o in _going)
                {
                    newbie = (AlarmMessage)o;
                    table = ds.Tables[0];
                    DataRow newRow = table.NewRow();

                    newRow["KommtGeht"] = "G";
                    //newRow["dateTime"] = DateTime.Now;
                    newRow["DatumUhrzeit"] = DateTime.Now.ToString("dd.MM.yyyy HH:mm:ss");

                    #region LCOName holen
                    Motan.XNet.LogicalControlObject AlrmMsglco = this.CN.GetLCO(newbie.Lco);
                    string LCOName;
                    if (AlrmMsglco != null)
                    {
                        LCOName = AlrmMsglco.Name.Trim();	// wenn mit dem LCO bereits einmal kommuniziert wurde, so ist der Name gesetzt
                        if (LCOName == "")   // String mit 4 Blanks bedeutet, Name noch nie gelesen
                        {
                            AlrmMsglco.Update(true);	 // dann Namen holen
                            LCOName = AlrmMsglco.Name.Trim();
                        }
                    }
                    else
                    {
                        LCOName = "----";
                    }
                    #endregion

                    newRow["Name"] = LCOName;
                    newRow["Lco"] = newbie.Lco;
                    newRow["Lcotype"] = newbie.LcoType;
                    newRow["Messagecode"] = newbie.MessageCode;
                    table.Rows.Add(newRow);
                    ds.AcceptChanges();
                }
                if (table.Rows.Count > Motan.XNet.ApplicationSettings.CountHistory)
                {
                    int _countToDelete = (table.Rows.Count - Motan.XNet.ApplicationSettings.CountHistory)+10;

                    for (int i = 1; i < _countToDelete; i++)
                        if (table.Rows.Count>0) 
                            table.Rows.RemoveAt(0);
                    ds.AcceptChanges();
                }

                ds.WriteXml(xmlFilename);
                ds.Dispose();
            }
            catch
            {
                #region Exception als XNetError buchen
                byte[] sByteArray = System.Text.Encoding.GetEncoding(1252).GetBytes("WriteAlarmsToXML");
                XNetMessage xme = new XNetMessage(this.Address, this.Address, XNetMessageType.Fault,0,0,sByteArray,DataPresentation.BigEndian);
                XNetException xe = new XNetException(xme);
                OnXNetError(xe);
                #endregion
            }
        }
        #endregion

        public AlarmMessage [] MessageList
		{
			get
			{
                AlarmMessage[] _ml = GetMessages();
                if (!restarted)
                {
                    OldMessageList.Clear();
                    for (int i=0; i<_ml.Length;i++)
                        OldMessageList.Add(_ml[i]);
                    restarted = true;
                }

                CompareMessages(_ml, OldMessageList);
                ActMessageList = _ml;
				return _ml;
			}
		}

		private AlarmMessage [] GetMessages()
		{
			XNetMessage msg_reply = this.ReadDataSet(79, 242, Int32.MaxValue);

			if(msg_reply == null || msg_reply.Empty)
				return new AlarmMessage[0];

			int anzElements = msg_reply.Data.Length/4; //Muss man noch testen

			AlarmMessage [] m = new AlarmMessage[anzElements];
			byte lco=0;
			byte lcotype=0;
			byte messagecode=0;
			byte messagetyp=0;

			for(int i=0; i<m.Length; i++)
			{
				msg_reply.Parse(out lco);
				msg_reply.Parse(out lcotype);
				msg_reply.Parse(out messagecode);
				msg_reply.Parse(out messagetyp);

				m[i] = new AlarmMessage(lco, lcotype, messagecode, messagetyp);
			}
			return m;
		}

		#endregion

		#region Klassendefinition WartungsMessage

		public class MaintMessage
		{
			public MaintMessage(byte lco, byte lcotype, byte messagecode, byte messagetyp)
			{
				Lco			= lco;
				LcoType		= lcotype;
				MessageCode = messagecode;
				MessageTyp	= messagetyp;
			}

			public readonly byte Lco;
			public readonly byte LcoType;
			public readonly byte MessageCode;
			public readonly byte MessageTyp;

			public override bool Equals(object obj)
			{
				return this == (MaintMessage) obj;
			}

			public static bool operator!=(MaintMessage m1, MaintMessage m2)
			{
				return !(m1 == m2);
			}

			public static bool operator==(MaintMessage m1, MaintMessage m2)
			{

				if((object) m1 == null && (object) m2 == null)			return true;
				if((object) m1 == null || (object) m2 == null)			return false;
				if(m1.Lco != m2.Lco)					return false;
				if(m1.LcoType != m2.LcoType)			return false;
				if(m1.MessageCode != m2.MessageCode)	return false;
				if(m1.MessageTyp != m2.MessageTyp)		return false;

				return true;
			}
			public override int GetHashCode()
			{
				return base.GetHashCode ();
			}

		}

		#endregion

		#region Read list of acual Maintenance messages

		public MaintMessage [] MaintMessageList
		{
			get
			{
				return GetMaintMessages();
			}
		}

		private MaintMessage [] GetMaintMessages()
		{
			XNetMessage msg_reply = this.ReadDataSet(79, 243, Int32.MaxValue);

			if(msg_reply == null || msg_reply.Empty)
				return new MaintMessage[0];

			int anzElements = msg_reply.Data.Length/4; //Muss man noch testen

			MaintMessage [] m = new MaintMessage[anzElements];
			byte lco=0;
			byte lcotype=0;
			byte messagecode=0;
			byte messagetyp=0;

			for(int i=0; i<m.Length; i++)
			{
				msg_reply.Parse(out lco);
				msg_reply.Parse(out lcotype);
				msg_reply.Parse(out messagecode);
				msg_reply.Parse(out messagetyp);

				m[i] = new MaintMessage(lco, lcotype, messagecode, messagetyp);
			}

			return m;
		}


		#endregion

		#region Read list of archive messages

		public ArchiveAlarmMessage [] ArchiveMessageList
		{
			get
			{
				return GetArchiveMessages();
			}
		}

		private ArchiveAlarmMessage [] GetArchiveMessages()
		{
			XNetMessage msg_reply = this.ReadDataSet(79, 244, Int32.MaxValue);

			if(msg_reply == null || msg_reply.Empty)
				return new ArchiveAlarmMessage[0];

			int anzElements = msg_reply.Data.Length/12; //Muss man noch testen

			ArchiveAlarmMessage [] m = new ArchiveAlarmMessage[anzElements];

			byte kTag=0;
			byte kMonat=0;
			byte kStunde=0;
			byte kMinute=0;
			byte gTag=0;
			byte gMonat=0;
			byte gStunde=0;
			byte gMinute=0;

			byte lco=0;
			byte lcotype=0;
			byte messagecode=0;
			byte messagetyp=0;

			for(int i=0; i<m.Length; i++)
			{
				msg_reply.Parse(out kTag);
				msg_reply.Parse(out kMonat);
				msg_reply.Parse(out kStunde);
				msg_reply.Parse(out kMinute);
				msg_reply.Parse(out gTag);
				msg_reply.Parse(out gMonat);
				msg_reply.Parse(out gStunde);
				msg_reply.Parse(out gMinute);

				msg_reply.Parse(out lco);
				msg_reply.Parse(out lcotype);
				msg_reply.Parse(out messagecode);
				msg_reply.Parse(out messagetyp);

				m[i] = new ArchiveAlarmMessage(kTag, kMonat, kStunde, kMinute,
														gTag, gMonat, gStunde, gMinute,
														lco, lcotype, messagecode, messagetyp);
			}

			return m;
		}


		#endregion

		#region GetListener Parameter
		
		private NodeAddress _acAlarmListener1=NodeAddress.Empty;
		public NodeAddress acAlarmListener1
		{
			get
			{
				return _acAlarmListener1;
			}		
		}

		private NodeAddress _acAlarmListener2=NodeAddress.Empty;
		public NodeAddress acAlarmListener2
		{
			get
			{
				return _acAlarmListener2;
			}		
		}

		#endregion

		#region The GetListener Method

		public bool GetListener()
		{
			XNetMessage msg_reply = this.ReadDataSet(79, 253, 4, StandardTimeout);

			if(msg_reply==null)
				return false;

			msg_reply.Parse(out _acAlarmListener1);
			msg_reply.Parse(out _acAlarmListener2);

			return true;
		}

		#endregion

		#region The GetAlarmTextIDMethod

		public static int GetAlarmTextID(int lcoTyp, int alarmcode)
		{
			// In der Stringtable sind f�r die LCO-Typen 1-255 enthalten
			// mit jeweils 64 Alarmbits ab ID 20000
			//Speziell f�r die LCO 249 liegen ab ID 37000 die Alarme f�r 256 Sonderalarme,
			//k�nnen bei Bedarf auch noch erweitert werden!

			if ((int)lcoTyp==249)
				return 37000 + alarmcode;
			else
			{
				if (((int)lcoTyp<=255)&&((int)lcoTyp>0))
				{
					return 20000 + (((int)lcoTyp - 1) * 64) + alarmcode;
				}
				else
					return 37000 + alarmcode;
			}


		}
		#endregion

		#region Reset Listener
		public bool ResetListener(byte WCN_Nr, byte LCO_Nr)
		{
			DataPresentation dp = CN.DataPresentation;

			byte [] Data = new byte[4];

			Data[0] = WCN_Nr;
			Data[1] = LCO_Nr;

			// f�r das Speichern bekommt die Steuerung 10 mal die DefaultTimeout Zeit...
            return WriteDataSet(79, 251, Data, StandardTimeout * 10);
		}
		#endregion

 

	}
}
