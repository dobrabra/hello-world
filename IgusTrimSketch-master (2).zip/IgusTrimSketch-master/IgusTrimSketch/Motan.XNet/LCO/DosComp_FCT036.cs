/* Functional Description
 *    
 * 
 * 
 */
/* Changes:
 * 
 * 
 * 
 * 
 */
using System;
using System.Collections;

using Motan;
using Motan.XNet;
using Motan.XNet.XNetProtocol;


namespace Motan.XNet.LCO
{
	/// <summary>
	/// LCO f�r eine DosierKomponente
	/// </summary>
	public class DosComp_FCT036:LogicalControlObject
	{
        #region Alarm

		public enum AlarmCode
		{
			afThroughputLOW			= 0,//(*Alarm.0 Durchsatz zu niedrig, *)
			afThroughputHigh		= 1,//(*Alarm.1 Durchsatz zu hoch	%*)
			afMotorBusAlarm			= 2,//(*Alarm.2 Dosiermotor antwortet nicht*)
			afRefillFault			= 3,//(*Alarm.3 Nachf�llfehler*)
			afLevelMIN				= 4,//(*Alarm.4 Minimumlevel unterschritten*)
			afMotorBlocked			= 5,//(*Alarm.5 Dosiermotor blockiert*)
			afMotorParaError		= 6,//(*Alarm.6 Getriebepara stimmen nicht*)
			afAlert_07				= 7,	
			afAlert_08				= 8,	
			afAlert_09				= 9,	
			afAlert_10				= 10,	
			afAlert_11				= 11,	
			afAlert_12				= 12,	
			afAlert_13				= 13,	
			afAlert_14				= 14,	
			afAlert_15				= 15,	
			afAlert_16				= 16,			
		}

        public bool HasAlarm(AlarmCode alarmcode)
        {
            return base.HasAlarm((int)alarmcode);
        }

        //public bool HasAlarm()
        //{
        //    if (_Alarm != 0)
        //        return true;

        //    else return false;
        //}

		#endregion

		#region Status
		public enum StatusCode
		{
			sfCalibrationInProgress = 0,	//(*Status.0 RESERVE*)
			sfOnOff					= 1,	//(*Status.1 Komponente an/Aus*)
			sfMotorOnOff			= 2,	//(*Status.2 RESERVE*)
			sfRefill				= 3,	//(*Status.3 Bef�llung aktiv true=aktiv*)
			sfManualControl			= 4,	//(*Status.4 Manuell true=aktiv*)
			sfLevelMinOnOff			= 5,	//(*Status.5 Minimumsonde aktiviert/deaktiviert*)
			sfLevelMin				= 6,	//(*Status.6 Minimumsonde*)
			sfModeCalib				= 7,	//(*Status.7 Modus Material kalibrieren*)
			sfMotorRun				= 8,	//(*Status.8 Motor laeuft *)
			sfModeManu				= 9,	//(*Status.9 RESERVE*)
			sfDeActivated			= 10,	//(*Status.10 Deaktiviert*)
			sfEnabled				= 11	//(*Status.11 Enabled*)
		};

		public bool HasStatus(StatusCode statuscode)
		{
			return base.HasStatus((int) statuscode);
		}
		#endregion
		
		#region Parameter241
		#region Property svParts
		private int _svParts=0;
		public int svParts
		{
			get
			{
				return _svParts*_PartsFactor;
			}
			set
			{
				WriteDataPoint(36,1,value/_PartsFactor,-1,_svParts/_PartsFactor);
			}
		}
		#region Property PartsFactor
		private int _PartsFactor=10;
		public int PartsFactor
		{
			get
			{
				return _PartsFactor;
			}
		}
		#endregion

		#endregion
        #region Property svPercentage
        private float _svPercentage = 0;
        public float svPercentage
        {
            get
            {
                return _svPercentage;
            }
            set
            {
                //               WriteDataPoint(36, 9, value, -1, _svPercentage);
            }
        }
        #endregion
        #region Property svThroughput
        private float _svThroughput = 0;
        public float svThroughput
        {
            get
            {
                return (_svThroughput);
            }
            set
            {
                //               WriteDataPoint(36, 9, value, -1, _svThroughput);
            }
        }
               #endregion
        #region Property svName
        private XString _svName = new XString(4);
        public string svName
        {
            get
            {
                return (string)_svName;
            }
            set
            {
                WriteDataPoint(36, 7, new XString(_svName.Capacity, value), -1, new XString(_svName.Capacity, _svName));
            }
        }

        #endregion
        #region Property svScale1
        private byte _svScale1 = 0;
        public byte svScale1
        {
            get
            {
                return _svScale1;
            }
        }
        #endregion
        #region Property svScale2
        private byte _svScale2 = 0;
        public byte svScale2
        {
            get
            {
                return _svScale2;
            }
        }
        #endregion
        #region Property svScale3
        private byte _svScale3 = 0;
        public byte svScale3
        {
            get
            {
                return _svScale3;
            }
        }
        #endregion
        #region Property svScale4
        private byte _svScale4 = 0;
        public byte svScale4
        {
            get
            {
                return _svScale4;
            }
        }
        #endregion
        #region Property svMotor1
        private byte _svMotor1 = 0;
        public byte svMotor1
        {
            get
            {
                return _svMotor1;
            }
        }
        #endregion
        #region Property svMotor2
        private byte _svMotor2 = 0;
        public byte svMotor2
        {
            get
            {
                return _svMotor2;
            }
        }
        #endregion
        #region Property svMotor3
        private byte _svMotor3 = 0;
        public byte svMotor3
        {
            get
            {
                return _svMotor3;
            }
        }
        #endregion
        #region Property svMotor4
        private byte _svMotor4 = 0;
        public byte svMotor4
        {
            get
            {
                return _svMotor4;
            }
        }
        #endregion
        #region Property res3
        private int _res3 = 0;
        public int res3
        {
            get
            {
                return _res3;
            }
            set
            {
                //               WriteDataPoint(36, 9, value, -1, _res3);
            }
        }
               #endregion
        #region Property res4
        private int _res4 = 0;
        public int res4
        {
            get
            {
                return _res4;
            }
            set
            {
                //               WriteDataPoint(36, 9, value, -1, _res4);
            }
        }
        #endregion
		#region Property svMaterialType
		private byte _svMaterialType=0;
		public byte svMaterialType
		{
			get
			{
				return _svMaterialType;
			}
			set
			{
				WriteDataPoint(36,2,value,-1,_svMaterialType);
			}
		}

		#endregion
        #region Property res5
        private byte _res5 = 0;
        public byte res5
        {
            get
            {
                return _res5;
            }
            set
            {
                //               WriteDataPoint(36, 9, value, -1, _res5);
            }
        }
                #endregion
        #region Property res6
        private short _res6 = 0;
        public short res6
        {
            get
            {
                return _res6;
            }
            set
            {
                //               WriteDataPoint(36, 9, value, -1, _res5);
            }
        }
        #endregion
        #region Property res7
        private int _res7 = 0;
        public int res7
        {
            get
            {
                return _res7;
            }
            set
            {
                //               WriteDataPoint(36, 9, value, -1, _res6);
            }
        }
        #endregion
        #region Property acMsgVersion
        private int _acMsgVersion = 0;
        public int acMsgVersion
        {
            get
            {
                return _acMsgVersion;
            }
        }
        #endregion
        #region Property svMaterialId
        private XString _svMaterialId = new XString(8);
        public string svMaterialId
        {
            get
            {
                return (string)_svMaterialId;
            }
            set
            {
                WriteDataPoint(36, 11, new XString(_svMaterialId.Capacity, value), -1, new XString(_svMaterialId.Capacity, _svMaterialId));
            }
        }
        #endregion
        #region Property svWorkingMode
        private short _svWorkingMode = 0;
        public short svWorkingMode
        {
            get
            {
                return _svWorkingMode;
            }
        }
        #endregion
        #region Property svCompoundMode
        private short _svCompoundMode = 0;
        public short svCompoundMode
        {
            get
            {
                return _svCompoundMode;
            }
            set
            {
                WriteDataPoint(36, 13, value, -1, _svCompoundMode);
            }
        }
               #endregion
        #region Property svDosDevice
        private short _svDosDevice = 0;
        public short svDosDevice
        {
            get
            {
                return _svDosDevice;
            }
            set
            {
                WriteDataPoint(36, 14, value, -1, _svDosDevice);
            }
        }
        #endregion
        #region Property svInitialFeedFactor
        private float _svInitialFeedFactor = 0;
        public float svInitialFeedFactor
        {
            get
            {
                return _svInitialFeedFactor;
            }
            set
            {
                //               WriteDataPoint(36, 9, value, -1, _svInitialFeedFactor );
            }
        }
        #endregion
	    #endregion

		#region Name

		public override string Name
		{
			get
			{
				return _svName;
			}
		}
		#endregion

		#region Commands
		public  bool cfBit0()
		{
			return base.WriteCommand(36,0x0001,-1,_Status);
		}

		public  bool cfMotorOnOff()
		{
			return base.WriteCommand(36,0x0002,-1,_Status);
		}

		public  bool cfStartCalibration()
		{
			return base.WriteCommand(36,0x0004,-1,_Status);
		}

		public  bool cfBit3()
		{
			return base.WriteCommand(36,0x0008,-1,_Status);
		}
		//*****************************
		public  bool cfBit4()
		{
			return base.WriteCommand(36,0x0010,-1,_Status);
		}

		public  bool cfModeManu()
		{
			return base.WriteCommand(36,0x0020,-1,_Status);
		}

		public  bool cfLevelMinOnOff()
		{
			return base.WriteCommand(36,0x0040,-1,_Status);
		}

		public  bool cfSetMotorConf()
		{
			return base.WriteCommand(36,0x0080,-1,_Status);
		}
		//*****************************
		public  bool cfSetMotorAdress()
		{
			return base.WriteCommand(36,0x0100,-1,_Status);
		}

		public  bool cfBit9()
		{
			return base.WriteCommand(36,0x0200,-1,_Status);
		}

		public  bool cfBit10()
		{
			return base.WriteCommand(36,0x0400,-1,_Status);
		}

		public  bool cfBit11()
		{
			return base.WriteCommand(36,0x0800,-1,_Status);
		}
		//*****************************
		public  bool cfDeactivate()
		{
			return base.WriteCommand(36,0x1000,-1,_Status);
		}

		public  bool cfBit13()
		{
			return base.WriteCommand(36,0x2000,-1,_Status);
		}

		public  bool cfBit14()
		{
			return base.WriteCommand(36,0x4000,-1,_Status);
		}

		public  bool cfBit15()
		{
			return base.WriteCommand(36,0x8000,-1,_Status);
		}
		#endregion

		#region Factories			
		public DosComp_FCT036(ControlNode cn, byte lconr):base(cn,lconr) 
		{
	    }
		#endregion

		#region The Update Method
        public override bool UpdateParser(XNetMessage msg_reply)
        {
            if (msg_reply.Data.Length >= 48)
            {
                msg_reply.Parse(out _acMsgVersion, 44);
                if (_acMsgVersion == 0x300112)
                {
                    if (msg_reply.Data.Length == 66)
                    {
                        _PartsFactor = 1;
                        msg_reply.Parse(out _Alarm);
                        msg_reply.Parse(out _Status);
                        msg_reply.Parse(out _svParts);
                        msg_reply.Parse(out _svPercentage);
                        msg_reply.Parse(out _svThroughput);
                        msg_reply.Parse(ref _svName);
                        msg_reply.Parse(out _svScale1);
                        msg_reply.Parse(out _svScale2);
                        msg_reply.Parse(out _svScale3);
                        msg_reply.Parse(out _svScale4);
                        msg_reply.Parse(out _svMotor1);
                        msg_reply.Parse(out _svMotor2);
                        msg_reply.Parse(out _svMotor3);
                        msg_reply.Parse(out _svMotor4);
                        msg_reply.Parse(out _res3);
                        msg_reply.Parse(out _res4);
                        msg_reply.Parse(out _svMaterialType);
                        msg_reply.Parse(out _res5);
                        msg_reply.Parse(out _res6);
                        msg_reply.Parse(out _res7);
                        msg_reply.Parse(out _acMsgVersion);
                        msg_reply.Parse(ref _svMaterialId);
                        msg_reply.Parse(out _svWorkingMode);
                        msg_reply.Parse(out _svCompoundMode);
                        msg_reply.Parse(out _svDosDevice);
                        msg_reply.Parse(out _svInitialFeedFactor);

                    }
                    else
                    {
                        _acMsgVersion = 0;
                        return false;
                    }
                }
                else
                {
                    _acMsgVersion = 0;
                    return false;
                }
            }
            else
            {
                _acMsgVersion = 0;
                return false;
            }
            return true;
        }

        public override bool Update(bool SyncMsg)
		{

            if (SyncMsg)
            {
                XNetMessage msg_reply = this.ReadDefaultDataSet(36, 44, SyncMsg);
                if (msg_reply == null)
                    return false;

                UpdateParser(msg_reply);
            }
            else
            {
                XNetMessage msg_reply = this.ReadDefaultDataSet(36, 44, SyncMsg);
                return true;
            }
            return true;
		}
		#endregion
	}
}