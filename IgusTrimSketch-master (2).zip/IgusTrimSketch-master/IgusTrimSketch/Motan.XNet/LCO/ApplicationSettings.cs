/*------------------------------------------------------------------------------*\
 * Fa. Teslab - Otmar Ganahl
 * Abh�ngigkeiten: Frameword 1.1, CF 1.1
 * Letzte �nderung: 14.11.2003
 *                  25.07.2005 Verschieben von Motan.XNetView in Motan.XNet (by Ho)
 * 051012 by Ho	Einbinden Item "EasyProgramExit" zum einfachen Beenden der netVISU f�r Entwickler
\*------------------------------------------------------------------------------*/
/* Functional Description
 *    
 * 
 * 
 */
/* Changes:
 * 
 * 160330 by MG(3.0.0.0):	Fehlerbild:		AA16041 Mehrfachaufrufe der Applikation f�r PC geht nicht
					     	Ursache:		Es wurde nur 1 Proze� zugelassen
					     	Abhilfe:		Neue Variable CountProcesses als geheimer Parameter in AppConfig
											Standardeinstellung ist 1, damit wird er NICHT in die Appconfig geschrieben.
											Werte >1 werden in die Appconfig geschrieben
					     	Baustein:		ApplicationSettings.cs  
 * 
 * 
 */

using System;
using System.IO;
using System.Reflection;
using System.Xml;
using System.Windows.Forms;


namespace Motan.XNet
{
    /// <summary>
    /// Ersatz der XML Konfiguration f�r das CF
    /// </summary>
    /// <remarks>
    /// Die Klasse bietet Funktionalitat�ten um eie Konfigurationsdatei auszulesen und
    /// zu manipulieren. Die Klasse funktioniert nur dann richtig, wenn im Hauptmodul (exe)
    /// die Methode Init aufgerufen wurde. Mit diesem Aufruf wird das Application
    /// Assembly ermittelt. Die Konfigurationsdatei selbst muss auf auf dem Panel den
    /// fixen Namen "App.config" besitzen.
    /// </remarks>
    public class ApplicationSettings
	{
        public enum MachineType
        {
            Extrusion = 0,
            DCIM = 1
        };

		public static bool IsStartWithParam = false;	// Hinzu f�r Start mit �bergabeparameter
		public static bool IsStartfromLinkNet = false;	// Hinzu f�r Start mit �bergabeparameter von Linknet
		public static string startupmask="";	// Hinzu f�r Start mit �bergabeparameter
		public static int startupindexoffset=0;	// Hinzu f�r Start mit �bergabeparameter
        public static bool AppconfigExists = false;

		public static uint State2LN=0;	// Statuswort zum Austausch mit Linknet
										// bit0 = set listener of current plc, will be cleared by Linknet
										// bit1 = ...

		private static string _ConfigFilename;
		private static string AppPath;					// 2do, 050411 by Ho: Problem private, sollte public sein <----> field!!!!
		/// <summary>
		/// Initialisierungsroutine
		/// </summary>
		/// <remarks>Diese Methode muss im Hauptmodul einmal aufgerufen werden.</remarks>
		public static void Init()
		{
			try
			{
				System.Reflection.Module AppModule   = Assembly.GetCallingAssembly().GetModules()[0];

				AppPath = Path.GetDirectoryName(AppModule.FullyQualifiedName);
				// Das Config File heisst wie die "App.config"
				_ConfigFilename = Path.Combine(AppPath, "AppConfig.txt");
				Load();
                if (DefaultTimeout < 100)
                    DefaultTimeout = 100;
                if (CountProcesses < 1)
                    CountProcesses = 1;
			}
			catch {}
		}

		/// <summary>
		/// Liefert den Applikationspfad der Anwendung zur�ck.
		/// </summary>
		public static string GetAppPath()
		{
			return AppPath;
		}

		/// <summary>
		/// Speichert die aktuellen Applicatiosettings ins Konfigurationsfile.
		/// </summary>
		public static void Save()
		{
			XmlTextWriter tw =new XmlTextWriter(_ConfigFilename, System.Text.Encoding.Default);
			tw.Formatting = Formatting.Indented;
			tw.WriteStartDocument();
			
			tw.WriteStartElement("AppSettings");

			SaveFields(tw, "", typeof(ApplicationSettings));

			tw.WriteEndElement(); // AppSettings
			tw.Close();
		}


		private static void SaveFields(XmlTextWriter tw, string Prefix, object o)
		{
			if(o == null)
				return;

			FieldInfo[] fields;

			if(o is Type)
			{
				fields = ((Type) o).GetFields(BindingFlags.Public | BindingFlags.Static);
				o = null;
			}
			else
				fields = o.GetType().GetFields(BindingFlags.Public | BindingFlags.Instance);


			foreach(FieldInfo fi in fields)
			{
				//Die hier angegebenen Variablen werden nicht in die AppConfig.txt geschrieben
				if ((fi.Name == "IsStartWithParam") || (fi.Name == "startupmask") ||(fi.Name == "startupindexoffset") ||(fi.Name == "dResolution")
                    || (fi.Name == "IsStartfromLinkNet") || (fi.Name == "State2LN") || (fi.Name == "AppconfigExists"))
					continue;
				
				if(fi.FieldType.IsClass && fi.FieldType != typeof(string))
				{
					// Reference Type -> die Properties des Types speichern
					SaveFields(tw, Prefix + fi.Name + ".", fi.GetValue(o));
				}
				else
				{
					// Value Type

					if(fi.Name == "EasyProgramExit")	// 051012 by Ho interner geheimer Parameter
					{
						if(fi.GetValue(o).ToString() == "True")
						{
							string val = fi.FieldType.IsEnum == false ? fi.GetValue(o).ToString() : ((int) fi.GetValue(o)).ToString();
							tw.WriteStartElement("Setting");
							tw.WriteAttributeString("name", Prefix + fi.Name);
							tw.WriteAttributeString("value", val);
							tw.WriteEndElement();
						}
					}
					else
					{
						if(fi.Name == "OnlyGuestLevelActive")	// 070222 by Ho interner geheimer Parameter
						{
							if(fi.GetValue(o).ToString() == "True")
							{
								string val = fi.FieldType.IsEnum == false ? fi.GetValue(o).ToString() : ((int) fi.GetValue(o)).ToString();
								tw.WriteStartElement("Setting");
								tw.WriteAttributeString("name", Prefix + fi.Name);
								tw.WriteAttributeString("value", val);
								tw.WriteEndElement();
							}
						}
						else
						{
							if(fi.Name == "Resolution")	
							{
								if(fi.GetValue(o).ToString() != "0")
								{
									string val = fi.FieldType.IsEnum == false ? fi.GetValue(o).ToString() : ((int) fi.GetValue(o)).ToString();
									tw.WriteStartElement("Setting");
									tw.WriteAttributeString("name", Prefix + fi.Name);
									tw.WriteAttributeString("value", val);
									tw.WriteEndElement();
								}
							}
							else
							{
                                if (fi.Name == "CountProcesses")
                                {
                                    if (fi.GetValue(o).ToString() != "1")
                                    {
                                        string val = fi.FieldType.IsEnum == false ? fi.GetValue(o).ToString() : ((int)fi.GetValue(o)).ToString();
                                        tw.WriteStartElement("Setting");
                                        tw.WriteAttributeString("name", Prefix + fi.Name);
                                        tw.WriteAttributeString("value", val);
                                        tw.WriteEndElement();
                                    }
                                }
                                else
                                {
                                    string val = fi.FieldType.IsEnum == false ? fi.GetValue(o).ToString() : ((int)fi.GetValue(o)).ToString();
                                    tw.WriteStartElement("Setting");
                                    tw.WriteAttributeString("name", Prefix + fi.Name);
                                    tw.WriteAttributeString("value", val);
                                    tw.WriteEndElement();
                                }
							}
						}
					}
				}
			}
		}

		/// <summary>
		/// Liest die Konfigurationsdatei aus.
		/// </summary>
		private static void Load()
		{
            if (new FileInfo(_ConfigFilename).Exists == false)
            {
                AppconfigExists = false;
                return;
            }
            AppconfigExists = true;

			XmlTextReader tr = null;

			try
			{
				tr = new XmlTextReader(_ConfigFilename);

				while(tr.Read())
				{
					if(tr.Name != "Setting")
						continue;

					try
					{
						LoadSetting(tr.GetAttribute("name"), tr.GetAttribute("value"));
					}
					catch {}
				}
			}
			catch 
            {
                MessageBox.Show("Fehler beim Einlesen der Appconfig.txt! / Error while reading Appconfig.txt!");
            }
			finally
			{
				if(tr != null)
					tr.Close();
			}
		}

		private static void LoadSetting(string name, string val)
		{
			string[] s = name.Split(new char[] { '.' });

			FieldInfo fi = typeof(ApplicationSettings).GetField(s[0], BindingFlags.Public | BindingFlags.Static);
			object o = null;

			for(int i = 1; i < s.Length; i++)
			{
				o  = fi.GetValue(o);
				fi = o.GetType().GetField(s[i], BindingFlags.Instance | BindingFlags.Public);
			}

			if(fi == null)
				return;

			if(fi.FieldType.IsEnum)
				fi.SetValue(o, Enum.ToObject(fi.FieldType, Int32.Parse(val)));
			if(fi.FieldType == typeof(int))
				fi.SetValue(o, Int32.Parse(val));
			if(fi.FieldType == typeof(bool))
				fi.SetValue(o, Boolean.Parse(val));
			if(fi.FieldType == typeof(double))
				fi.SetValue(o, Double.Parse(val));
			if(fi.FieldType == typeof(string))
				fi.SetValue(o, val);
		}


		#region fields
		public static string	RemoteEndPoint		    = "192.168.3.249:5141";
        public static int       DefaultTimeout          =5000;
        //public static int		PollingIntervall		= 2000;
        //public static string	HelpPath				= "";
        //public static int		ScanFormView			= 0;
		public static string	LocalEndPoint			= "192.168.3.105:5141";
        public static string	LogFile					= "Errorlog.txt";
		public static string	Culture					= "en-gb";
		public static string	WeightUnit				= "Kilogramm";
        public static string    ThroughputUnit          = "kg_h";
		public static int		AutoLogoutTime			= 180;
		public static bool		Screenshot				= false;
 		public static bool		EasyProgramExit			= false;	
		public static bool		BorderStyleVisible		= false;		
        public static bool      LoggingActive           = false;
        public static string    ScreenShotDir           = "";
        public static int       lYMax1                  = 100;
        public static int       lYMax2                  = 100;
        public static int       lYMax3                  = 100;
        public static int       lYMin1                  = 0;
        public static int       lYMin2                  = 0;
        public static int       lYMin3                  = 0;
        public static int       bCurve11                = 1;
        public static int       bCurve21                = 1;
        public static int       bCurve31                = 1;
        public static int       bCurve12                = 1;
        public static int       bCurve22                = 2;
        public static int       bCurve32                = 3;
        public static int       bTimePerDiv             = 1;
        public static int       CountHistory            = 2500;
        public static int       CountProcesses          = 1;
        public static int Variante = (int)MachineType.Extrusion;
        // Sonder by SB 140728
        public static bool ExceptionTest = false;

		#endregion


	}	



}
