﻿using Microsoft.VisualBasic;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace IgusTrimSketch.Views
{
    public partial class foSelectTrimSet: Form
    {
        public string selectedItem;
        dataBase _db;
        Controller _c;
        int _index;
        public foSelectTrimSet(List<TrimSet> ml, dataBase db)
        {
            InitializeComponent();

            _db = db;
            foreach (var item in ml)
            {
                listBox1.Items.Add(item.name);
            }
        }
        public foSelectTrimSet(Controller c, dataBase db, int index)
        {
            InitializeComponent();

            _db = db;
            _c = c;
            _index = index;

            foreach (var item in _db.trimsetList)
            {
                listBox1.Items.Add(item.name);
            }
        }

        private void btnOk_Click(object sender, EventArgs e)
        {

            _db.trimGroupList[_index].trimSetName = listBox1.SelectedItem.ToString();
            Close();

        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            Close();    //in FormClosing controller aufrufen
        }

        private void listBox1_DoubleClick(object sender, EventArgs e)
        {
            _c.showTrimset(listBox1.SelectedItem.ToString());
            Close();    //in FormClosing controller aufrufen
        }

        private void btnNewTrimset_Click(object sender, EventArgs e)
        {
            string myValue = Interaction.InputBox("Enter Name", "Input Box", "Name Here", 100, 100);
            TrimSet ts = new TrimSet(myValue, 0); //type entfernen
            _db.trimsetList.Add(ts);

            listBox1.Items.Clear();

            foreach (var item in _db.trimsetList)
            {
                listBox1.Items.Add(item.name);
            }

        }

        private void foSelectTrimSet_FormClosing(object sender, FormClosingEventArgs e)
        {
            _c.showTrimGroups();
        }
    }
}
