﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace IgusTrimSketch
{
    public partial class foTrimSet : Form
    {
        dataBase _db;
        Controller _c;
        string _trimsetName;

        public foTrimSet(Controller c, dataBase db, string trimsetName)
        {
            InitializeComponent();
            _c = c;
            _db = db;
            _trimsetName = trimsetName;

            SetupDataGridView();
            PopulateDataGridView(selectItembyName(_trimsetName));
        }

        private void Form1_Load(System.Object sender, System.EventArgs e)
        {
            SetupDataGridView();
            PopulateDataGridView(0);
        }
        private int selectItembyName(string name)
        {
            int actualTrimSet = 0;
            for (int i = 0; i < _db.trimsetList.Count; i++)
            {
                if (name==_db.trimsetList[i].name)
                {
                    actualTrimSet = i;
                    return actualTrimSet;
                }
            }
            return actualTrimSet;
        }

        private void SetupDataGridView()
        {
            ;
        }

        private void PopulateDataGridView(int actualTrimset)
        {
            List<string[]> rows = new List<string[]>();
            string[] row = new string[3];

            trimsDataGridView.Rows.Clear();
            for (int i = 0; i < 32; i++) { 
                row[0] = _db.trimsetList[actualTrimset].TrimTriples[i].nr.ToString();
                row[1] = _db.trimsetList[actualTrimset].TrimTriples[i].diameter.ToString();
                row[2] = _db.trimsetList[actualTrimset].TrimTriples[i].trim.ToString();

                rows.Add(row);
                trimsDataGridView.Rows.Add(row);
            }   
        }

        private void btnOk_Click_1(object sender, EventArgs e)
        {
            int i = 0;
            int actualTrimSet = selectItembyName(_trimsetName);
            foreach (DataGridViewRow item in trimsDataGridView.Rows)
            {
                if (i < 32)  //Todo PATCH
                {
                    _db.trimsetList[actualTrimSet].TrimTriples[i].diameter = Convert.ToInt16(item.Cells[1].Value);
                    _db.trimsetList[actualTrimSet].TrimTriples[i].trim = Convert.ToInt16(item.Cells[2].Value);
                }
                i++;
            }
         
            Close();
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void foTrimSet_FormClosing(object sender, FormClosingEventArgs e)
        {
            _c.showSelectTrimset();
        }

    }
}
