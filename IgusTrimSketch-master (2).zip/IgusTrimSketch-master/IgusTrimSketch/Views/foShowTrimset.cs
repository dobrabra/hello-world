﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace IgusTrimSketch.Views
{
    public partial class foShowTrimSet : Form
    {
        #region Members
        dataBase _db;
        bool dontClose = false;
        bool newItem = false;
        int _index = 0;
        TrimSet _tempTrimSet;
        #endregion

        #region Constructors
        public foShowTrimSet()
        {
            InitializeComponent();
        }

        public foShowTrimSet(dataBase db)
        {
            InitializeComponent();
            _db = db;
            showNewTrimset();
        }

        public foShowTrimSet(dataBase db, int index)
        {
            InitializeComponent();
            _db = db;
            _index = index;
            showActualTrimset(_index);
        }
        #endregion

        private void showNewTrimset()
        {
            try
            {
                newItem = true;
                tbxName.Text = "";
                _tempTrimSet = new TrimSet("neu", 32);
                MapTrimsetToGrid(_tempTrimSet);

            }
            catch (Exception) 
            { 
                MessageBox.Show("Error creating new trimset ");
            }
        }
 
        private void showActualTrimset(int actualTrimset)
        {
            try
            {
                tbxName.Text = _db.trimsetList[actualTrimset].name;
                MapTrimsetToGrid(_db.trimsetList[actualTrimset]);
            }
            catch (Exception)
            {
                MessageBox.Show("Error editing actual trimset ");
            }
        }

        private void MapTrimsetToGrid(TrimSet ts)
        {
            List<string[]> rows = new List<string[]>();
            string[] row = new string[3];

            trimsDataGridView.Rows.Clear();

            for (int i = 0; i < ts.TrimTriples.Length; i++)
            {
                row[0] = ts.TrimTriples[i].nr.ToString();
                row[1] = ts.TrimTriples[i].diameter.ToString();
                row[2] = ts.TrimTriples[i].trim.ToString();

                rows.Add(row);
                trimsDataGridView.Rows.Add(row);
            }
        }

        private void MapGridToTrimset(TrimSet ts)
        {
            int i = 0;

            foreach (DataGridViewRow item in trimsDataGridView.Rows)
            {
                if (i < ts.TrimTriples.Length) 
                {
                    ts.TrimTriples[i].diameter = Convert.ToInt16(item.Cells[1].Value);
                    ts.TrimTriples[i].trim = Convert.ToInt16(item.Cells[2].Value);
                }
                i++;
            }
            ts.name = tbxName.Text;
        }

       #region Eventhandler

        private void btnCancel_Click(object sender, EventArgs e)
        {
            dontClose = false;
        }

        private void btnOk_Click(object sender, EventArgs e)
        {
            int i = 0;
            dontClose = tbxName.Text == "";

            if (dontClose)
            {
                MessageBox.Show("Bitte Maschinenliste und Trimrezept wählen !");
            }
            else
            {
                if (newItem)
                {
                    MapGridToTrimset(_tempTrimSet);
                    _db.trimsetList.Add(_tempTrimSet);

                }
                else
                {
                    MapGridToTrimset(_db.trimsetList[_index]);
                }
                _db.saveDatabase();
            }
        }

        private void foEditGroup_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (dontClose)
            {
                e.Cancel = true;
            }
        }
        #endregion
    }
}
