﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace IgusTrimSketch.Views
{
    public partial class foShowMachineList : Form
    {
        #region Members
        dataBase _db;
        bool dontClose = false;
        bool newItem = false;
        int _index = 0;
        MachineList _tempMachineList;
        #endregion

        #region Constructors
        public foShowMachineList()
        {
            InitializeComponent();
        }

        public foShowMachineList(dataBase db)
        {
            InitializeComponent();
            _db = db;
            showNewMachineList();

        }

        public foShowMachineList(dataBase db, int index)
        {
            InitializeComponent();
            _db = db;
            _index = index;
            showActualMachineList(_index);
        }
        #endregion

        private void showNewMachineList()
        {
            try
            {
                newItem = true;
                tbxName.Text = "";
                _tempMachineList = new MachineList("neu");
                MapMachinelistToGrid(_tempMachineList);

            }
            catch (Exception)
            {
                MessageBox.Show("Error creating new machineList ");
            }
        }

        private void showActualMachineList(int actualMachineList)
        {
            try
            {
                tbxName.Text = _db.machineList[actualMachineList].name;
                MapMachinelistToGrid(_db.machineList[actualMachineList]);
            }
            catch (Exception)
            {

                MessageBox.Show("Error editing actual machineList ");
            }
        }

        private void MapGridToMachinelist(MachineList ml)
        {
            int i = 0;

            ml.machines.Clear();
            foreach (DataGridViewRow item in trimsDataGridView.Rows)
            {
                try
                {
                    if ((item.Cells[0].Value.ToString() != "Nr") && (item.Cells[0].Value.ToString() != ""))
                    {
                        Machine _machine = new Machine();
                        _machine.name = item.Cells[1].Value.ToString();
                        _machine.ipaddress = (item.Cells[1].Value.ToString());
                        _machine.lco = Convert.ToInt16(item.Cells[2].Value);
                        ml.AddMachine(_machine);
                    }
                }
                catch (Exception)
                {
                    ;// MessageBox.Show("Error creating new machineList ");
                }              
            }
            ml.name = tbxName.Text; ;
        }

        private void MapMachinelistToGrid(MachineList ml)
        {
            List<string[]> rows = new List<string[]>();
            string[] row = new string[3];

            trimsDataGridView.Rows.Clear();
            for (int i = 0; i < ml.machines.Count; i++)
            {
                row[0] = ml.machines[i].name;
                row[1] = ml.machines[i].ipaddress;
                row[2] = ml.machines[i].lco.ToString();
                rows.Add(row);
                trimsDataGridView.Rows.Add(row);
            }
        }

        private bool checkListname(List<MachineList> mll, int index)
        {
            int i = 0;
            foreach (var item in mll)
            {
                if ((item.name == tbxName.Text) && !(i==index))
                {
                     return false;
                }
                i++;
            }
            return (tbxName.Text == "") ? false : true;
        }

        #region Eventhandler
        private void btnCancel_Click(object sender, EventArgs e)
        {
            dontClose = false;
        }

        private void btnOk_Click(object sender, EventArgs e)
        {

          if (newItem)
          {
              if (!checkListname(_db.machineList,-1))
              {
                  MessageBox.Show(" Namen ungültig !");
                  dontClose = true;
              }
              else
              {
                  MapGridToMachinelist(_tempMachineList);
              }

          }
          else
          {
                if (!checkListname(_db.machineList, _index))
                {
                    MessageBox.Show(" Namen ungültig !");
                    dontClose = true;
                }
                else
                {
                    MapGridToMachinelist(_db.machineList[_index]);
                }
               
          }
          _db.saveDatabase();
            
        }

        private void foEditGroup_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (dontClose)
            {
                e.Cancel = true;
            }
        }
        #endregion
    }
}
