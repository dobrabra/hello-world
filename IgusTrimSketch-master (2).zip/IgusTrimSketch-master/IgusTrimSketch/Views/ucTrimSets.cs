﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Text;
using System.Windows.Forms;

namespace IgusTrimSketch.Views
{
    public partial class ucTrimSets : UserControl
    {
        #region Members
        dataBase _db;
        Controller _controller;
        #endregion

        #region Constructors
        public ucTrimSets()
        {
            InitializeComponent();
        }

        public ucTrimSets(Controller c, dataBase db)
        {
            _controller = c;
            _db = db;
            InitializeComponent();
            PopulateDataGridView();
        }
        #endregion

        public void Initialise(Controller c, dataBase db)
        {
            _controller = c;
            _db = db;
            PopulateDataGridView();
        }
        public void updateView()
        {
            PopulateDataGridView();
        }

        #region User events
  
        private void btnNew_Click(object sender, EventArgs e)
        {
            _controller.newTrimset();
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            _controller.deleteTrimset(trimsDataGridView.SelectedRows[0].Index);
        }

        private void btnEdit_Click(object sender, EventArgs e)
        {
            _controller.editTrimset(trimsDataGridView.SelectedRows[0].Index);
        }
        #endregion

        private void PopulateDataGridView()
        {
            List<string[]> rows = new List<string[]>();
            string[] row = new string[3];

            trimsDataGridView.Rows.Clear();
            for (int i = 0; i < _db.trimsetList.Count; i++)
            {
                row[0] = _db.trimsetList[i].name;
                rows.Add(row);
                trimsDataGridView.Rows.Add(row);
            }
        }
    }        
}
