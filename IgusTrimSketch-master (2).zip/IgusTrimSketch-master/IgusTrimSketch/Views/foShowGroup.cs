﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace IgusTrimSketch.Views
{
    public partial class foShowGroup : Form
    {
        #region Member
        dataBase _db;
        bool dontClose = false;
        bool newItem = false;
        int _index = 0;
        #endregion

        #region Constructor
        public foShowGroup()
        {
            InitializeComponent();
        }

        public foShowGroup(dataBase db)
        {
            InitializeComponent();
            _db = db;
            PopulateListboxes();
            newItem = true;

        }

        public foShowGroup(dataBase db, int index)
        {
            InitializeComponent();
            _db = db;
            _index = index;
            PopulateListboxes();
            SetActualValues(_index);
        }
        #endregion

        private void SetActualValues(int idx)
        {
            for (int i = 0; i < lbxMachineLists.Items.Count; i++)
            {
                if (lbxMachineLists.Items[i].ToString() == _db.trimGroupList[idx].machineListname)
                    lbxMachineLists.SelectedIndex = i;
            }

            for (int i = 0; i < lbxTrimRecipes.Items.Count; i++)
            {
                if (lbxTrimRecipes.Items[i].ToString() == _db.trimGroupList[idx].trimSetName)
                    lbxTrimRecipes.SelectedIndex = i;
            }
            try
            {
                tbxName.Text = _db.trimGroupList[idx].name;
            }
            catch (Exception)
            {
                tbxName.Text = "";
            }
        }

        private void PopulateListboxes()
        {
            for (int i = 0; i < _db.machineList.Count; i++)
            {
                lbxMachineLists.Items.Add(_db.machineList[i].name);
            }

            for (int i = 0; i < _db.trimsetList.Count; i++)
            {
                lbxTrimRecipes.Items.Add(_db.trimsetList[i].name);
            }
        }

        #region Eventhandler
        private void btnCancel_Click(object sender, EventArgs e)
        {
            dontClose = false;
        }

        private void btnOk_Click(object sender, EventArgs e)
        {
            dontClose = (lbxMachineLists.SelectedItem == null) || (lbxTrimRecipes.SelectedItem == null);

            if (dontClose)
            {
                MessageBox.Show("Bitte Maschinenliste und Trimrezept wählen !");
            }

            else
            {
                if (newItem)
                {
                    _db.trimGroupList.Add(new TrimGroup(tbxName.Text, lbxMachineLists.SelectedItem.ToString(), lbxTrimRecipes.SelectedItem.ToString()));
                }
                else
                {
                    _db.trimGroupList[_index].name = tbxName.Text;
                    _db.trimGroupList[_index].machineListname = lbxMachineLists.Text;
                    _db.trimGroupList[_index].trimSetName = lbxTrimRecipes.Text;
                }
                _db.saveDatabase();
            }
        }

        private void foEditGroup_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (dontClose)
            {
                e.Cancel = true;
            }
        }
        #endregion
    }
}
