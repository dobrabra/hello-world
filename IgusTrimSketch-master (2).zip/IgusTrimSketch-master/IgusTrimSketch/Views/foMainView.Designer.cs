﻿namespace IgusTrimSketch
{
    partial class foMainView
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.ucGroups1 = new IgusTrimSketch.Views.ucGroups();
            this.ucMachineLists1 = new IgusTrimSketch.Views.ucMachineLists();
            this.ucTrendRecipes1 = new IgusTrimSketch.Views.ucTrimSets();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.tabPage3.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.Dock = System.Windows.Forms.DockStyle.Top;
            this.label1.Location = new System.Drawing.Point(0, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(524, 13);
            this.label1.TabIndex = 13;
            // 
            // tabControl1
            // 
            this.tabControl1.Appearance = System.Windows.Forms.TabAppearance.Buttons;
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Controls.Add(this.tabPage3);
            this.tabControl1.Dock = System.Windows.Forms.DockStyle.Top;
            this.tabControl1.Location = new System.Drawing.Point(0, 13);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(524, 333);
            this.tabControl1.TabIndex = 14;
            // 
            // tabPage1
            // 
            this.tabPage1.BackColor = System.Drawing.SystemColors.ControlLight;
            this.tabPage1.Controls.Add(this.ucGroups1);
            this.tabPage1.Location = new System.Drawing.Point(4, 30);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(516, 299);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Trimgruppen";
            // 
            // tabPage2
            // 
            this.tabPage2.BackColor = System.Drawing.SystemColors.ControlDark;
            this.tabPage2.Controls.Add(this.ucMachineLists1);
            this.tabPage2.Location = new System.Drawing.Point(4, 30);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(516, 299);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Maschinenlisten";
            // 
            // tabPage3
            // 
            this.tabPage3.BackColor = System.Drawing.SystemColors.ControlDark;
            this.tabPage3.Controls.Add(this.ucTrendRecipes1);
            this.tabPage3.Location = new System.Drawing.Point(4, 30);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage3.Size = new System.Drawing.Size(516, 299);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "Trimrezepte";
            // 
            // ucGroups1
            // 
            this.ucGroups1.BackColor = System.Drawing.SystemColors.ControlDark;
            this.ucGroups1.Dock = System.Windows.Forms.DockStyle.Top;
            this.ucGroups1.Location = new System.Drawing.Point(3, 3);
            this.ucGroups1.Margin = new System.Windows.Forms.Padding(4);
            this.ucGroups1.Name = "ucGroups1";
            this.ucGroups1.Padding = new System.Windows.Forms.Padding(0, 4, 0, 0);
            this.ucGroups1.Size = new System.Drawing.Size(510, 304);
            this.ucGroups1.TabIndex = 1;
            // 
            // ucMachineLists1
            // 
            this.ucMachineLists1.BackColor = System.Drawing.SystemColors.ControlDark;
            this.ucMachineLists1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ucMachineLists1.Location = new System.Drawing.Point(3, 3);
            this.ucMachineLists1.Margin = new System.Windows.Forms.Padding(4);
            this.ucMachineLists1.Name = "ucMachineLists1";
            this.ucMachineLists1.Padding = new System.Windows.Forms.Padding(0, 4, 0, 0);
            this.ucMachineLists1.Size = new System.Drawing.Size(510, 293);
            this.ucMachineLists1.TabIndex = 1;
            // 
            // ucTrendRecipes1
            // 
            this.ucTrendRecipes1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ucTrendRecipes1.Location = new System.Drawing.Point(3, 3);
            this.ucTrendRecipes1.Margin = new System.Windows.Forms.Padding(4);
            this.ucTrendRecipes1.Name = "ucTrendRecipes1";
            this.ucTrendRecipes1.Padding = new System.Windows.Forms.Padding(0, 4, 0, 4);
            this.ucTrendRecipes1.Size = new System.Drawing.Size(510, 293);
            this.ucTrendRecipes1.TabIndex = 1;
            // 
            // foMainView
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 18F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(524, 344);
            this.Controls.Add(this.tabControl1);
            this.Controls.Add(this.label1);
            this.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.IsMdiContainer = true;
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "foMainView";
            this.Text = "Übersicht Trimgruppen";
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage2.ResumeLayout(false);
            this.tabPage3.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.TabPage tabPage3;
        private Views.ucGroups ucGroups1;
        private Views.ucMachineLists ucMachineLists1;
        private Views.ucTrimSets ucTrendRecipes1;
    }
}