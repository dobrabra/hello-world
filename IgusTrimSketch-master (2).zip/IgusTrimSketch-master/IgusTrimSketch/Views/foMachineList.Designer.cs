﻿namespace IgusTrimSketch
{
    partial class foMachineList
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.deleteRowButton = new System.Windows.Forms.Button();
            this.addNewRowButton = new System.Windows.Forms.Button();
            this.trimsDataGridView = new System.Windows.Forms.DataGridView();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.trimsDataGridView)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.deleteRowButton);
            this.panel1.Controls.Add(this.addNewRowButton);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel1.Location = new System.Drawing.Point(0, 337);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(505, 113);
            this.panel1.TabIndex = 0;
            // 
            // deleteRowButton
            // 
            this.deleteRowButton.Location = new System.Drawing.Point(196, 39);
            this.deleteRowButton.Name = "deleteRowButton";
            this.deleteRowButton.Size = new System.Drawing.Size(89, 38);
            this.deleteRowButton.TabIndex = 1;
            this.deleteRowButton.Text = "Zeile löschen";
            this.deleteRowButton.UseVisualStyleBackColor = true;
            // 
            // addNewRowButton
            // 
            this.addNewRowButton.Location = new System.Drawing.Point(33, 39);
            this.addNewRowButton.Name = "addNewRowButton";
            this.addNewRowButton.Size = new System.Drawing.Size(89, 38);
            this.addNewRowButton.TabIndex = 0;
            this.addNewRowButton.Text = "Zeile anfügen";
            this.addNewRowButton.UseVisualStyleBackColor = true;
            this.addNewRowButton.Click += new System.EventHandler(this.addNewRowButton_Click);
            // 
            // trimsDataGridView
            // 
            this.trimsDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.trimsDataGridView.Dock = System.Windows.Forms.DockStyle.Fill;
            this.trimsDataGridView.Location = new System.Drawing.Point(0, 0);
            this.trimsDataGridView.Name = "trimsDataGridView";
            this.trimsDataGridView.Size = new System.Drawing.Size(505, 337);
            this.trimsDataGridView.TabIndex = 1;
            // 
            // foMachineList
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(505, 450);
            this.Controls.Add(this.trimsDataGridView);
            this.Controls.Add(this.panel1);
            this.Name = "foMachineList";
            this.Text = "Trimgruppen";
            this.panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.trimsDataGridView)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button deleteRowButton;
        private System.Windows.Forms.Button addNewRowButton;
        private System.Windows.Forms.DataGridView trimsDataGridView;
    }
}