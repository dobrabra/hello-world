﻿using System;
using System.Collections.Generic;
using System.Text;
using IgusTrimSketch.Views;
using IgusTrimSketch.Helper;
using System.Windows.Forms;

namespace IgusTrimSketch
{
    public class Controller
    {
        foMainView viewTrimGroups;
        dataBase model;
        DatabasePersist xmlPersist;
        Service.ControlnetSender controlnetSender;
        Config config = new Config();

        public Controller()
        {
            controlnetSender = new Service.ControlnetSender(config.IpAddress, config.Port);
            controlnetSender.OnListSendingErrorHandler += ControlnetSender_OnListSendingErrorHandler;
            controlnetSender.OnListSendingReadyHandler += ControlnetSender_OnListSendingReadyHandler
                ;
            // controlnetSender = new Service.ControlnetSender("192.168.3.135",5144);
            xmlPersist = new DatabasePersist();
            model = new dataBase(xmlPersist);

            viewTrimGroups = new foMainView(this, model);
            viewTrimGroups.ShowDialog();
        }

        #region Eventhandler
        private void ControlnetSender_OnListSendingReadyHandler(object sender)
        {
            MessageBox.Show("Trimliste an alle gesendet");
        }

        private void ControlnetSender_OnListSendingErrorHandler(object sender)
        {
            MessageBox.Show("Trimliste senden abgebrochen mit Fehler");
        }
        #endregion

        #region Methods Machinelist
        public void deleteMachineList(int index)
        {
            model.machineList.RemoveAt(index);
            viewTrimGroups.updateMachineListView();
        }

        public void editMachineList(int index)
        {
            foShowMachineList editDialog = new foShowMachineList(model, index);
            editDialog.ShowDialog();
            viewTrimGroups.updateMachineListView();
        }

        public void newMachineList()
        {
            foShowMachineList editDialog = new foShowMachineList(model);
            editDialog.ShowDialog();
            viewTrimGroups.updateMachineListView();
        }
        #endregion

        #region Methods Trimset
        public void deleteTrimset(int index)
        {
            model.trimsetList.RemoveAt(index);
            viewTrimGroups.updateTrimsetView();
        }

        public void editTrimset(int index)
        {
            foShowTrimSet editDialog = new foShowTrimSet(model, index);
            editDialog.ShowDialog();
            viewTrimGroups.updateTrimsetView();
        }
  
        public void newTrimset()
        {
            foShowTrimSet editDialog = new foShowTrimSet(model);
            editDialog.ShowDialog();
            viewTrimGroups.updateTrimsetView();
        }
        #endregion

        #region Methods Trimgroups
        public void deleteGroup(int index)
        {
            model.trimGroupList.RemoveAt(index);
            viewTrimGroups.updateGroupView();
        }

        public void editGroup(int index)
        {
            foShowGroup editDialog = (index==-1) ? new foShowGroup(model) : new foShowGroup(model, index);
            editDialog.ShowDialog();
            viewTrimGroups.updateGroupView();
        }

        public void sendTrimGroupToControls(string MachineListName, string TrimSetName)
        {
            controlnetSender.SendTrimData(
                model.getMachineListByName(MachineListName),
                model.getTrimSetByName(TrimSetName)
               );
        }
        #endregion
    }
}
