﻿using Motan.XNet.XNetProtocol;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace IgusTrimSketch
{

    public partial class LcoAccess : Form
    {
        public static Motan.XNet.XNetProtocol.UDPAdapter UdpAdapter;

        System.Net.IPAddress ipSourceAddress;
        System.Net.IPEndPoint ipSourceEndpoint;
        List<TrimMessage> trimMessages = new List<TrimMessage>();

        private int count;

        public bool ListSendingIsBusy { get; private set; }

        public LcoAccess(string ipAddress, int port)
        {
            InitializeComponent();

            ipSourceAddress = System.Net.IPAddress.Parse(ipAddress);
            ipSourceEndpoint = new System.Net.IPEndPoint(ipSourceAddress, port);
 
            UdpAdapter = new Motan.XNet.XNetProtocol.UDPAdapter(ipSourceEndpoint);
            UdpAdapter.XNetAsyncMessage += UdpAdapter_XNetAsyncMessage;

        }

        private void UdpAdapter_XNetAsyncMessage(UDPAdapter udpAdapter, XNetMessage message)
        {
            count++;
            sendTrimMessageList();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            ListSendingIsBusy = true;
            count = 0;
            sendTrimMessageList();
        }

        public void SendTrimData(MachineList ml, TrimSet trimset)
        {
            trimMessages.Clear();

            for (int i = 0; i < ml.machines.Count; i++)
            {
                TrimMessage tm = new TrimMessage(ml.machines[i].ipaddress, Convert.ToByte(ml.machines[i].lco));

                for (int j = 0; j < trimset.TrimTriples.Length; j++)
                {
                    tm.data[j*4] = (byte)(trimset.TrimTriples[j].diameter >> 8);  // 0x00
                    tm.data[j*4 + 1] = (byte)trimset.TrimTriples[j].diameter;

                    tm.data[j*4 + 2] = (byte)(trimset.TrimTriples[j].trim >> 8);  // 0x00
                    tm.data[j*4 + 3] = (byte)trimset.TrimTriples[j].trim;
                }
               trimMessages.Add(tm);
            }

            sendTrimMessageList();
        }


        private void sendTrimMessageList()
        {
            if (count < trimMessages.Count)
            {
                sendTrimMessage(trimMessages[count].ipAddress, trimMessages[count].lco, trimMessages[count].data);
            }
            else
            {
                ListSendingIsBusy = false;
            }

        }


        private void sendTrimMessage(string destIp, byte destLco, byte[] data)
        {
            System.Net.IPEndPoint ipDestEndpoint = new System.Net.IPEndPoint(System.Net.IPAddress.Parse(destIp), 5141);
            Motan.XNet.XNetProtocol.XNetMessage message = new Motan.XNet.XNetProtocol.XNetMessage(
                     new LCOAddress(ipSourceEndpoint, 100),
                     new LCOAddress(ipDestEndpoint, destLco),
                     XNetMessageType.Send,
                     10,
                     100,
                     data,
                     DataPresentation.LittleEndian);

            UdpAdapter.Notify(message);
        }
    }

    public class TrimMessage
    {
        public string ipAddress;
        public byte lco;
        public byte[] data;

        public TrimMessage(string destIp, byte destLco)
        {
            ipAddress = destIp;
            lco = destLco;
            data = new byte[200];

        }
    }
}
