﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Windows.Forms;
using Motan.XNet.XNetProtocol;

namespace IgusTrimSketch.Service
{
    public class ControlnetSender
    {
        #region Member
        public Motan.XNet.XNetProtocol.UDPAdapter UdpAdapter;

        System.Net.IPAddress ipSourceAddress;
        System.Net.IPEndPoint ipSourceEndpoint;
        List<TrimMessage> trimMessages = new List<TrimMessage>();
        Timer monitorTime = new Timer();

        private int count;


        public bool ListSendingIsBusy { get; private set; }
        public bool ListSendingError { get; private set; }
        public delegate void OnListSendingReady(object sender);
        public delegate void OnListSendingError(object sender);
        public event OnListSendingReady OnListSendingReadyHandler;
        public event OnListSendingError OnListSendingErrorHandler;

        #endregion

        public ControlnetSender(string ipAddress, int port)
        {
            ipSourceAddress = System.Net.IPAddress.Parse(ipAddress);
            ipSourceEndpoint = new System.Net.IPEndPoint(ipSourceAddress, port);

            monitorTime.Interval = 1000;
            monitorTime.Tick += MonitorTime_Tick;
            try
            {
                UdpAdapter = new Motan.XNet.XNetProtocol.UDPAdapter(ipSourceEndpoint);
                UdpAdapter.XNetAsyncMessage += UdpAdapter_XNetAsyncMessage;
                if (! UdpAdapter.udpIsOk)  //TODO
                   throw new Exception("Udpadapter konnte nicht erzeugt werden. IP-Adresse und Port kontrollieren");
           }
            catch (Exception e)
            {
                MessageBox.Show("Fehler beim Erzeugen des ControlnetSender\n" + e.Message); //TODO;
            }
        }

        private void MonitorTime_Tick(object sender, EventArgs e)
        {
            monitorTime.Enabled = false;
            ListSendingError = true;
            ListSendingIsBusy = false;
            if (OnListSendingErrorHandler != null)
            {
                OnListSendingErrorHandler(this);
            }
        }

        private void UdpAdapter_XNetAsyncMessage(UDPAdapter udpAdapter, XNetMessage message)
        {
            monitorTime.Enabled = false;
            if (message.Type == XNetMessageType.Fault)
            {
                if (OnListSendingErrorHandler != null)
                {
                    OnListSendingErrorHandler(this);
                }
            }
            else
            {
                count++;
                sendTrimMessageList();
            }
        }

        public void SendTrimData(MachineList ml, TrimSet trimset)
        {
            trimMessages.Clear();

            for (int i = 0; i < ml.machines.Count; i++)
            {
                TrimMessage tm = new TrimMessage(ml.machines[i].ipaddress, Convert.ToByte(ml.machines[i].lco));

                for (int j = 0; j < trimset.TrimTriples.Length; j++)
                {
                    tm.data[j * 4] = (byte)(trimset.TrimTriples[j].diameter >> 8);  // 0x00
                    tm.data[j * 4 + 1] = (byte)trimset.TrimTriples[j].diameter;

                    tm.data[j * 4 + 2] = (byte)(trimset.TrimTriples[j].trim >> 8);  // 0x00
                    tm.data[j * 4 + 3] = (byte)trimset.TrimTriples[j].trim;
                }
                trimMessages.Add(tm);
            }
            count = 0;
            ListSendingIsBusy = true;
            sendTrimMessageList();
        }

        private void sendTrimMessageList()
        {
            if (count < trimMessages.Count)
            {
                sendTrimMessage(trimMessages[count].ipAddress, trimMessages[count].lco, trimMessages[count].data);
                monitorTime.Enabled = true;
            }
            else
            {
                if (OnListSendingReadyHandler != null)
                {
                    OnListSendingReadyHandler(this);
                }
                ListSendingIsBusy = false;
            }

        }

        private void sendTrimMessage(string destIp, byte destLco, byte[] data)
        {
            try
            {
                System.Net.IPEndPoint ipDestEndpoint = new System.Net.IPEndPoint(System.Net.IPAddress.Parse(destIp), 5141);
                Motan.XNet.XNetProtocol.XNetMessage message = new Motan.XNet.XNetProtocol.XNetMessage(
                         new LCOAddress(ipSourceEndpoint, 100),
                         new LCOAddress(ipDestEndpoint, destLco),
                         XNetMessageType.Send,
                         10,
                         243,
                         data,
                         DataPresentation.LittleEndian);

                UdpAdapter.Notify(message);
            }
            catch (Exception e)
            {

                MessageBox.Show("Fehler in sendTrimMessage "+e.Message); //TODO
            }
 
        }
    }

    public class TrimMessage
    {
        public string ipAddress;
        public byte lco;
        public byte[] data;

        public TrimMessage(string destIp, byte destLco)
        {
            ipAddress = destIp;
            lco = destLco;
            data = new byte[150];

        }
    }
}

