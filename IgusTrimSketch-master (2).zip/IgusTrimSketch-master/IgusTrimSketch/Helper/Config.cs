﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using System.Windows.Forms;
using System.Xml.Serialization;

namespace IgusTrimSketch.Helper
{
    public class Config
    {
        public string IpAddress;
        public int Port;

        public Config()
        {
            //IpAddress = "192.168.3.136";
            //Port =5144;
            using (System.IO.TextReader str = File.OpenText(@"Config.txt"))
            {
                try
                {
                    string[] _conf = str.ReadLine().Split(':');
                    IpAddress = _conf[0];
                    Port = Convert.ToUInt16(_conf[1]);
                }
                catch (Exception e)
                {
                    MessageBox.Show("Config.IpAdress: " + e.Message);
                }
            }
        }
    }
}
