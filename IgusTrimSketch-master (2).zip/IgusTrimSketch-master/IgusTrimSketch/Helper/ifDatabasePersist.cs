﻿using System;
using System.Collections.Generic;
using System.Text;


namespace IgusTrimSketch
{
    interface IDatabasePersist
    {
       void loadDatabase(dataBase db);

       void saveDatabase(dataBase db);
    }
}
