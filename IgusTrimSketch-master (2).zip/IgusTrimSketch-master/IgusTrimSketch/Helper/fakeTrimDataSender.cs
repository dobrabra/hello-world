﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;

namespace IgusTrimSketch
{
    public static class fakeTrimDataSender
    {
        public static bool senderIsBusy;
        public static void SendTrimData(MachineList ml, TrimSet trimset)
        {
            senderIsBusy = true;

            var builder = new StringBuilder();

            foreach (var m in ml.machines)
            {
                Console.WriteLine(m.ipaddress + ':' + m.lco.ToString());
                builder.Length = 0 ; // builder.Clear();

                foreach (var ts in trimset.TrimTriples)
                {
                    builder.AppendFormat("{0}, {1}, {2} :: ", ts.nr, ts.diameter, ts.trim);

                }
                Console.WriteLine("Data: <nr>,<diameter>,<trimfactor> <::> ");
                Console.Write(builder.ToString());
                Console.WriteLine();
            }
            Thread.Sleep(1000);
        }
    }
}
